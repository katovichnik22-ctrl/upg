import { useCallback, useMemo, useRef, useState } from 'react';
import {
  type Bet, type BetType, type Variant,
  LIMITS, PAYOUTS, payout, wheelOrder,
} from '../data/roulette';
import { secureInt } from './rng';

export interface SessionStats {
  spins: number;
  wagered: number;
  won: number;
}

/** Ключ ставки: тип + покрытые числа */
const keyOf = (type: BetType, numbers: string[]) => `${type}:${numbers.join('-')}`;

export function useRoulette(variant: Variant) {
  const [bets, setBets] = useState<Bet[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [stats, setStats] = useState<SessionStats>({ spins: 0, wagered: 0, won: 0 });
  const lastRound = useRef<Bet[]>([]);

  const total = useMemo(() => bets.reduce((a, b) => a + b.amount, 0), [bets]);

  const isInside = (t: BetType) =>
    t === 'straight' || t === 'split' || t === 'street' || t === 'corner' || t === 'sixline';

  /** Добавить фишку. Возвращает false, если упёрлись в лимит. */
  const place = useCallback((type: BetType, numbers: string[], amount: number): boolean => {
    const id = keyOf(type, numbers);
    const max = isInside(type) ? LIMITS.insideMax : LIMITS.outsideMax;
    let ok = true;
    setBets((cur) => {
      const found = cur.find((b) => b.id === id);
      const next = (found?.amount ?? 0) + amount;
      if (next > max) { ok = false; return cur; }
      return found
        ? cur.map((b) => (b.id === id ? { ...b, amount: next } : b))
        : [...cur, { id, type, numbers, amount }];
    });
    return ok;
  }, []);

  /** Снять одну фишку номинала (или всю ставку, если меньше) */
  const remove = useCallback((type: BetType, numbers: string[], amount: number) => {
    const id = keyOf(type, numbers);
    setBets((cur) =>
      cur.flatMap((b) => {
        if (b.id !== id) return [b];
        const left = b.amount - amount;
        return left > 0 ? [{ ...b, amount: left }] : [];
      }),
    );
  }, []);

  const undo = useCallback(() => {
    setBets((cur) => cur.slice(0, -1));
  }, []);

  const clear = useCallback(() => setBets([]), []);

  const double = useCallback(() => {
    setBets((cur) => cur.map((b) => {
      const max = isInside(b.type) ? LIMITS.insideMax : LIMITS.outsideMax;
      return { ...b, amount: Math.min(max, b.amount * 2) };
    }));
  }, []);

  const repeat = useCallback(() => {
    if (lastRound.current.length) setBets(lastRound.current.map((b) => ({ ...b })));
  }, []);

  /** Честный выбор сектора: криптостойкий генератор, каждый спин независим.
     Результат вычисляется здесь, ДО анимации — колесо лишь докручивается. */
  const drawResult = useCallback((): string => {
    const order = wheelOrder(variant);
    return order[secureInt(order.length)];
  }, [variant]);

  /** Подсчёт итогов раунда */
  const resolve = useCallback((result: string) => {
    const staked = bets.reduce((a, b) => a + b.amount, 0);
    let won = 0;
    const winners: Bet[] = [];
    for (const b of bets) {
      const p = payout(b, result);
      if (p > 0) { won += p; winners.push(b); }
    }
    lastRound.current = bets.map((b) => ({ ...b }));
    setHistory((h) => [result, ...h].slice(0, 20));
    setStats((s) => ({ spins: s.spins + 1, wagered: s.wagered + staked, won: s.won + won }));
    /* лучший множитель раунда — для эффекта джекпота */
    const bestMult = winners.reduce((m, b) => Math.max(m, PAYOUTS[b.type]), 0);
    return { staked, won, winners, bestMult };
  }, [bets]);

  const rtp = stats.wagered > 0 ? (stats.won / stats.wagered) * 100 : 0;

  return {
    bets, total, history, stats, rtp,
    place, remove, undo, clear, double, repeat,
    drawResult, resolve,
    hasLast: () => lastRound.current.length > 0,
    minBet: LIMITS.insideMin,
  };
}
