import type { Skin } from './types';

export type CaseCat = 'budget' | 'weapon' | 'rarity' | 'premium';

export interface CaseDef {
  id: string;
  name: string;
  desc: string;
  price: number;
  /** chance for the jackpot tier to roll a ★ knife/glove */
  starChance: number;
  icon: string;
  /** обложка-контейнер в public/cases */
  cover?: string;
  c1: string;
  c2: string;
  accent: string;
  cat: CaseCat;
  /** restricts which skins may drop */
  filter?: (s: Skin) => boolean;
}

export const CATEGORIES: Array<{ id: CaseCat | 'all'; label: string }> = [
  { id: 'all', label: 'Все' },
  { id: 'budget', label: 'Бюджет' },
  { id: 'weapon', label: 'Оружейные' },
  { id: 'rarity', label: 'По редкости' },
  { id: 'premium', label: 'Премиум' },
];

/* ---------- loot filters ---------- */

const w = (...names: string[]) => (s: Skin) => names.includes(s.weapon);
const rar = (...names: string[]) => (s: Skin) => names.includes(s.rarity);
const isKnife = (s: Skin) => s.star && !/gloves|wraps/i.test(s.weapon);
const isGlove = (s: Skin) => /gloves|wraps/i.test(s.weapon);

const PISTOLS = ['Glock-18', 'USP-S', 'P2000', 'P250', 'Five-SeveN', 'Tec-9', 'CZ75-Auto', 'Dual Berettas', 'Desert Eagle', 'R8 Revolver'];
const SMGS = ['MAC-10', 'MP9', 'MP7', 'MP5-SD', 'UMP-45', 'P90', 'PP-Bizon'];
const HEAVY = ['Nova', 'XM1014', 'MAG-7', 'Sawed-Off', 'M249', 'Negev'];
const SNIPERS = ['AWP', 'SSG 08', 'SCAR-20', 'G3SG1'];
const RIFLES = ['AK-47', 'M4A4', 'M4A1-S', 'FAMAS', 'Galil AR', 'AUG', 'SG 553'];

/* ---------- the cases ---------- */

export const CASES: CaseDef[] = [
  /* ---------------- budget ---------------- */
  {
    id: 'starter', name: 'Контейнер «Новичок»', cover: 'steel', desc: 'Первые шаги', price: 60, starChance: 0,
    icon: '📦', c1: '#4b5563', c2: '#1f2937', accent: '#9ca3af', cat: 'budget',
  },
  {
    id: 'steel', name: 'Контейнер «Сталь»', cover: 'steel', desc: 'Проверенная классика', price: 150, starChance: 0,
    icon: '⚙️', c1: '#64748b', c2: '#1e293b', accent: '#cbd5e1', cat: 'budget',
  },
  {
    id: 'graffiti', name: 'Контейнер «Граффити»', cover: 'violet', desc: 'Уличный стиль', price: 320, starChance: 0,
    icon: '🎨', c1: '#ec4899', c2: '#581c87', accent: '#f9a8d4', cat: 'budget',
  },
  {
    id: 'chrome', name: 'Контейнер «Хром»', cover: 'azure', desc: 'Блеск металла', price: 650, starChance: 0.02,
    icon: '🔩', c1: '#38bdf8', c2: '#1e3a8a', accent: '#7dd3fc', cat: 'budget',
  },
  {
    id: 'forest', name: 'Контейнер «Чаща»', cover: 'jade', desc: 'Полевой камуфляж', price: 900, starChance: 0.02,
    icon: '🌲', c1: '#22c55e', c2: '#14532d', accent: '#86efac', cat: 'budget',
  },

  /* ---------------- weapon ---------------- */
  {
    id: 'ak', name: 'Оружейный «Калибр»', cover: 'crimson', desc: 'Только легендарный «калаш»', price: 1800, starChance: 0,
    icon: '🔫', c1: '#f97316', c2: '#7c2d12', accent: '#fdba74', cat: 'weapon',
    filter: w('AK-47'),
  },
  {
    id: 'awp', name: 'Оружейный «Дальний»', cover: 'azure', desc: 'Один выстрел — один фраг', price: 2600, starChance: 0,
    icon: '🎯', c1: '#06b6d4', c2: '#164e63', accent: '#67e8f9', cat: 'weapon',
    filter: w('AWP'),
  },
  {
    id: 'm4', name: 'Оружейный «Штурм»', cover: 'steel', desc: 'Арсенал спецназа', price: 2000, starChance: 0,
    icon: '🛡️', c1: '#3b82f6', c2: '#1e3a8a', accent: '#93c5fd', cat: 'weapon',
    filter: w('M4A4', 'M4A1-S'),
  },
  {
    id: 'pistol', name: 'Оружейный «Запасной»', cover: 'pistol', desc: 'Всё для пистолетного раунда', price: 700, starChance: 0,
    icon: '🔧', c1: '#a855f7', c2: '#4c1d95', accent: '#d8b4fe', cat: 'weapon',
    filter: w(...PISTOLS),
  },
  {
    id: 'smg', name: 'Оружейный «Шквал»', cover: 'voltage', desc: 'Скорострельность решает', price: 850, starChance: 0,
    icon: '💨', c1: '#14b8a6', c2: '#134e4a', accent: '#5eead4', cat: 'weapon',
    filter: w(...SMGS),
  },
  {
    id: 'heavy', name: 'Оружейный «Тяжёлый»', cover: 'ember', desc: 'Дробовики и пулемёты', price: 620, starChance: 0,
    icon: '💥', c1: '#eab308', c2: '#713f12', accent: '#fde047', cat: 'weapon',
    filter: w(...HEAVY),
  },
  {
    id: 'sniper', name: 'Оружейный «Прицел»', cover: 'frost', desc: 'Работа на дистанции', price: 2300, starChance: 0,
    icon: '🔭', c1: '#0ea5e9', c2: '#0c4a6e', accent: '#7dd3fc', cat: 'weapon',
    filter: w(...SNIPERS),
  },
  {
    id: 'rifle', name: 'Оружейный «Линия»', cover: 'crimson', desc: 'Основное оружие боя', price: 1600, starChance: 0,
    icon: '⚔️', c1: '#f43f5e', c2: '#881337', accent: '#fda4af', cat: 'weapon',
    filter: w(...RIFLES),
  },

  /* ---------------- rarity ---------------- */
  {
    id: 'blue', name: 'Контейнер «Лазурь»', cover: 'azure', desc: 'Только армейское качество', price: 260, starChance: 0,
    icon: '🔵', c1: '#4b69ff', c2: '#1e2a78', accent: '#93a5ff', cat: 'rarity',
    filter: rar('Mil-Spec Grade'),
  },
  {
    id: 'purple', name: 'Контейнер «Аметист»', cover: 'violet', desc: 'Только запрещённое', price: 1100, starChance: 0,
    icon: '🟣', c1: '#8847ff', c2: '#3b1d78', accent: '#c4a3ff', cat: 'rarity',
    filter: rar('Restricted'),
  },
  {
    id: 'pink', name: 'Контейнер «Пурпур»', cover: 'elite', desc: 'Только засекреченное', price: 3600, starChance: 0,
    icon: '🌸', c1: '#d32ce6', c2: '#6b1173', accent: '#f0a5f7', cat: 'rarity',
    filter: rar('Classified'),
  },
  {
    id: 'red', name: 'Контейнер «Багрянец»', cover: 'crimson', desc: 'Только тайное', price: 9500, starChance: 0.05,
    icon: '🔴', c1: '#eb4b4b', c2: '#7f1d1d', accent: '#fca5a5', cat: 'rarity',
    filter: rar('Covert'),
  },

  /* ---------------- premium ---------------- */
  {
    id: 'neon', name: 'Контейнер «Неон»', cover: 'voltage', desc: 'Кислотные раскраски', price: 1400, starChance: 0.04,
    icon: '⚡', c1: '#d946ef', c2: '#4a044e', accent: '#f0abfc', cat: 'premium',
  },
  {
    id: 'gold', name: 'Контейнер «Золото»', cover: 'golden', desc: 'Богатый улов', price: 3200, starChance: 0.08,
    icon: '💰', c1: '#f6c445', c2: '#78350f', accent: '#fcd34d', cat: 'premium',
  },
  {
    id: 'dragon', name: 'Контейнер «Дракон»', cover: 'ember', desc: 'Пламя и чешуя', price: 7500, starChance: 0.14,
    icon: '🐉', c1: '#ef4444', c2: '#4c0519', accent: '#fda4af', cat: 'premium',
  },
  {
    id: 'samurai', name: 'Контейнер «Клинок»', cover: 'shadow', desc: 'Путь воина', price: 11000, starChance: 0.2,
    icon: '🏯', c1: '#fb7185', c2: '#500724', accent: '#fecdd3', cat: 'premium',
  },
  {
    id: 'knife', name: 'Ножевой контейнер', cover: 'knife', desc: 'Только ножи — гарантия ★', price: 85000, starChance: 1,
    icon: '🗡️', c1: '#a78bfa', c2: '#3b0764', accent: '#ddd6fe', cat: 'premium',
    filter: isKnife,
  },
  {
    id: 'glove', name: 'Перчаточный контейнер', cover: 'glove', desc: 'Только перчатки — гарантия ★', price: 92000, starChance: 1,
    icon: '🧤', c1: '#f59e0b', c2: '#7c2d12', accent: '#fcd34d', cat: 'premium',
    filter: isGlove,
  },
  {
    id: 'legend', name: 'Контейнер «Легенда»', cover: 'elite', desc: 'Максимальный риск', price: 42000, starChance: 0.55,
    icon: '👑', c1: '#fde047', c2: '#854d0e', accent: '#fef08a', cat: 'premium',
  },
  {
    id: 'mythic', name: 'Контейнер «Миф»', cover: 'vault', desc: 'Топ инвентаря', price: 90000, starChance: 0.7,
    icon: '💎', c1: '#22d3ee', c2: '#083344', accent: '#a5f3fc', cat: 'premium',
  },

  /* ---------------- дополнительные ---------------- */
  {
    id: 'desert', name: 'Контейнер «Пустыня»', cover: 'ember', desc: 'Песок и камуфляж', price: 480, starChance: 0,
    icon: '🏜️', c1: '#d97706', c2: '#451a03', accent: '#fcd34d', cat: 'budget',
  },
  {
    id: 'arctic', name: 'Контейнер «Арктика»', cover: 'frost', desc: 'Белый камуфляж', price: 1100, starChance: 0.02,
    icon: '❄️', c1: '#38bdf8', c2: '#082f49', accent: '#bae6fd', cat: 'budget',
  },
  {
    id: 'deagle', name: 'Оружейный «Орёл»', cover: 'pistol', desc: 'Только Desert Eagle', price: 1300, starChance: 0,
    icon: '🦅', c1: '#a855f7', c2: '#3b0764', accent: '#e9d5ff', cat: 'weapon',
    filter: w('Desert Eagle'),
  },
  {
    id: 'usp', name: 'Оружейный «Тишина»', cover: 'steel', desc: 'Пистолет спецназа', price: 900, starChance: 0,
    icon: '🎯', c1: '#0ea5e9', c2: '#0c4a6e', accent: '#7dd3fc', cat: 'weapon',
    filter: w('USP-S'),
  },
  {
    id: 'glock', name: 'Оружейный «Старт»', cover: 'voltage', desc: 'Оружие террористов', price: 850, starChance: 0,
    icon: '🔸', c1: '#f59e0b', c2: '#451a03', accent: '#fde68a', cat: 'weapon',
    filter: w('Glock-18'),
  },
  {
    id: 'famas', name: 'Оружейный «Отряд»', cover: 'jade', desc: 'FAMAS, Galil, AUG, SG', price: 1050, starChance: 0,
    icon: '⚡', c1: '#65a30d', c2: '#1a2e05', accent: '#bef264', cat: 'weapon',
    filter: w('FAMAS', 'Galil AR', 'AUG', 'SG 553'),
  },
  {
    id: 'silver', name: 'Контейнер «Серебро»', cover: 'steel', desc: 'Промышленное качество', price: 180, starChance: 0,
    icon: '⬜', c1: '#94a3b8', c2: '#1e293b', accent: '#e2e8f0', cat: 'rarity',
    filter: rar('Industrial Grade', 'Consumer Grade'),
  },
  {
    id: 'contraband', name: 'Контейнер «Запрет»', cover: 'vault', desc: 'Легендарные предметы', price: 65000, starChance: 0.4,
    icon: '🚫', c1: '#e4ae39', c2: '#451a03', accent: '#fde047', cat: 'premium',
  },
  {
    id: 'halloween', name: 'Контейнер «Жатва»', cover: 'shadow', desc: 'Событийный кейс', price: 5200, starChance: 0.1,
    icon: '🎃', c1: '#ea580c', c2: '#431407', accent: '#fdba74', cat: 'premium',
  },
  {
    id: 'newyear', name: 'Контейнер «Стужа»', cover: 'frost', desc: 'Событийный кейс', price: 6400, starChance: 0.12,
    icon: '🎄', c1: '#16a34a', c2: '#052e16', accent: '#86efac', cat: 'premium',
  },
  {
    id: 'esports', name: 'Контейнер «Арена»', cover: 'elite', desc: 'Турнирная классика', price: 9800, starChance: 0.16,
    icon: '🏆', c1: '#2563eb', c2: '#172554', accent: '#93c5fd', cat: 'premium',
  },
  {
    id: 'titan', name: 'Контейнер «Титан»', cover: 'steel', desc: 'Тяжёлый металл', price: 18000, starChance: 0.34,
    icon: '⚙️', c1: '#64748b', c2: '#0f172a', accent: '#cbd5e1', cat: 'premium',
  },
];

/* ---------------- drop math ---------------- */

/** Weighted value tiers (multiples of the case price). Average RTP ≈ 88%. */
const TIERS: Array<{ p: number; lo: number; hi: number }> = [
  { p: 0.535, lo: 0.135, hi: 0.54 },
  { p: 0.270, lo: 0.540, hi: 1.04 },
  { p: 0.130, lo: 1.040, hi: 2.15 },
  { p: 0.052, lo: 2.150, hi: 5.40 },
  { p: 0.013, lo: 5.400, hi: 15.8 },
];

function rollTier() {
  let r = Math.random();
  for (let i = 0; i < TIERS.length; i++) {
    r -= TIERS[i].p;
    if (r <= 0) return { ...TIERS[i], top: i === TIERS.length - 1 };
  }
  return { ...TIERS[TIERS.length - 1], top: true };
}

const inRange = (list: Skin[], lo: number, hi: number) =>
  list.filter((s) => s.price >= lo && s.price <= hi);

const rnd = <T,>(list: T[]): T => list[Math.floor(Math.random() * list.length)];

/** every skin this case is allowed to give */
export function casePool(skins: Skin[], c: CaseDef): Skin[] {
  if (!c.filter) return skins;
  const f = skins.filter(c.filter);
  return f.length >= 6 ? f : skins;
}

/** items shown spinning on the reel */
export function reelPool(skins: Skin[], c: CaseDef): Skin[] {
  const base = casePool(skins, c);
  const near = inRange(base, c.price * 0.1, c.price * 6);
  return near.length >= 10 ? near : base.slice(0, 80);
}

/** the actual weighted drop */
export function rollCaseDrop(skins: Skin[], c: CaseDef): Skin {
  const base = casePool(skins, c);
  const tier = rollTier();

  if (tier.top && c.starChance > 0 && Math.random() < c.starChance) {
    const stars = base.filter((s) => s.star && s.price >= c.price * tier.lo);
    if (stars.length > 0) return rnd(stars);
  }

  let pool = inRange(base, c.price * tier.lo, c.price * tier.hi);
  if (pool.length === 0) pool = inRange(base, c.price * tier.lo * 0.55, c.price * tier.hi * 2);
  if (pool.length === 0) pool = inRange(base, 1, c.price * tier.hi * 4);
  if (pool.length === 0) pool = base;
  return rnd(pool);
}
