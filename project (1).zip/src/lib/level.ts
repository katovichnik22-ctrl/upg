/**
 * Level curve.
 *
 * XP is the total amount wagered. A linear curve (xp / 2500) produced absurd
 * numbers — 4M wagered turned into level 1600. Instead each level costs
 * progressively more, so levels stay meaningful deep into a long session:
 *
 *   totalXpFor(L) = BASE * (L - 1) ^ EXP
 *
 *   1M wagered  → ~24
 *   4M wagered  → ~44
 *   25M wagered → ~110
 */

const BASE = 1000;
const EXP = 2.2;
export const MAX_LEVEL = 999;

/** cumulative XP required to reach the given level */
export function totalXpFor(level: number): number {
  if (level <= 1) return 0;
  return Math.round(BASE * Math.pow(level - 1, EXP));
}

export function levelFromXp(xp: number): number {
  if (xp <= 0) return 1;
  const lvl = Math.floor(Math.pow(xp / BASE, 1 / EXP)) + 1;
  return Math.max(1, Math.min(MAX_LEVEL, lvl));
}

export interface LevelInfo {
  level: number;
  /** 0..1 progress towards the next level */
  progress: number;
  /** xp earned inside the current level */
  into: number;
  /** xp span of the current level */
  span: number;
  /** xp still required for the next level */
  remaining: number;
}

export function levelInfo(xp: number): LevelInfo {
  const level = levelFromXp(xp);
  const cur = totalXpFor(level);
  const next = totalXpFor(level + 1);
  const span = Math.max(1, next - cur);
  const into = Math.max(0, Math.min(span, xp - cur));
  return {
    level,
    progress: Math.max(0, Math.min(1, into / span)),
    into,
    span,
    remaining: Math.max(0, next - xp),
  };
}
