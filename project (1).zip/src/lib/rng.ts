/**
 * Честный генератор случайных чисел.
 * Приоритет — crypto.getRandomValues (криптостойкий, одинаково честный
 * во всех WebView). Fallback — Math.random с перемешиванием сида.
 */

let fallbackSeed = 0;
function initSeed(): number {
  const t = Date.now();
  const p = typeof performance !== 'undefined' ? performance.now() : 0;
  return (t ^ Math.floor(p * 1000) ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
}

/** Возвращает число в диапазоне [0, 1). */
export function secureRandom(): number {
  try {
    const c = typeof crypto !== 'undefined' ? crypto : undefined;
    if (c && typeof c.getRandomValues === 'function') {
      const buf = new Uint32Array(1);
      c.getRandomValues(buf);
      return buf[0] / 2 ** 32;
    }
  } catch {
    /* getRandomValues недоступен — идём в fallback */
  }
  /* fallback: xorshift поверх Math.random + сид из времени */
  if (fallbackSeed === 0) fallbackSeed = initSeed();
  let x = fallbackSeed;
  x ^= x << 13; x >>>= 0;
  x ^= x >> 17;
  x ^= x << 5;  x >>>= 0;
  fallbackSeed = x;
  /* смешиваем с Math.random, чтобы не было повторяющихся последовательностей */
  return ((x / 2 ** 32) + Math.random()) % 1;
}

/** Целое в диапазоне [0, n). */
export function secureInt(n: number): number {
  return Math.floor(secureRandom() * n);
}
