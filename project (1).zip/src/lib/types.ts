import type { ItemType, WeaponCat } from '../types/items';

export interface Skin {
  id: string;
  /** категория для фильтров магазина */
  cat?: WeaponCat;
  type?: ItemType;
  name: string;
  weapon: string;
  rarity: string;
  rarityRu: string;
  color: string;
  price: number;
  image: string;
  star: boolean;
}

export interface OwnedSkin extends Skin {
  uid: string;
}

export type Tab = 'upgrader' | 'roulette' | 'clicker' | 'online' | 'shop' | 'profile' | 'settings';
export type GameId = 'casino-roulette' | 'roulette' | 'slots' | 'blackjack' | 'crash' | 'mines' | 'coinflip' | 'aviator' | 'plinko' | 'penalty' | 'fishing';

export interface HistoryItem {
  id: string;
  time: number;
  kind: 'upgrade' | 'roulette' | 'shop' | 'bonus' | 'sell' | 'case' | 'game';
  text: string;
  amount: number;
  success?: boolean;
}

export interface Stats {
  upgrades: number;
  upgradeWins: number;
  rouletteSpins: number;
  rouletteWins: number;
  wagered: number;
  earned: number;
  bestWin: number;
  casesOpened: number;
  gamesPlayed: number;
  gameWins: number;
  deposited: number;
}

export type ViewMode = 'auto' | 'mobile' | 'desktop';

export interface Settings {
  sound: boolean;
  volume: number;
  fast: boolean;
  view: ViewMode;
  /** режим экономии ресурсов для слабых устройств */
  lite: boolean;
}

export type ToastType = 'win' | 'lose' | 'info';
export interface Toast {
  id: number;
  text: string;
  sub?: string;
  type: ToastType;
}
