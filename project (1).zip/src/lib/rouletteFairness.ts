import { secureInt } from './rng';
import { wheelOrder, colorOf, isZero, type Variant } from '../data/roulette';

/** DEV-проверка честности рулетки: прогон N спинов и статистика в консоль. */
export function testRouletteFairness(n = 100000, variant: Variant = 'eu'): void {
  const order = wheelOrder(variant);
  const size = order.length;

  const counts: Record<string, number> = {};
  let red = 0, black = 0, green = 0, odd = 0, even = 0;
  const dozens = [0, 0, 0];
  let maxRedStreak = 0, maxBlackStreak = 0, streak = 0;
  let streakColor: string | null = null;

  for (let i = 0; i < n; i++) {
    const num = order[secureInt(size)];
    counts[num] = (counts[num] ?? 0) + 1;

    const c = colorOf(num);
    if (c === 'red') red++; else if (c === 'black') black++; else green++;

    if (!isZero(num)) {
      const v = Number(num);
      if (v % 2 === 0) even++; else odd++;
      dozens[Math.floor((v - 1) / 12)]++;
    }

    if (c === 'red' || c === 'black') {
      if (c === streakColor) streak++;
      else { streakColor = c; streak = 1; }
      if (c === 'red') maxRedStreak = Math.max(maxRedStreak, streak);
      else maxBlackStreak = Math.max(maxBlackStreak, streak);
    } else {
      streakColor = null; streak = 0;
    }
  }

  const expected = n / size;
  const nums = Object.entries(counts).map(([k, v]) => ({ k, v }));
  nums.sort((a, b) => a.v - b.v);
  const min = nums[0], max = nums[nums.length - 1];

  /* eslint-disable no-console */
  console.log(`%c🎡 Тест честности рулетки — ${variant.toUpperCase()} · ${n.toLocaleString('ru')} спинов`,
    'color:#f6c445;font-weight:bold');
  console.log(`Ожидание на число: ~${expected.toFixed(0)}`);
  console.log(`Красное: ${red} (${(red / n * 100).toFixed(2)}%)`);
  console.log(`Чёрное:  ${black} (${(black / n * 100).toFixed(2)}%)`);
  console.log(`Зеро:    ${green} (${(green / n * 100).toFixed(2)}%)`);
  console.log(`Чёт/Нечет: ${even} / ${odd}`);
  console.log(`Дюжины: 1-12=${dozens[0]}  13-24=${dozens[1]}  25-36=${dozens[2]}`);
  console.log(`Реже всего: ${min.k}=${min.v}, чаще всего: ${max.k}=${max.v} (разброс ${((max.v - min.v) / expected * 100).toFixed(1)}%)`);
  console.log(`Макс. стрик: красное ×${maxRedStreak}, чёрное ×${maxBlackStreak}`);
  console.log('Норма: числа ~равномерны, стрик 10–13 за 100k — это математика, не баг.');
  /* eslint-enable no-console */
}

/** Признак режима разработки (без vite-типов). */
export const IS_DEV = typeof location !== 'undefined'
  && location.hostname === 'localhost' && location.port !== '';

/* в разработке функция доступна из консоли: testRouletteFairness(100000) */
if (IS_DEV && typeof window !== 'undefined') {
  (window as unknown as { testRouletteFairness: typeof testRouletteFairness })
    .testRouletteFairness = testRouletteFairness;
}
