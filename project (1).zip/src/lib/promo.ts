import { readPromos, writePromos } from '../admin/adminCore';

/** Результат активации промокода */
export interface PromoResult {
  ok: boolean;
  /** сколько начислено на баланс */
  amount: number;
  /** заголовок уведомления */
  title: string;
  /** подпись уведомления */
  note?: string;
  /** отдельное сообщение, показываемое крупным баннером */
  banner?: string;
}

/** Встроенные промокоды: код → награда */
interface BuiltIn {
  amount: number;
  note: string;
  banner?: string;
}

const BUILT_IN: Record<string, BuiltIn> = {
  PASHAGAY: { amount: 67_000, note: 'Промокод активирован' },
  MATVEYPIDOR: { amount: 10_000, note: 'Промокод активирован', banner: 'твой папа лох' },
};

const K_USED = 'nikgrager-promo-used';

const readUsed = (): string[] => {
  try { return JSON.parse(localStorage.getItem(K_USED) ?? '[]'); } catch { return []; }
};

const markUsed = (code: string) => {
  try {
    const list = readUsed();
    if (!list.includes(code)) {
      list.push(code);
      localStorage.setItem(K_USED, JSON.stringify(list));
    }
  } catch { /* нет места */ }
};

/** Был ли код уже активирован на этом устройстве */
export const isUsed = (code: string) => readUsed().includes(code.trim().toUpperCase());

/**
 * Активация промокода.
 * Сначала проверяются встроенные коды, затем созданные в админ-панели.
 */
export function redeem(raw: string): PromoResult {
  const code = raw.trim().toUpperCase();
  if (!code) return { ok: false, amount: 0, title: 'Введите код' };

  if (readUsed().includes(code)) {
    return { ok: false, amount: 0, title: 'Код уже использован' };
  }

  /* встроенные */
  const b = BUILT_IN[code];
  if (b) {
    markUsed(code);
    return { ok: true, amount: b.amount, title: b.note, banner: b.banner };
  }

  /* созданные администратором */
  const list = readPromos();
  const i = list.findIndex((p) => p.code.toUpperCase() === code);
  if (i >= 0) {
    const p = list[i];
    if (p.used >= p.limit) {
      return { ok: false, amount: 0, title: 'Лимит активаций исчерпан' };
    }
    list[i] = { ...p, used: p.used + 1 };
    writePromos(list);
    markUsed(code);
    return { ok: true, amount: p.amount, title: 'Промокод активирован' };
  }

  return { ok: false, amount: 0, title: 'Такого кода нет' };
}
