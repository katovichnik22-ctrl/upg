import type { ClickerState } from './store';

/** Описание апгрейда кликера */
export interface UpgradeDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
  baseCost: number;
  /** рост цены за уровень */
  growth: number;
  maxLevel: number;
  /** применение эффекта к состоянию */
  apply: (c: ClickerState, level: number) => Partial<ClickerState>;
  /** что даёт следующий уровень (для подписи) */
  gain: (level: number) => string;
}

/**
 * Баланс кликера рассчитан так, чтобы прогресс был долгим:
 * цены апгрейдов растут круче, прирост характеристик скромнее,
 * а обменный курс монет в рубли заметно ниже единицы.
 */
export const UPGRADES: UpgradeDef[] = [
  {
    id: 'power',
    name: 'Сила клика',
    desc: 'Больше монет за тап',
    icon: 'zap',
    baseCost: 120,
    growth: 1.85,
    maxLevel: 40,
    apply: (_c, lvl) => ({ perClick: 1 + Math.floor(lvl * 0.7) }),
    gain: (lvl) => `станет +${1 + Math.floor((lvl + 1) * 0.7)} за клик`,
  },
  {
    id: 'energy',
    name: 'Макс. энергия',
    desc: 'Дольше играть без паузы',
    icon: 'battery',
    baseCost: 200,
    growth: 1.8,
    maxLevel: 30,
    apply: (_c, lvl) => ({ maxEnergy: 100 + lvl * 15 }),
    gain: (lvl) => `+15 энергии (станет ${100 + (lvl + 1) * 15})`,
  },
  {
    id: 'regen',
    name: 'Регенерация',
    desc: 'Энергия восстанавливается быстрее',
    icon: 'refresh',
    baseCost: 350,
    growth: 1.95,
    maxLevel: 20,
    apply: (_c, lvl) => ({ regen: 1 + lvl * 0.25 }),
    gain: (lvl) => `+0.25/сек (станет ${(1 + (lvl + 1) * 0.25).toFixed(2)})`,
  },
  {
    id: 'auto',
    name: 'Автокликер',
    desc: 'Пассивный доход в секунду',
    icon: 'bot',
    baseCost: 900,
    growth: 2.05,
    maxLevel: 25,
    apply: (_c, lvl) => ({ auto: Math.floor(lvl * 0.8) }),
    gain: (lvl) => `станет ${Math.floor((lvl + 1) * 0.8)}/сек`,
  },
  {
    id: 'crit',
    name: 'Крит-шанс',
    desc: 'Шанс умножить награду',
    icon: 'target',
    baseCost: 1400,
    growth: 2.1,
    maxLevel: 20,
    apply: (_c, lvl) => ({ critChance: Math.min(0.3, lvl * 0.012) }),
    gain: (lvl) => `станет ${(Math.min(0.3, (lvl + 1) * 0.012) * 100).toFixed(1)}%`,
  },
  {
    id: 'critmult',
    name: 'Сила крита',
    desc: 'Множитель крита ×2 → ×5',
    icon: 'flame',
    baseCost: 9000,
    growth: 4.5,
    maxLevel: 3,
    apply: (_c, lvl) => ({ critMult: [2, 2.5, 3.5, 5][Math.min(3, lvl)] }),
    gain: (lvl) => `множитель ×${[2, 2.5, 3.5, 5][Math.min(3, lvl + 1)]}`,
  },
];

export const upgradeCost = (u: UpgradeDef, level: number) =>
  Math.round(u.baseCost * Math.pow(u.growth, level));

/** Пересчёт всех характеристик из уровней апгрейдов */
export function recalc(c: ClickerState): ClickerState {
  let next: ClickerState = { ...c };
  for (const u of UPGRADES) {
    const lvl = c.upgrades[u.id] ?? 0;
    if (lvl > 0) next = { ...next, ...u.apply(next, lvl) };
  }
  next.energy = Math.min(next.energy, next.maxEnergy);
  return next;
}

/** Офлайн-доход и восстановление энергии при возврате */
export function applyOffline(c: ClickerState): { next: ClickerState; earned: number; secs: number } {
  const now = Date.now();
  const secs = Math.max(0, Math.floor((now - (c.lastSeen || now)) / 1000));
  /* офлайн считаем максимум за 4 часа и с половинной отдачей */
  const capped = Math.min(secs, 4 * 3600);
  const earned = Math.floor(capped * c.auto * 0.5);
  const energy = Math.min(c.maxEnergy, c.energy + capped * c.regen);
  return {
    next: { ...c, coins: c.coins + earned, energy, lastSeen: now },
    earned,
    secs: capped,
  };
}

/** Ежедневный бонус со стриком */
export const dailyReward = (streak: number) => 120 * Math.min(7, Math.max(1, streak));

/** Мини-задания */
export interface TaskDef {
  id: string;
  name: string;
  reward: number;
  done: (c: ClickerState) => boolean;
  progress: (c: ClickerState) => string;
}

const upgradeLevels = (c: ClickerState) =>
  Object.values(c.upgrades).reduce((a, b) => a + b, 0);

export const TASKS: TaskDef[] = [
  {
    id: 'clicks100', name: 'Сделать 100 кликов', reward: 120,
    done: (c) => c.totalClicks >= 100,
    progress: (c) => `${Math.min(100, c.totalClicks)}/100`,
  },
  {
    id: 'clicks1000', name: 'Сделать 1 000 кликов', reward: 600,
    done: (c) => c.totalClicks >= 1000,
    progress: (c) => `${Math.min(1000, c.totalClicks)}/1000`,
  },
  {
    id: 'clicks10000', name: 'Сделать 10 000 кликов', reward: 4000,
    done: (c) => c.totalClicks >= 10000,
    progress: (c) => `${Math.min(10000, c.totalClicks)}/10000`,
  },
  {
    id: 'clicks50000', name: 'Сделать 50 000 кликов', reward: 18000,
    done: (c) => c.totalClicks >= 50000,
    progress: (c) => `${Math.min(50000, c.totalClicks)}/50000`,
  },
  {
    id: 'up3', name: 'Купить 3 апгрейда', reward: 250,
    done: (c) => upgradeLevels(c) >= 3,
    progress: (c) => `${Math.min(3, upgradeLevels(c))}/3`,
  },
  {
    id: 'up15', name: 'Купить 15 апгрейдов', reward: 1400,
    done: (c) => upgradeLevels(c) >= 15,
    progress: (c) => `${Math.min(15, upgradeLevels(c))}/15`,
  },
  {
    id: 'up40', name: 'Купить 40 апгрейдов', reward: 9000,
    done: (c) => upgradeLevels(c) >= 40,
    progress: (c) => `${Math.min(40, upgradeLevels(c))}/40`,
  },
  {
    id: 'auto', name: 'Включить автокликер', reward: 400,
    done: (c) => c.auto > 0,
    progress: (c) => (c.auto > 0 ? 'готово' : 'не куплен'),
  },
];

/**
 * Курс обмена монет кликера в игровые рубли.
 * Намеренно ниже единицы: заработать на дорогие кейсы должно быть трудом.
 */
export const COIN_RATE = 0.35;

/** Минимальная сумма обмена */
export const MIN_EXCHANGE = 500;
