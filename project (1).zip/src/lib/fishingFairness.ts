import { secureRandom } from './rng';
import { FISH, CRIT_AVG, FISHING_RTP, killChance, pickFish, rollCrit } from '../data/fishing';

/** DEV-проверка RTP рыбалки: N результативных выстрелов. */
export function testFishingRTP(n = 10000): void {
  let staked = 0;
  let won = 0;
  const caught: Record<string, number> = {};
  const bet = 10;

  for (let i = 0; i < n; i++) {
    staked += bet;
    const f = pickFish(secureRandom);
    /* выстрел попал в рыбу — решаем, выловлена ли она */
    if (secureRandom() < killChance(f)) {
      const crit = rollCrit(secureRandom);
      won += bet * f.mult * crit;
      caught[f.id] = (caught[f.id] ?? 0) + 1;
    }
  }

  const rtp = won / staked;
  /* eslint-disable no-console */
  console.log(`%c🐟 Тест RTP рыбалки — ${n.toLocaleString('ru')} выстрелов`,
    'color:#7fd3e8;font-weight:bold');
  console.log(`Поставлено: ${staked.toLocaleString('ru')}`);
  console.log(`Выиграно:   ${Math.round(won).toLocaleString('ru')}`);
  console.log(`RTP: ${(rtp * 100).toFixed(2)}%  (цель ${(FISHING_RTP * 100).toFixed(0)}%)`);
  console.log(`Средний крит-множитель: ${CRIT_AVG.toFixed(3)}`);
  console.table(
    FISH.map((f) => ({
      рыба: f.label,
      множитель: `x${f.mult}`,
      'шанс улова': `${(killChance(f) * 100).toFixed(1)}%`,
      поймано: caught[f.id] ?? 0,
    })),
  );
  console.log(rtp > 1
    ? '%c⚠️ RTP выше 100% — математика сломана!'
    : '%c✅ RTP в норме: в долгую казино в плюсе',
    rtp > 1 ? 'color:#ff6b7d' : 'color:#4ade80');
  /* eslint-enable no-console */
}

export const IS_DEV = typeof location !== 'undefined'
  && location.hostname === 'localhost' && location.port !== '';

if (IS_DEV && typeof window !== 'undefined') {
  (window as unknown as { testFishingRTP: typeof testFishingRTP })
    .testFishingRTP = testFishingRTP;
}
