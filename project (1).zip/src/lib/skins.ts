import type { Skin } from './types';
import { priceFor as realPrice, weaponCat } from '../data/skins';
import { rarityColor, rarityRu } from '../data/rarity';

/* ------------------------------------------------------------------ */
/*  Price model (virtual, deterministic)                               */
/* ------------------------------------------------------------------ */

const RARITY_PRICE: Record<string, [number, number]> = {
  'Consumer Grade': [8, 70],
  'Industrial Grade': [15, 140],
  'Mil-Spec Grade': [35, 950],
  'Restricted': [160, 3800],
  'Classified': [650, 16000],
  'Covert': [2500, 95000],
  'Extraordinary': [36000, 480000],
  'Contraband': [120000, 260000],
};

const RARITY_RU: Record<string, string> = {
  'Consumer Grade': 'Ширпотреб',
  'Industrial Grade': 'Промышленное',
  'Mil-Spec Grade': 'Армейское',
  'Restricted': 'Запрещённое',
  'Classified': 'Засекреченное',
  'Covert': 'Тайное',
  'Extraordinary': 'Экстраординарное',
  'Contraband': 'Контрабанда',
};

const RARITY_FALLBACK_COLOR: Record<string, string> = {
  'Consumer Grade': '#b0c3d9',
  'Industrial Grade': '#5e98d9',
  'Mil-Spec Grade': '#4b69ff',
  'Restricted': '#8847ff',
  'Classified': '#d32ce6',
  'Covert': '#eb4b4b',
  'Extraordinary': '#eb4b4b',
  'Contraband': '#e4ae39',
};

function fnv(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0) / 4294967295;
}

function roundNice(v: number): number {
  if (v >= 50000) return Math.round(v / 1000) * 1000;
  if (v >= 5000) return Math.round(v / 100) * 100;
  if (v >= 1000) return Math.round(v / 50) * 50;
  if (v >= 300) return Math.round(v / 10) * 10;
  if (v >= 100) return Math.round(v / 5) * 5;
  return Math.max(1, Math.round(v));
}

export function priceFor(name: string, rarity: string, star: boolean, glove: boolean): number {
  const h = fnv(name);
  if (star && !glove) {
    // knives
    return roundNice(18000 + Math.pow(h, 1.35) * 520000);
  }
  const range = RARITY_PRICE[rarity] ?? [100, 1000];
  const v = range[0] + Math.pow(h, 1.25) * (range[1] - range[0]);
  return roundNice(v);
}

const isGlove = (weapon: string) => /gloves|wraps/i.test(weapon);

/* ------------------------------------------------------------------ */
/*  Normalisation of upstream API                                      */
/* ------------------------------------------------------------------ */

interface RawSkin {
  id?: string;
  name?: string;
  weapon?: { name?: string } | string;
  rarity?: { name?: string; color?: string } | string;
  image?: string;
}

function normalize(raw: RawSkin[]): Skin[] {
  const seen = new Set<string>();
  const out: Skin[] = [];
  for (const s of raw) {
    if (!s?.name || !s?.image) continue;
    if (seen.has(s.name)) continue;
    seen.add(s.name);
    const weapon = typeof s.weapon === 'object' ? (s.weapon?.name ?? '') : (s.weapon ?? '');
    const rarity = typeof s.rarity === 'object' ? (s.rarity?.name ?? 'Mil-Spec Grade') : (s.rarity ?? 'Mil-Spec Grade');
    const color = (typeof s.rarity === 'object' ? s.rarity?.color : undefined) ?? RARITY_FALLBACK_COLOR[rarity] ?? '#4b69ff';
    const star = s.name.startsWith('★');
    const glove = isGlove(weapon);
    void color; void glove;
    out.push({
      id: s.id ?? s.name,
      name: s.name,
      weapon,
      rarity,
      rarityRu: rarityRu(rarity),
      color: rarityColor(rarity),
      price: realPrice({ name: s.name, rarity, weapon }),
      image: s.image,
      star,
      cat: weaponCat(weapon, star),
      type: star ? (/gloves|wraps/i.test(weapon) ? 'glove' : 'knife') : 'skin',
    });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Built-in fallback (offline)                                        */
/* ------------------------------------------------------------------ */

const FALLBACK_RAW: Array<[string, string, string]> = [
  ['AK-47 | Redline', 'AK-47', 'Classified'],
  ['AK-47 | Asiimov', 'AK-47', 'Covert'],
  ['AK-47 | Neon Revolution', 'AK-47', 'Covert'],
  ['AK-47 | Elite Build', 'AK-47', 'Mil-Spec Grade'],
  ['AK-47 | Slate', 'AK-47', 'Restricted'],
  ['AWP | Asiimov', 'AWP', 'Covert'],
  ['AWP | Neo-Noir', 'AWP', 'Covert'],
  ['AWP | Atheris', 'AWP', 'Restricted'],
  ['AWP | Hyper Beast', 'AWP', 'Covert'],
  ['M4A4 | Asiimov', 'M4A4', 'Covert'],
  ['M4A4 | Neo-Noir', 'M4A4', 'Classified'],
  ['M4A1-S | Printstream', 'M4A1-S', 'Covert'],
  ['M4A1-S | Cyrex', 'M4A1-S', 'Classified'],
  ['Desert Eagle | Blaze', 'Desert Eagle', 'Restricted'],
  ['Desert Eagle | Printstream', 'Desert Eagle', 'Covert'],
  ['USP-S | Kill Confirmed', 'USP-S', 'Covert'],
  ['USP-S | Cyrex', 'USP-S', 'Restricted'],
  ['Glock-18 | Water Elemental', 'Glock-18', 'Classified'],
  ['P90 | Asiimov', 'P90', 'Covert'],
  ['SSG 08 | Dragonfire', 'SSG 08', 'Covert'],
  ['★ Karambit | Doppler', 'Karambit', 'Covert'],
  ['★ Bayonet | Fade', 'Bayonet', 'Covert'],
  ['★ Butterfly Knife | Tiger Tooth', 'Butterfly Knife', 'Covert'],
  ['★ Sport Gloves | Vice', 'Sport Gloves', 'Extraordinary'],
];

function fallbackDb(): Skin[] {
  return FALLBACK_RAW.map(([name, weapon, rarity]) => {
    const star = name.startsWith('★');
    const glove = isGlove(weapon);
    return {
      id: 'fb-' + name,
      name,
      weapon,
      rarity,
      rarityRu: RARITY_RU[rarity] ?? rarity,
      color: RARITY_FALLBACK_COLOR[rarity] ?? '#4b69ff',
      price: priceFor(name, rarity, star, glove),
      image: '',
      star,
    };
  }).map((s) => ({ ...s, price: s.image ? s.price : s.price }));
}

/* ------------------------------------------------------------------ */
/*  Loader with cache                                                  */
/* ------------------------------------------------------------------ */

const CACHE_KEY = 'upgrader-db-v2';
const SOURCES = [
  'https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins.json',
  'https://cdn.jsdelivr.net/gh/ByMykel/CSGO-API@main/public/api/en/skins.json',
];

/** fetch with a hard timeout — an APK/WebView must never hang on a dead network */
async function fetchWithTimeout(url: string, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { signal: ctrl.signal, cache: 'force-cache' });
  } finally {
    clearTimeout(timer);
  }
}

export async function loadSkins(onStep?: (msg: string) => void): Promise<Skin[]> {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached) as Skin[];
      if (Array.isArray(parsed) && parsed.length > 100) {
        onStep?.('База загружена из кэша');
        return parsed;
      }
    }
  } catch { /* storage may be blocked on file:// — ignore */ }

  const online = typeof navigator === 'undefined' || navigator.onLine !== false;
  if (online) {
    for (const url of SOURCES) {
      try {
        onStep?.('Загрузка базы скинов CS2…');
        const res = await fetchWithTimeout(url, 9000);
        if (!res.ok) continue;
        const raw = (await res.json()) as RawSkin[];
        const skins = normalize(raw);
        if (skins.length < 100) continue;
        try {
          localStorage.setItem(CACHE_KEY, JSON.stringify(skins));
        } catch { /* storage full or blocked — fine */ }
        onStep?.(`Загружено скинов: ${skins.length}`);
        return skins;
      } catch { /* timeout / CORS / offline — try the next source */ }
    }
  }

  onStep?.('Офлайн-режим: ограниченная база');
  return fallbackDb();
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

export const fmt = (n: number): string =>
  `${Math.round(n).toLocaleString('ru-RU')} ₽`;

export const fmtSign = (n: number): string =>
  `${n >= 0 ? '+' : '−'}${Math.abs(Math.round(n)).toLocaleString('ru-RU')} ₽`;
