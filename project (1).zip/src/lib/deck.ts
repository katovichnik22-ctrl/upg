import { secureRandom } from './rng';

export type Suit = 'S' | 'H' | 'D' | 'C';
export interface Card { r: string; s: Suit; id: string; }

export const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
export const SUITS: Suit[] = ['S', 'H', 'D', 'C'];

export const SUIT_CHAR: Record<Suit, string> = { S: '♠', H: '♥', D: '♦', C: '♣' };
export const isRed = (s: Suit) => s === 'H' || s === 'D';

/** Количество колод в шузе (как в казино) */
export const DECKS = 6;

/** Свежий шуз из DECKS колод */
export function freshShoe(decks = DECKS): Card[] {
  const out: Card[] = [];
  for (let d = 0; d < decks; d++) {
    for (const s of SUITS) {
      for (const r of RANKS) out.push({ r, s, id: `${r}${s}${d}` });
    }
  }
  return shuffle(out);
}

/** Честное перемешивание Фишера–Йетса на криптостойком генераторе */
export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(secureRandom() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Очки руки: туз считается 11, если не перебор */
export function score(hand: Card[]): number {
  let total = 0;
  let aces = 0;
  for (const c of hand) {
    if (c.r === 'A') { aces++; total += 11; }
    else if (c.r === 'J' || c.r === 'Q' || c.r === 'K') total += 10;
    else total += Number(c.r);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

/** Мягкая рука: туз всё ещё считается за 11 */
export function isSoft(hand: Card[]): boolean {
  let total = 0;
  let aces = 0;
  for (const c of hand) {
    if (c.r === 'A') { aces++; total += 11; }
    else if (['J', 'Q', 'K'].includes(c.r)) total += 10;
    else total += Number(c.r);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return aces > 0 && total <= 21;
}

export const isBlackjack = (h: Card[]) => h.length === 2 && score(h) === 21;
export const isPair = (h: Card[]) =>
  h.length === 2 && cardValue(h[0]) === cardValue(h[1]);

export function cardValue(c: Card): number {
  if (c.r === 'A') return 11;
  if (['J', 'Q', 'K'].includes(c.r)) return 10;
  return Number(c.r);
}
