import { freshShoe, shuffle, RANKS, SUITS, score, type Card } from './deck';

/**
 * DEV-проверка честности перемешивания.
 * Проверяем равномерность позиций карт и распределение первой карты.
 */
export function testShuffleFairness(n = 100000): void {
  /* 1. Позиционная равномерность на колоде из 52 карт */
  const deck: Card[] = [];
  for (const s of SUITS) for (const r of RANKS) deck.push({ r, s, id: `${r}${s}` });

  const posSum: Record<string, number> = {};
  const firstCard: Record<string, number> = {};
  for (let i = 0; i < n; i++) {
    const sh = shuffle(deck);
    for (let p = 0; p < sh.length; p++) {
      const k = sh[p].id;
      posSum[k] = (posSum[k] ?? 0) + p;
    }
    firstCard[sh[0].id] = (firstCard[sh[0].id] ?? 0) + 1;
  }

  const expectedPos = (deck.length - 1) / 2;
  const avgs = Object.entries(posSum).map(([k, v]) => ({ k, avg: v / n }));
  avgs.sort((a, b) => a.avg - b.avg);
  const worst = Math.max(
    Math.abs(avgs[0].avg - expectedPos),
    Math.abs(avgs[avgs.length - 1].avg - expectedPos),
  );

  const firsts = Object.values(firstCard);
  const expFirst = n / 52;
  const minF = Math.min(...firsts), maxF = Math.max(...firsts);

  /* 2. Распределение очков стартовой руки из реального шуза */
  const scores: Record<number, number> = {};
  let bj = 0;
  const rounds = Math.min(n, 50000);
  for (let i = 0; i < rounds; i++) {
    const shoe = freshShoe();
    const hand = [shoe[0], shoe[1]];
    const sc = score(hand);
    scores[sc] = (scores[sc] ?? 0) + 1;
    if (sc === 21) bj++;
  }
  const bjRate = (bj / rounds) * 100;

  /* eslint-disable no-console */
  console.log(`%c🃏 Тест перемешивания — ${n.toLocaleString('ru')} прогонов`,
    'color:#4ade80;font-weight:bold');
  console.log(`Средняя позиция карты: ожидание ${expectedPos.toFixed(1)}, макс. отклонение ${worst.toFixed(3)}`);
  console.log(`Первая карта: ожидание ${expFirst.toFixed(0)} раз, реально ${minF}..${maxF}`);
  console.log(`Блэкджек на старте: ${bjRate.toFixed(2)}%  (теория ~4.75% для 6 колод)`);
  const ok = worst < 0.25 && bjRate > 4.0 && bjRate < 5.6;
  console.log(ok
    ? '%c✅ перемешивание честное и равномерное'
    : '%c⚠️ проверьте генератор', ok ? 'color:#4ade80' : 'color:#ff6b7d');
  /* eslint-enable no-console */
}

export const IS_DEV = typeof location !== 'undefined'
  && location.hostname === 'localhost' && location.port !== '';

if (IS_DEV && typeof window !== 'undefined') {
  (window as unknown as { testShuffleFairness: typeof testShuffleFairness })
    .testShuffleFairness = testShuffleFairness;
}
