import { SYMBOLS } from '../data/slotSymbols';

/** Предзагрузка символов слотов, чтобы не подгружались во время спина */
let started = false;

export function preloadSlotSymbols(): void {
  if (started || typeof window === 'undefined') return;
  started = true;
  /* грузим в простое, не мешая первому рендеру */
  const run = () => {
    for (const def of Object.values(SYMBOLS)) {
      const img = new Image();
      img.decoding = 'async';
      img.src = def.image;
    }
  };
  const ric = (window as unknown as {
    requestIdleCallback?: (cb: () => void) => number;
  }).requestIdleCallback;
  if (ric) ric(run); else window.setTimeout(run, 800);
}
