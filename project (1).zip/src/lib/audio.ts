/* Tiny WebAudio synth — no external assets needed */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let enabled = true;
let volume = 0.6;

function ensure(): AudioContext | null {
  if (!enabled) return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = volume;
      master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

export const audio = {
  setEnabled(v: boolean) { enabled = v; },
  setVolume(v: number) {
    volume = v;
    if (master) master.gain.value = v;
  },

  blip(freq: number, dur = 0.06, type: OscillatorType = 'square', gain = 0.12, slideTo?: number) {
    const c = ensure();
    if (!c || !master) return;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, c.currentTime);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime + dur);
    g.gain.setValueAtTime(gain, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    o.connect(g).connect(master);
    o.start();
    o.stop(c.currentTime + dur + 0.02);
  },

  click() { this.blip(1500, 0.04, 'square', 0.06); },
  hover() { this.blip(2600, 0.02, 'square', 0.02); },
  tick() { this.blip(1900 + Math.random() * 500, 0.025, 'square', 0.05); },
  reelTick() { this.blip(900 + Math.random() * 250, 0.03, 'square', 0.07); },
  coin() {
    this.blip(1300, 0.09, 'triangle', 0.12);
    setTimeout(() => this.blip(1950, 0.12, 'triangle', 0.1), 70);
  },
  win() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => setTimeout(() => this.blip(n, 0.22, 'triangle', 0.14), i * 95));
    setTimeout(() => this.blip(1318.5, 0.4, 'triangle', 0.12), notes.length * 95);
  },
  bigWin() {
    const notes = [392, 523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98];
    notes.forEach((n, i) => setTimeout(() => this.blip(n, 0.25, 'triangle', 0.14), i * 85));
  },
  lose() {
    this.blip(300, 0.35, 'sawtooth', 0.09, 90);
    setTimeout(() => this.blip(160, 0.4, 'sawtooth', 0.07, 60), 140);
  },
};
