import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { HistoryItem, OwnedSkin, Settings, Skin, Stats, Toast, ToastType } from './types';
import { audio } from './audio';
import { loadSkins, priceFor } from './skins';
import { loadMarketItems } from '../data/marketItems';

/* ================= skins database context ================= */

interface SkinsCtx {
  skins: Skin[];
  /** весь маркет: скины + наклейки + музыка + кейсы/агенты/брелоки */
  catalog: Skin[];
  byName: Map<string, Skin>;
  loading: boolean;
  step: string;
}
const SkinsContext = createContext<SkinsCtx>({ skins: [], catalog: [], byName: new Map(), loading: true, step: '' });

export function SkinsProvider({ children }: { children: React.ReactNode }) {
  const [skins, setSkins] = useState<Skin[]>([]);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState('Подключение…');

  useEffect(() => {
    let alive = true;
    const t0 = Date.now();
    loadSkins(setStep).then(async (s) => {
      const wait = Math.max(0, 900 - (Date.now() - t0));
      await new Promise((r) => setTimeout(r, wait));
      if (!alive) return;
      setSkins(s);
      setLoading(false);
    });
    return () => { alive = false; };
  }, []);

  const byName = useMemo(() => {
    const m = new Map<string, Skin>();
    for (const s of skins) m.set(s.name, s);
    return m;
  }, [skins]);

  /* наклейки, брелоки, контейнеры и прочее — с картинками Steam CDN */
  const [extra, setExtra] = useState<Skin[]>([]);
  useEffect(() => {
    let alive = true;
    loadMarketItems().then((items) => { if (alive) setExtra(items); });
    return () => { alive = false; };
  }, []);

  const catalog = useMemo<Skin[]>(() => [...skins, ...extra], [skins, extra]);

  return (
    <SkinsContext.Provider value={{ skins, catalog, byName, loading, step }}>
      {children}
    </SkinsContext.Provider>
  );
}
export const useSkins = () => useContext(SkinsContext);

/** Merge stored item with live DB (fresh image / price). */
export function useEnrich<T extends Skin>(item: T | null | undefined): T | null {
  const { byName } = useSkins();
  if (!item) return null;
  const live = byName.get(item.name);
  if (!live) return item;
  return { ...item, ...live, uid: (item as unknown as OwnedSkin).uid } as T;
}

/* ================= game state ================= */

const SAVE_KEY = 'upgrader-save-v2';

/** Режим экономики выбирается один раз при создании профиля */
/** Донат убран: единственный режим — честный кликер */
export type Economy = 'clicker';

/** Состояние кликера (хранится вместе с профилем) */
export interface ClickerState {
  coins: number;
  energy: number;
  maxEnergy: number;
  perClick: number;
  regen: number;      // энергии в секунду
  auto: number;       // монет в секунду пассивно
  critChance: number; // 0..1
  critMult: number;
  totalClicks: number;
  upgrades: Record<string, number>;
  lastSeen: number;
  streak: number;
  lastDaily: string;
  tasksDone: string[];
}

export const defaultClicker = (): ClickerState => ({
  coins: 0,
  energy: 100,
  maxEnergy: 100,
  perClick: 1,
  regen: 1,
  auto: 0,
  critChance: 0,
  critMult: 2,
  totalClicks: 0,
  upgrades: {},
  lastSeen: Date.now(),
  streak: 0,
  lastDaily: '',
  tasksDone: [],
});

interface Persist {
  balance: number;
  inventory: OwnedSkin[];
  history: HistoryItem[];
  stats: Stats;
  settings: Settings;
  name: string;
  lastBonus: string;
  economy: Economy;
  /** режим экономики подтверждён игроком */
  economySet: boolean;
  clicker: ClickerState;
  unlockedSlots: string[];
}

const STARTERS: Array<[string, string]> = [
  ['Glock-18 | Water Elemental', 'Classified'],
  ['USP-S | Cyrex', 'Restricted'],
  ['AK-47 | Elite Build', 'Mil-Spec Grade'],
  ['AWP | Atheris', 'Restricted'],
];

/** Инвентарь нового профиля пуст. Демо-набор — только в разработке. */
const __DEV__ = typeof location !== 'undefined'
  && location.hostname === 'localhost' && location.port !== '';

function mkStarter(): OwnedSkin[] {
  if (!__DEV__) return [];
  return STARTERS.map(([name, rarity], i) => ({
    uid: 'start-' + i,
    id: 'start-' + i,
    name,
    weapon: name.split(' | ')[0],
    rarity,
    rarityRu: '',
    color: '#4b69ff',
    price: priceFor(name, rarity, false, false),
    image: '',
    star: false,
  }));
}

const defaultPersist = (): Persist => ({
  balance: 1000,
  inventory: mkStarter(),
  history: [],
  stats: { upgrades: 0, upgradeWins: 0, rouletteSpins: 0, rouletteWins: 0, wagered: 0, earned: 0, bestWin: 0, casesOpened: 0, gamesPlayed: 0, gameWins: 0, deposited: 0 },
  settings: { sound: true, volume: 0.6, fast: false, view: 'auto', lite: false },
  name: 'Игрок',
  lastBonus: '',
  economy: 'clicker',
  economySet: false,
  clicker: defaultClicker(),
  unlockedSlots: [],
});

/* ---------------- profiles ---------------- */

export interface ProfileMeta {
  id: string;
  name: string;
  created: number;
}

const PROFILES_KEY = 'nikgrager-profiles-v1';
const profileKey = (id: string) => `${SAVE_KEY}::${id}`;

interface ProfileIndex {
  active: string;
  list: ProfileMeta[];
}

function readProfiles(): ProfileIndex {
  try {
    const raw = localStorage.getItem(PROFILES_KEY);
    if (raw) {
      const idx = JSON.parse(raw) as ProfileIndex;
      if (idx?.list?.length) return idx;
    }
  } catch { /* fall through to migration */ }

  /* first run — migrate any legacy single save into profile #1 */
  const id = 'p1';
  let name = 'Игрок';
  try {
    const legacy = localStorage.getItem(SAVE_KEY);
    if (legacy) {
      localStorage.setItem(profileKey(id), legacy);
      const parsed = JSON.parse(legacy) as Partial<Persist>;
      if (parsed?.name) name = parsed.name;
      localStorage.removeItem(SAVE_KEY);
    }
  } catch { /* ignore */ }

  const idx: ProfileIndex = { active: id, list: [{ id, name, created: Date.now() }] };
  try { localStorage.setItem(PROFILES_KEY, JSON.stringify(idx)); } catch { /* ignore */ }
  return idx;
}

function writeProfiles(idx: ProfileIndex) {
  try { localStorage.setItem(PROFILES_KEY, JSON.stringify(idx)); } catch { /* ignore */ }
}

function loadPersist(id: string): Persist {
  try {
    const raw = localStorage.getItem(profileKey(id));
    if (!raw) return defaultPersist();
    const d = { ...defaultPersist(), ...JSON.parse(raw) };
    d.stats = { ...defaultPersist().stats, ...d.stats };
    d.settings = { ...defaultPersist().settings, ...d.settings };
    d.clicker = { ...defaultClicker(), ...d.clicker };
    if (!Array.isArray(d.unlockedSlots)) d.unlockedSlots = [];
    return d;
  } catch {
    return defaultPersist();
  }
}

interface GameCtx {
  state: Persist;
  toasts: Toast[];
  depositOpen: boolean;
  setDepositOpen: (v: boolean) => void;
  profiles: ProfileMeta[];
  activeProfile: string;
  switchProfile: (id: string) => void;
  createProfile: (name: string, economy?: Economy) => void;
  deleteProfile: (id: string) => void;
  /** режим экономики текущего профиля */
  economy: Economy;
  setClicker: (p: Partial<ClickerState> | ((c: ClickerState) => Partial<ClickerState>)) => void;
  unlockSlot: (id: string) => void;
  adjust: (n: number) => void;
  canAfford: (n: number) => boolean;
  addItem: (s: Skin) => OwnedSkin;
  removeItem: (uid: string) => OwnedSkin | undefined;
  sellItem: (uid: string) => void;
  sellAll: () => void;
  log: (h: Omit<HistoryItem, 'id' | 'time'>) => void;
  addStats: (p: Partial<Stats>) => void;
  setSettings: (p: Partial<Settings>) => void;
  setName: (n: string) => void;
  claimBonus: () => boolean;
  reset: () => void;
  toast: (text: string, type?: ToastType, sub?: string) => void;
}

const GameContext = createContext<GameCtx>(null as unknown as GameCtx);

let uidCounter = 0;
export const uid = () => `u${Date.now().toString(36)}${(uidCounter++).toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`;

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [index, setIndex] = useState<ProfileIndex>(readProfiles);
  const [state, setState] = useState<Persist>(() => loadPersist(readProfiles().active));
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [depositOpen, setDepositOpen] = useState(false);
  const toastId = useRef(0);

  const activeProfile = index.active;

  useEffect(() => {
    try { localStorage.setItem(profileKey(activeProfile), JSON.stringify(state)); } catch { /* ignore */ }
  }, [state, activeProfile]);

  /* keep the profile label in sync with the in-game nickname */
  useEffect(() => {
    setIndex((idx) => {
      const cur = idx.list.find((p) => p.id === idx.active);
      if (!cur || cur.name === state.name) return idx;
      const next = { ...idx, list: idx.list.map((p) => (p.id === idx.active ? { ...p, name: state.name } : p)) };
      writeProfiles(next);
      return next;
    });
  }, [state.name]);

  useEffect(() => {
    audio.setEnabled(state.settings.sound);
    audio.setVolume(state.settings.volume);
  }, [state.settings.sound, state.settings.volume]);

  const toast = useCallback((text: string, type: ToastType = 'info', sub?: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-4), { id, text, type, sub }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3400);
  }, []);

  const adjust = useCallback((n: number) => {
    setState((s) => ({ ...s, balance: Math.max(0, Math.round(s.balance + n)) }));
  }, []);

  const canAfford = useCallback((n: number) => state.balance >= n, [state.balance]);

  const addItem = useCallback((s: Skin): OwnedSkin => {
    const item: OwnedSkin = { ...s, uid: uid() };
    setState((st) => ({ ...st, inventory: [item, ...st.inventory] }));
    return item;
  }, []);

  const removeItem = useCallback((uidv: string): OwnedSkin | undefined => {
    let found: OwnedSkin | undefined;
    setState((st) => {
      found = st.inventory.find((i) => i.uid === uidv);
      return { ...st, inventory: st.inventory.filter((i) => i.uid !== uidv) };
    });
    return found;
  }, []);

  const log = useCallback((h: Omit<HistoryItem, 'id' | 'time'>) => {
    setState((st) => ({
      ...st,
      history: [{ ...h, id: uid(), time: Date.now() }, ...st.history].slice(0, 60),
    }));
  }, []);

  const addStats = useCallback((p: Partial<Stats>) => {
    setState((st) => {
      const stats = { ...st.stats } as Record<string, number>;
      for (const k of Object.keys(p)) stats[k] = (stats[k] ?? 0) + (p as Record<string, number>)[k];
      return { ...st, stats: stats as unknown as Stats };
    });
  }, []);

  const sellItem = useCallback((uidv: string) => {
    setState((st) => {
      const item = st.inventory.find((i) => i.uid === uidv);
      if (!item) return st;
      const val = Math.max(1, Math.round(item.price * 0.94));
      return {
        ...st,
        balance: st.balance + val,
        inventory: st.inventory.filter((i) => i.uid !== uidv),
        history: [{ id: uid(), time: Date.now(), kind: 'sell' as const, text: `Продан ${item.name}`, amount: val }, ...st.history].slice(0, 60),
      };
    });
    audio.coin();
  }, []);

  const sellAll = useCallback(() => {
    setState((st) => {
      if (st.inventory.length === 0) return st;
      const total = st.inventory.reduce((a, i) => a + Math.max(1, Math.round(i.price * 0.94)), 0);
      return {
        ...st,
        balance: st.balance + total,
        inventory: [],
        history: [{ id: uid(), time: Date.now(), kind: 'sell' as const, text: `Продано предметов: ${st.inventory.length}`, amount: total }, ...st.history].slice(0, 60),
      };
    });
    audio.coin();
  }, []);

  const setSettings = useCallback((p: Partial<Settings>) => {
    setState((st) => ({ ...st, settings: { ...st.settings, ...p } }));
  }, []);

  const setName = useCallback((n: string) => {
    setState((st) => ({ ...st, name: n.slice(0, 18) || 'Игрок' }));
  }, []);

  const claimBonus = useCallback((): boolean => {
    const today = new Date().toDateString();
    if (state.lastBonus === today) return false;
    setState((st) => ({
      ...st,
      balance: st.balance + 500,
      lastBonus: today,
      history: [{ id: uid(), time: Date.now(), kind: 'bonus' as const, text: 'Ежедневный бонус', amount: 500 }, ...st.history].slice(0, 60),
    }));
    audio.coin();
    return true;
  }, [state.lastBonus]);

  const reset = useCallback(() => {
    const d = defaultPersist();
    d.name = state.name;
    setState(d);
    try { localStorage.removeItem(profileKey(activeProfile)); } catch { /* ignore */ }
  }, [activeProfile, state.name]);

  /* ---------------- profile actions ---------------- */

  const switchProfile = useCallback((id: string) => {
    setIndex((idx) => {
      if (!idx.list.some((p) => p.id === id) || idx.active === id) return idx;
      const next = { ...idx, active: id };
      writeProfiles(next);
      /* load synchronously so the save effect never writes stale data */
      setState(loadPersist(id));
      return next;
    });
  }, []);

  const createProfile = useCallback((name: string, economy: Economy = 'clicker') => {
    const id = `p${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`;
    const clean = name.trim().slice(0, 18) || 'Игрок';
    const fresh = defaultPersist();
    fresh.name = clean;
    fresh.economy = economy;
    fresh.economySet = true;
    /* честный кликер стартует без стартового баланса */
    if (economy === 'clicker') fresh.balance = 0;
    try { localStorage.setItem(profileKey(id), JSON.stringify(fresh)); } catch { /* ignore */ }
    setIndex((idx) => {
      const next: ProfileIndex = {
        active: id,
        list: [...idx.list, { id, name: clean, created: Date.now() }],
      };
      writeProfiles(next);
      setState(fresh);
      return next;
    });
  }, []);

  const deleteProfile = useCallback((id: string) => {
    setIndex((idx) => {
      if (idx.list.length <= 1) return idx; // never delete the last one
      const list = idx.list.filter((p) => p.id !== id);
      const active = idx.active === id ? list[0].id : idx.active;
      const next: ProfileIndex = { active, list };
      writeProfiles(next);
      try { localStorage.removeItem(profileKey(id)); } catch { /* ignore */ }
      if (idx.active === id) setState(loadPersist(active));
      return next;
    });
  }, []);

  const setClicker = useCallback(
    (p: Partial<ClickerState> | ((c: ClickerState) => Partial<ClickerState>)) => {
      setState((st) => {
        const patch = typeof p === 'function' ? p(st.clicker) : p;
        return { ...st, clicker: { ...st.clicker, ...patch } };
      });
    },
    [],
  );

  const unlockSlot = useCallback((id: string) => {
    setState((st) =>
      st.unlockedSlots.includes(id)
        ? st
        : { ...st, unlockedSlots: [...st.unlockedSlots, id] },
    );
  }, []);

  const value = useMemo<GameCtx>(() => ({
    state, toasts, depositOpen, setDepositOpen, adjust, canAfford, addItem, removeItem, sellItem, sellAll,
    log, addStats, setSettings, setName, claimBonus, reset, toast,
    profiles: index.list, activeProfile, switchProfile, createProfile, deleteProfile,
    economy: state.economy, setClicker, unlockSlot,
  }), [state, toasts, depositOpen, adjust, canAfford, addItem, removeItem, sellItem, sellAll, log, addStats,
    setSettings, setName, claimBonus, reset, toast,
    index.list, activeProfile, switchProfile, createProfile, deleteProfile, setClicker, unlockSlot]);

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export const useGame = () => useContext(GameContext);
