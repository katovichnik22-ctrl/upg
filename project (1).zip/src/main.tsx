import React, { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import "./lib/rouletteFairness"; // DEV: window.testRouletteFairness()
import "./lib/fishingFairness";  // DEV: window.testFishingRTP()
import "./lib/deckFairness";     // DEV: window.testShuffleFairness()

/** Any render crash must show text, never a black screen (critical inside APK). */
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24 }}>
        <div style={{ maxWidth: 360, textAlign: "center", color: "#c4cdf0" }}>
          <div style={{ fontSize: 34, marginBottom: 10 }}>⚠️</div>
          <h1 style={{ fontSize: 17, fontWeight: 800, color: "#fff", margin: "0 0 8px" }}>
            Что-то пошло не так
          </h1>
          <p style={{ fontSize: 12.5, lineHeight: 1.6, color: "#8a94b8", margin: "0 0 16px" }}>
            {error.message || "Неизвестная ошибка"}
          </p>
          <button
            onClick={() => {
              try {
                localStorage.removeItem("upgrader-save-v2");
                localStorage.removeItem("upgrader-db-v2");
              } catch {
                /* storage unavailable */
              }
              location.reload();
            }}
            style={{
              background: "linear-gradient(180deg,#ffd964,#e8a013)",
              color: "#241a02",
              border: 0,
              borderRadius: 12,
              padding: "12px 22px",
              fontWeight: 800,
              fontSize: 13,
              cursor: "pointer",
            }}
          >
            Сбросить и перезапустить
          </button>
        </div>
      </div>
    );
  }
}

function removeBootSplash() {
  const boot = document.getElementById("boot");
  if (boot && boot.parentNode) boot.parentNode.removeChild(boot);
}

const container = document.getElementById("root");
if (container) {
  const tree = (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
  /* StrictMode удваивает рендеры — оставляем только в разработке */
  const isDev = location.port !== '' && location.hostname === 'localhost';
  createRoot(container).render(isDev ? <StrictMode>{tree}</StrictMode> : tree);
  // React has taken over — hide the static splash
  requestAnimationFrame(removeBootSplash);
  setTimeout(removeBootSplash, 600);
}
