import type { RarityInfo, Wear } from '../types/items';

/** Редкости CS2 с официальными цветами */
export const RARITIES: RarityInfo[] = [
  { id: 'consumer',      api: 'Consumer Grade',   ru: 'Ширпотреб',        color: '#b0c3d9' },
  { id: 'industrial',    api: 'Industrial Grade', ru: 'Промышленное',     color: '#5e98d9' },
  { id: 'milspec',       api: 'Mil-Spec Grade',   ru: 'Армейское',        color: '#4b69ff' },
  { id: 'restricted',    api: 'Restricted',       ru: 'Запрещённое',      color: '#8847ff' },
  { id: 'classified',    api: 'Classified',       ru: 'Засекреченное',    color: '#d32ce6' },
  { id: 'covert',        api: 'Covert',           ru: 'Тайное',           color: '#eb4b4b' },
  { id: 'extraordinary', api: 'Extraordinary',    ru: 'Экстраординарное', color: '#eb4b4b' },
  { id: 'contraband',    api: 'Contraband',       ru: 'Контрабанда',      color: '#e4ae39' },
];

const byApi = new Map(RARITIES.map((r) => [r.api, r]));

export const rarityInfo = (api: string): RarityInfo =>
  byApi.get(api) ?? RARITIES[2];

export const rarityRu = (api: string) => rarityInfo(api).ru;
export const rarityColor = (api: string) => rarityInfo(api).color;

/** Износы: множитель к базовой цене (FN) и русское имя */
export const WEARS: Array<{ id: Wear; ru: string; short: string; mult: number }> = [
  { id: 'FN', ru: 'Прямо с завода',   short: 'FN', mult: 1.00 },
  { id: 'MW', ru: 'Немного поношенное', short: 'MW', mult: 0.74 },
  { id: 'FT', ru: 'После полевых',    short: 'FT', mult: 0.47 },
  { id: 'WW', ru: 'Поношенное',       short: 'WW', mult: 0.40 },
  { id: 'BS', ru: 'Закалённое в боях', short: 'BS', mult: 0.34 },
];

export const wearInfo = (w: Wear) => WEARS.find((x) => x.id === w) ?? WEARS[0];

/** StatTrak™ обычно дороже обычного варианта */
export const STATTRAK_MULT = 1.55;
/** Сувенирные — дешевле обычных (кроме топовых), берём усреднённо */
export const SOUVENIR_MULT = 0.85;
