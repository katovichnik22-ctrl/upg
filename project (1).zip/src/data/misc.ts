import type { MarketItem } from '../types/items';
import { rarityColor, rarityRu } from './rarity';

/** Кейсы, капсулы, графити, брелоки, агенты — цены (₽) */
const CASES: Array<[string, number]> = [
  ['Operation Bravo Case', 32000],
  ['Operation Vanguard Weapon Case', 780],
  ['Operation Breakout Weapon Case', 1250],
  ['Operation Phoenix Weapon Case', 980],
  ['Huntsman Weapon Case', 640],
  ['CS:GO Weapon Case', 28000],
  ['CS:GO Weapon Case 2', 12000],
  ['CS:GO Weapon Case 3', 3400],
  ['eSports 2013 Case', 9200],
  ['eSports 2013 Winter Case', 6400],
  ['eSports 2014 Summer Case', 2400],
  ['Winter Offensive Weapon Case', 620],
  ['Revolver Case', 62],
  ['Shadow Case', 78],
  ['Falchion Case', 72],
  ['Chroma Case', 180],
  ['Chroma 2 Case', 220],
  ['Chroma 3 Case', 92],
  ['Gamma Case', 140],
  ['Gamma 2 Case', 160],
  ['Glove Case', 340],
  ['Spectrum Case', 120],
  ['Spectrum 2 Case', 260],
  ['Clutch Case', 42],
  ['Horizon Case', 58],
  ['Danger Zone Case', 38],
  ['Prisma Case', 34],
  ['Prisma 2 Case', 46],
  ['CS20 Case', 54],
  ['Shattered Web Case', 88],
  ['Fracture Case', 26],
  ['Operation Broken Fang Case', 240],
  ['Snakebite Case', 22],
  ['Operation Riptide Case', 210],
  ['Dreams & Nightmares Case', 96],
  ['Recoil Case', 32],
  ['Revolution Case', 44],
  ['Kilowatt Case', 68],
  ['Gallery Case', 74],
  ['Fever Case', 52],
];

const CAPSULES: Array<[string, number]> = [
  ['Katowice 2014 Legends Capsule', 145000],
  ['Cologne 2014 Legends Capsule', 34000],
  ['Katowice 2015 Legends Capsule', 8600],
  ['Boston 2018 Legends Capsule', 780],
  ['Berlin 2019 Legends Capsule', 420],
  ['Stockholm 2021 Legends Capsule', 340],
  ['Antwerp 2022 Legends Capsule', 280],
  ['Rio 2022 Legends Capsule', 240],
  ['Paris 2023 Legends Capsule', 210],
  ['Copenhagen 2024 Legends Capsule', 180],
  ['Shanghai 2024 Legends Capsule', 160],
  ['Community Sticker Capsule 1', 120],
  ['Sticker Capsule 2', 240],
  ['Chicken Capsule', 96],
  ['Pinups Capsule', 140],
  ['Slid3 Capsule', 110],
];

const AGENTS: Array<[string, number, string]> = [
  ['Sir Bloody Miami Darryl | The Professionals', 3400, 'Covert'],
  ['Sir Bloody Darryl Royale | The Professionals', 2800, 'Covert'],
  ['Bloody Darryl The Strapped | The Professionals', 2600, 'Covert'],
  ['Sir Bloody Skullhead Darryl | The Professionals', 2400, 'Covert'],
  ['Special Agent Ava | FBI', 1650, 'Covert'],
  ['\u2018Two Times\u2019 McCoy | USAF TACP', 980, 'Classified'],
  ['Cmdr. Mae \u2018Dead Cold\u2019 Jamison | SWAT', 1450, 'Covert'],
  ['Lt. Commander Ricksaw | NSWC SEAL', 620, 'Classified'],
  ['Chem-Haz Capitaine | Gendarmerie Nationale', 1250, 'Covert'],
  ['Primeiro Tenente | Brazilian 1st Battalion', 780, 'Classified'],
  ['Getaway Sally', 420, 'Restricted'],
  ['Number K | Sabre', 340, 'Restricted'],
  ['Blackwolf | Sabre', 380, 'Restricted'],
  ['The Doctor Romanov | Sabre', 1100, 'Classified'],
  ['Osiris | Elite Crew', 560, 'Classified'],
  ['Street Soldier | Phoenix', 320, 'Restricted'],
  ['Enforcer | Phoenix', 280, 'Restricted'],
  ['Slingshot | Phoenix', 240, 'Restricted'],
  ['Arno The Overgrown | Guerrilla Warfare', 420, 'Restricted'],
  ['Rezan The Ready | Sabre', 640, 'Classified'],
];

const GRAFFITI: Array<[string, number]> = [
  ['Sealed Graffiti | Recoil AK-47', 48],
  ['Sealed Graffiti | Recoil AWP', 62],
  ['Sealed Graffiti | Chicken', 18],
  ['Sealed Graffiti | Kawaii Killer CT', 34],
  ['Sealed Graffiti | Rage Mode', 22],
  ['Sealed Graffiti | GGWP', 16],
  ['Sealed Graffiti | Backstabber', 28],
  ['Sealed Graffiti | Crown', 44],
  ['Sealed Graffiti | Hostage Rescue', 20],
  ['Sealed Graffiti | X-Ray', 26],
];

const CHARMS: Array<[string, number]> = [
  ['Charm | Hot Howl', 18000],
  ['Charm | Baby Karat T', 9200],
  ['Charm | Baby Karat CT', 8600],
  ['Charm | Hot Wurst', 2400],
  ['Charm | Diamond Dog', 4200],
  ['Charm | Titeenium AWP', 1650],
  ['Charm | Lil\u2019 Crass', 780],
  ['Charm | Semi-Precious', 3400],
  ['Charm | Die-cast AK', 1250],
  ['Charm | Glamour Shot', 640],
  ['Charm | Pocket AWP', 980],
  ['Charm | Backsplash', 420],
  ['Charm | Lil\u2019 Squirt', 340],
  ['Charm | Big Kev', 520],
  ['Charm | Whittle Knife', 1450],
];

function item(
  name: string, price: number, rarity: string,
  type: MarketItem['type'], weapon: string,
): MarketItem {
  return {
    id: `${type}-${name}`,
    name,
    weapon,
    type,
    cat: 'other',
    rarity,
    rarityRu: rarityRu(rarity),
    color: rarityColor(rarity),
    price,
    image: '',
    star: false,
  };
}

/** Кейсы / капсулы / графити / брелоки / агенты одним списком */
export function buildMisc(): MarketItem[] {
  const out: MarketItem[] = [];
  for (const [n, p] of CASES) {
    out.push(item(n, p, p > 5000 ? 'Classified' : p > 500 ? 'Restricted' : 'Mil-Spec Grade', 'case', 'Контейнер'));
  }
  for (const [n, p] of CAPSULES) {
    out.push(item(n, p, p > 5000 ? 'Classified' : p > 400 ? 'Restricted' : 'Mil-Spec Grade', 'capsule', 'Капсула'));
  }
  for (const [n, p, r] of AGENTS) out.push(item(n, p, r, 'agent', 'Агент'));
  for (const [n, p] of GRAFFITI) out.push(item(n, p, 'Consumer Grade', 'graffiti', 'Граффити'));
  for (const [n, p] of CHARMS) {
    out.push(item(n, p, p > 5000 ? 'Covert' : p > 1000 ? 'Classified' : 'Restricted', 'charm', 'Брелок'));
  }
  return out;
}

export const ITEM_TYPES: Array<{ id: MarketItem['type'] | 'all'; label: string }> = [
  { id: 'all', label: 'Всё' },
  { id: 'skin', label: 'Скины' },
  { id: 'sticker', label: 'Наклейки' },
  { id: 'music', label: 'Музыка' },
  { id: 'case', label: 'Кейсы' },
  { id: 'capsule', label: 'Капсулы' },
  { id: 'agent', label: 'Агенты' },
  { id: 'charm', label: 'Брелоки' },
  { id: 'graffiti', label: 'Граффити' },
];
