import type { Skin } from '../lib/types';
import { rarityColor, rarityRu } from './rarity';
import {
  STICKER_PRICES, STICKER_EVENT_BASE, STICKER_VARIANT_MULT,
  CHARM_PRICES, CRATE_PRICES, CAPSULE_PRICES, AGENT_PRICES,
  MUSIC_PRICES, MUSIC_ST_MULT, GRAFFITI_PRICES, GRAFFITI_BASE,
} from './marketPrices';

/** Сырой элемент из открытого API каталога CS2 */
interface RawItem {
  id?: string;
  name?: string;
  market_hash_name?: string;
  rarity?: { name?: string } | string;
  image?: string;
  tournament?: { name?: string } | string | null;
  type?: string | null;
  effect?: string | null;
}

const API = 'https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en';
const SOURCES = {
  stickers: `${API}/stickers.json`,
  keychains: `${API}/keychains.json`,
  crates: `${API}/crates.json`,
  agents: `${API}/agents.json`,
  graffiti: `${API}/graffiti.json`,
  musicKits: `${API}/music_kits.json`,
};

const rarityOf = (r: RawItem['rarity']): string =>
  (typeof r === 'object' ? r?.name : r) ?? 'Mil-Spec Grade';

function round(v: number): number {
  if (v >= 100_000) return Math.round(v / 1000) * 1000;
  if (v >= 10_000) return Math.round(v / 100) * 100;
  if (v >= 1_000) return Math.round(v / 10) * 10;
  if (v >= 100) return Math.round(v);
  return Math.max(3, Math.round(v * 10) / 10);
}

/** Детерминированный разброс ±18%, чтобы однотипные позиции не были клонами */
function jitter(name: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < name.length; i++) { h ^= name.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return 0.82 + ((h >>> 0) / 4294967295) * 0.36;
}

/* ---------- цены по категориям ---------- */

const tourName = (t: RawItem['tournament']): string =>
  (typeof t === 'object' && t ? t.name ?? '' : (t as string) ?? '');

function stickerPrice(name: string, tournament?: RawItem['tournament'], effect?: string | null): number {
  const exact = STICKER_PRICES[name];
  if (exact) return exact;

  /* базу берём по турниру, иначе общая community-наклейка */
  const tn = tourName(tournament);
  let base = 24;
  for (const [ev, p] of Object.entries(STICKER_EVENT_BASE)) {
    /* сопоставляем по году и городу: «2019 IEM Katowice» ↔ «Katowice 2019» */
    const [city, year] = ev.split(' ');
    if (name.includes(ev) || (tn.includes(city) && tn.includes(year))) { base = p; break; }
  }
  /* вариант: Holo / Foil / Gold и т.п. */
  let mult = 1;
  for (const [key, m] of Object.entries(STICKER_VARIANT_MULT)) {
    if (key && (name.includes(`(${key})`) || effect === key)) { mult = Math.max(mult, m); }
  }
  /* автограф игрока дороже командной */
  if (/\|\s*[A-Za-z0-9_]+\s*\|/.test(name) && tn) mult *= 1.4;
  return round(base * mult * jitter(name));
}

const priceFromTable = (
  table: Record<string, number>, name: string, fallback: number,
): number => table[name] ?? round(fallback * jitter(name));

/* ---------- сборка предметов ---------- */

function toItem(
  raw: RawItem, type: Skin['type'], weapon: string, price: number,
): Skin {
  const name = raw.market_hash_name || raw.name || '';
  const rarity = rarityOf(raw.rarity);
  return {
    id: raw.id ?? `${type}-${name}`,
    name,
    weapon,
    rarity,
    rarityRu: rarityRu(rarity),
    color: rarityColor(rarity),
    price,
    image: raw.image ?? '',
    star: false,
    cat: 'other',
    type,
  };
}

async function fetchJson(url: string, ms = 12000): Promise<RawItem[]> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal, cache: 'force-cache' });
    if (!res.ok) return [];
    const data = (await res.json()) as RawItem[];
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

const CACHE_KEY = 'nikgrager-market-v3';

/**
 * Загружает наклейки, брелоки, контейнеры, агентов, граффити и музыку
 * вместе с картинками Steam CDN. Результат кэшируется.
 */
export async function loadMarketItems(): Promise<Skin[]> {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached) as Skin[];
      if (Array.isArray(parsed) && parsed.length > 200) return parsed;
    }
  } catch { /* кэш недоступен */ }

  const online = typeof navigator === 'undefined' || navigator.onLine !== false;
  if (!online) return [];

  const [stickers, keychains, crates, agents, graffiti, music] = await Promise.all([
    fetchJson(SOURCES.stickers),
    fetchJson(SOURCES.keychains),
    fetchJson(SOURCES.crates),
    fetchJson(SOURCES.agents),
    fetchJson(SOURCES.graffiti),
    fetchJson(SOURCES.musicKits),
  ]);

  const out: Skin[] = [];

  /* наклейки — самая крупная категория, ограничиваем разумным числом */
  for (const s of stickers.slice(0, 4000)) {
    const name = s.market_hash_name || s.name || '';
    if (!name) continue;
    out.push(toItem(s, 'sticker', 'Наклейка', stickerPrice(name, s.tournament, s.effect)));
  }

  for (const k of keychains) {
    const name = k.market_hash_name || k.name || '';
    if (!name) continue;
    out.push(toItem(k, 'charm', 'Брелок', priceFromTable(CHARM_PRICES, name, 520)));
  }

  for (const c of crates) {
    const name = c.market_hash_name || c.name || '';
    if (!name) continue;
    const isCapsule = /capsule|package|pack/i.test(name) || c.type === 'Sticker Capsule';
    const table = isCapsule ? CAPSULE_PRICES : CRATE_PRICES;
    out.push(toItem(
      c, isCapsule ? 'capsule' : 'case',
      isCapsule ? 'Капсула' : 'Контейнер',
      priceFromTable(table, name, isCapsule ? 190 : 85),
    ));
  }

  for (const a of agents) {
    const name = a.market_hash_name || a.name || '';
    if (!name) continue;
    out.push(toItem(a, 'agent', 'Агент', priceFromTable(AGENT_PRICES, name, 420)));
  }

  for (const g of graffiti.slice(0, 600)) {
    const name = g.market_hash_name || g.name || '';
    if (!name) continue;
    out.push(toItem(g, 'graffiti', 'Граффити', priceFromTable(GRAFFITI_PRICES, name, GRAFFITI_BASE)));
  }

  for (const m of music) {
    const name = m.market_hash_name || m.name || '';
    if (!name) continue;
    const st = name.includes('StatTrak');
    const base = MUSIC_PRICES[name.replace('StatTrak\u2122 ', '')] ?? 280;
    out.push(toItem(m, 'music', 'Музыка', round(base * (st ? MUSIC_ST_MULT : 1))));
  }

  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(out));
  } catch { /* переполнение хранилища — не критично */ }

  return out;
}
