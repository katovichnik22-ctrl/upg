/**
 * Справочные рыночные цены (₽) по данным Steam Community Market.
 * Это снимок порядка цен на момент сборки: живой рынок колеблется,
 * поэтому значения — близкий ориентир, а не котировка в реальном времени.
 */

/* ---------- НАКЛЕЙКИ ---------- */
export const STICKER_PRICES: Record<string, number> = {
  // легендарная Катовице 2014
  'Sticker | Titan (Holo) | Katowice 2014': 2_900_000,
  'Sticker | iBUYPOWER (Holo) | Katowice 2014': 1_650_000,
  'Sticker | Reason Gaming (Holo) | Katowice 2014': 980_000,
  'Sticker | Vox Eminor (Holo) | Katowice 2014': 420_000,
  'Sticker | Titan | Katowice 2014': 185_000,
  'Sticker | iBUYPOWER | Katowice 2014': 140_000,
  'Sticker | Natus Vincere (Holo) | Katowice 2014': 310_000,
  'Sticker | Fnatic (Holo) | Katowice 2014': 240_000,
  'Sticker | Virtus.Pro (Holo) | Katowice 2014': 260_000,
  'Sticker | Ninjas in Pyjamas (Holo) | Katowice 2014': 230_000,
  'Sticker | Team Dignitas (Holo) | Katowice 2014': 195_000,
  'Sticker | HellRaisers (Holo) | Katowice 2014': 175_000,
  'Sticker | Natus Vincere | Katowice 2014': 28_000,
  'Sticker | Fnatic | Katowice 2014': 24_000,
  'Sticker | Virtus.Pro | Katowice 2014': 26_000,

  // Katowice 2015
  'Sticker | Flipsid3 Tactics (Holo) | Katowice 2015': 34_000,
  'Sticker | Team EnVyUs (Holo) | Katowice 2015': 22_000,
  'Sticker | Natus Vincere (Holo) | Katowice 2015': 26_000,
  'Sticker | Fnatic (Holo) | Katowice 2015': 24_000,
  'Sticker | Virtus.Pro (Holo) | Katowice 2015': 23_000,
  'Sticker | TSM Kinguin (Holo) | Katowice 2015': 18_000,

  // Cologne 2014
  'Sticker | Titan (Holo) | Cologne 2014': 165_000,
  'Sticker | iBUYPOWER (Holo) | Cologne 2014': 92_000,
  'Sticker | Natus Vincere (Holo) | Cologne 2014': 42_000,
  'Sticker | Fnatic (Holo) | Cologne 2014': 36_000,

  // особые
  'Sticker | Crown (Foil)': 78_000,
  'Sticker | Howling Dawn': 54_000,
  'Sticker | Harp of War (Holo)': 12_500,
  'Sticker | Winged Defuser': 9_800,
  'Sticker | Phoenix (Holo)': 6_400,
  'Sticker | King on the Field': 4_200,
  'Sticker | Death Sentence (Holo)': 2_800,

  // автографы топ-игроков (Katowice 2014)
  'Sticker | kennyS (Foil) | Katowice 2014': 320_000,
  'Sticker | olofmeister (Foil) | Katowice 2014': 180_000,
  'Sticker | GeT_RiGhT (Foil) | Katowice 2014': 165_000,
  'Sticker | s1mple (Foil) | Katowice 2015': 95_000,
};

/** Базовые цены по турниру и типу — для массовых наклеек */
export const STICKER_EVENT_BASE: Record<string, number> = {
  'Katowice 2014': 2_400, 'Cologne 2014': 900, 'DreamHack 2014': 680,
  'Katowice 2015': 380, 'Cologne 2015': 150, 'Cluj-Napoca 2015': 85,
  'MLG Columbus 2016': 105, 'Cologne 2016': 70, 'Atlanta 2017': 60,
  'Krakow 2017': 45, 'Boston 2018': 38, 'London 2018': 30,
  'Katowice 2019': 28, 'Berlin 2019': 24, 'Stockholm 2021': 19,
  'Antwerp 2022': 16, 'Rio 2022': 13, 'Paris 2023': 11,
  'Copenhagen 2024': 9, 'Shanghai 2024': 8, 'Austin 2025': 7,
};

/** Множители вариантов наклейки */
export const STICKER_VARIANT_MULT: Record<string, number> = {
  '': 1, 'Glitter': 2.6, 'Holo': 7.5, 'Foil': 12, 'Gold': 34, 'Lenticular': 9,
  'Champion': 4.5, 'Autograph': 1.8,
};

/* ---------- БРЕЛОКИ ---------- */
export const CHARM_PRICES: Record<string, number> = {
  'Charm | Hot Howl': 21_000,
  'Charm | Baby Karat T': 11_500,
  'Charm | Baby Karat CT': 10_800,
  'Charm | Diamond Dog': 5_400,
  'Charm | Semi-Precious': 4_100,
  'Charm | Titeenium AWP': 1_950,
  'Charm | Hot Wurst': 2_700,
  'Charm | Die-cast AK': 1_480,
  'Charm | Whittle Knife': 1_650,
  'Charm | Pocket AWP': 1_150,
  'Charm | Glamour Shot': 740,
  'Charm | Big Kev': 580,
  "Charm | Lil' Crass": 860,
  'Charm | Backsplash': 480,
  "Charm | Lil' Squirt": 390,
  "Charm | Lil' Ava": 420,
  "Charm | Lil' Cap Gun": 340,
  "Charm | Lil' SAS": 360,
  "Charm | Lil' Monster": 450,
  "Charm | Lil' Sandy": 330,
  'Charm | Chicken Lil': 520,
  'Charm | Baby Karat': 9_800,
  'Charm | Disco MAC': 640,
  'Charm | Hot Sauce': 410,
  'Charm | Stitch-Loaded': 370,
  'Charm | Pinch O’ Salt': 300,
  'Charm | That’s Bananas': 390,
};

/* ---------- КОНТЕЙНЕРЫ ---------- */
export const CRATE_PRICES: Record<string, number> = {
  'Operation Bravo Case': 34_000,
  'CS:GO Weapon Case': 29_000,
  'eSports 2013 Case': 9_400,
  'CS:GO Weapon Case 2': 13_500,
  'eSports 2013 Winter Case': 6_800,
  'Operation Phoenix Weapon Case': 1_050,
  'Huntsman Weapon Case': 680,
  'Operation Breakout Weapon Case': 1_320,
  'eSports 2014 Summer Case': 2_500,
  'Operation Vanguard Weapon Case': 820,
  'CS:GO Weapon Case 3': 3_600,
  'Chroma Case': 190, 'Chroma 2 Case': 230, 'Chroma 3 Case': 96,
  'Falchion Case': 74, 'Shadow Case': 80, 'Revolver Case': 64,
  'Operation Wildfire Case': 290, 'Gamma Case': 145, 'Gamma 2 Case': 165,
  'Glove Case': 350, 'Spectrum Case': 125, 'Operation Hydra Case': 7_200,
  'Spectrum 2 Case': 270, 'Clutch Case': 44, 'Horizon Case': 60,
  'Danger Zone Case': 40, 'Prisma Case': 36, 'CS20 Case': 56,
  'Shattered Web Case': 92, 'Prisma 2 Case': 48, 'Fracture Case': 28,
  'Operation Broken Fang Case': 250, 'Snakebite Case': 24,
  'Operation Riptide Case': 220, 'Dreams & Nightmares Case': 100,
  'Recoil Case': 34, 'Revolution Case': 46, 'Kilowatt Case': 70,
  'Gallery Case': 76, 'Fever Case': 54,
  'Winter Offensive Weapon Case': 650,
  'Operation Payback Weapon Case': 540,
};

/** Капсулы с наклейками */
export const CAPSULE_PRICES: Record<string, number> = {
  'Katowice 2014 Legends (Holo-Foil)': 420_000,
  'Katowice 2014 Challengers (Holo-Foil)': 380_000,
  'Cologne 2014 Legends (Holo-Foil)': 95_000,
  'Katowice 2015 Legends (Holo-Foil)': 34_000,
  'Cologne 2015 Legends (Holo/Foil)': 6_200,
  'Boston 2018 Legends (Holo-Foil)': 1_100,
  'Berlin 2019 Legends (Holo/Foil)': 540,
  'Stockholm 2021 Legends Sticker Capsule': 380,
  'Antwerp 2022 Legends Sticker Capsule': 300,
  'Rio 2022 Legends Sticker Capsule': 260,
  'Paris 2023 Legends Sticker Capsule': 220,
  'Copenhagen 2024 Legends Sticker Capsule': 185,
  'Shanghai 2024 Legends Sticker Capsule': 160,
  'Community Capsule 2018': 140,
  'Chicken Capsule': 98,
  'Sticker Capsule': 260,
  'Sticker Capsule 2': 240,
};

/* ---------- АГЕНТЫ ---------- */
export const AGENT_PRICES: Record<string, number> = {
  'Sir Bloody Miami Darryl | The Professionals': 3_700,
  'Sir Bloody Darryl Royale | The Professionals': 3_100,
  'Sir Bloody Skullhead Darryl | The Professionals': 2_600,
  'Sir Bloody Loudmouth Darryl | The Professionals': 2_900,
  'Bloody Darryl The Strapped | The Professionals': 2_800,
  'Special Agent Ava | FBI': 1_750,
  'Cmdr. Mae \u2018Dead Cold\u2019 Jamison | SWAT': 1_550,
  'Chem-Haz Capitaine | Gendarmerie Nationale': 1_350,
  'The Doctor Romanov | Sabre': 1_200,
  '\u2018Two Times\u2019 McCoy | USAF TACP': 1_050,
  '\u2018Two Times\u2019 McCoy | TACP Cavalry': 980,
  'Lt. Commander Ricksaw | NSWC SEAL': 680,
  'Rezan The Ready | Sabre': 700,
  'Primeiro Tenente | Brazilian 1st Battalion': 820,
  'Osiris | Elite Crew': 600,
  'Prof. Shahmat | Elite Crew': 560,
  'Blackwolf | Sabre': 410,
  'Number K | Sabre': 370,
  'Getaway Sally': 450,
  'Arno The Overgrown | Guerrilla Warfare': 460,
  'Street Soldier | Phoenix': 340,
  'Enforcer | Phoenix': 300,
  'Slingshot | Phoenix': 260,
  'Soldier | Phoenix': 240,
  'Dragomir | Sabre': 280,
};

/* ---------- МУЗЫКАЛЬНЫЕ НАБОРЫ ---------- */
export const MUSIC_PRICES: Record<string, number> = {
  'Music Kit | Hotline Miami, Hotline Miami': 680,
  'Music Kit | The Verkkars, EZ4ENCE': 760,
  'Music Kit | Kelly Bailey, Hazardous Environments': 560,
  'Music Kit | Midnight Riders, All I Want for Christmas': 520,
  'Music Kit | Halo, The Master Chief Collection': 590,
  'Music Kit | Daniel Sadowski, The 8-Bit Kit': 360,
  'Music Kit | Skog, Metal': 440,
  'Music Kit | Noisia, Sharpened': 400,
  'Music Kit | AWOLNATION, I Am': 350,
  'Music Kit | Scarlxrd, CHAIN$AW.LULLABYE': 360,
  'Music Kit | Dren, Death\u2019s Head Demolition': 340,
  'Music Kit | Damjan Mravunac, The Talos Principle': 280,
  'Music Kit | Darude, Moments': 320,
  'Music Kit | Feed Me, High Noon': 300,
  'Music Kit | Daniel Sadowski, Total Domination': 280,
  'Music Kit | Beartooth, Disgusting': 300,
  'Music Kit | Dark Tranquillity, Atoma': 330,
  'Music Kit | Chipzel, Yellow Magic': 310,
  'Music Kit | Ki:Theory, MOLOTOV': 290,
};

/** StatTrak™ музыкальный набор заметно дороже */
export const MUSIC_ST_MULT = 2.4;

/* ---------- ГРАФФИТИ ---------- */
export const GRAFFITI_BASE = 14;
export const GRAFFITI_PRICES: Record<string, number> = {
  'Sealed Graffiti | Recoil AWP': 68,
  'Sealed Graffiti | Recoil AK-47': 52,
  'Sealed Graffiti | Crown (Wire Blue)': 48,
  'Sealed Graffiti | Kawaii Killer CT': 36,
  'Sealed Graffiti | X-Ray (Monster Purple)': 28,
  'Sealed Graffiti | Backstabber': 30,
  'Sealed Graffiti | Rage Mode': 24,
  'Sealed Graffiti | Chicken': 20,
  'Sealed Graffiti | GGWP': 18,
};
