/** Данные европейской и американской рулетки */

export type Variant = 'eu' | 'us';

/** Красные числа (одинаковы в обоих вариантах) */
export const RED_NUMBERS = [
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
];

/** Чёрные числа */
export const BLACK_NUMBERS = [
  2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35,
];

/** Порядок секторов на европейском колесе (один зеро) */
export const WHEEL_ORDER_EU: string[] = [
  '0', '32', '15', '19', '4', '21', '2', '25', '17', '34', '6', '27',
  '13', '36', '11', '30', '8', '23', '10', '5', '24', '16', '33', '1',
  '20', '14', '31', '9', '22', '18', '29', '7', '28', '12', '35', '3', '26',
];

/** Порядок секторов на американском колесе (0 и 00 напротив друг друга) */
export const WHEEL_ORDER_US: string[] = [
  '0', '28', '9', '26', '30', '11', '7', '20', '32', '17', '5', '22',
  '34', '15', '3', '24', '36', '13', '1', '00', '27', '10', '25', '29',
  '12', '8', '19', '31', '18', '6', '21', '33', '16', '4', '23', '35',
  '14', '2',
];

export const wheelOrder = (v: Variant) => (v === 'eu' ? WHEEL_ORDER_EU : WHEEL_ORDER_US);

export type PocketColor = 'red' | 'black' | 'green';

/** Цвет сектора */
export function colorOf(n: string): PocketColor {
  if (n === '0' || n === '00') return 'green';
  const num = Number(n);
  return RED_NUMBERS.includes(num) ? 'red' : 'black';
}

export const isZero = (n: string) => n === '0' || n === '00';

/* ------------------------------------------------------------------ */
/*  Ставки                                                             */
/* ------------------------------------------------------------------ */

export type BetType =
  | 'straight'  // 1 число      35:1
  | 'split'     // 2 числа      17:1
  | 'street'    // 3 числа      11:1
  | 'corner'    // 4 числа       8:1
  | 'sixline'   // 6 чисел       5:1
  | 'column'    // 12 чисел      2:1
  | 'dozen'     // 12 чисел      2:1
  | 'red' | 'black'
  | 'odd' | 'even'
  | 'low' | 'high';

/** Выплаты «к одному» (сверх возврата ставки) */
export const PAYOUTS: Record<BetType, number> = {
  straight: 35,
  split: 17,
  street: 11,
  corner: 8,
  sixline: 5,
  column: 2,
  dozen: 2,
  red: 1, black: 1,
  odd: 1, even: 1,
  low: 1, high: 1,
};

export const BET_LABELS: Record<BetType, string> = {
  straight: 'Число', split: 'Сплит', street: 'Улица', corner: 'Угол',
  sixline: 'Линия', column: 'Колонка', dozen: 'Дюжина',
  red: 'Красное', black: 'Чёрное', odd: 'Нечёт', even: 'Чёт',
  low: '1–18', high: '19–36',
};

/** Одна ставка на столе */
export interface Bet {
  id: string;
  type: BetType;
  /** покрываемые числа (для внутренних ставок) */
  numbers: string[];
  amount: number;
}

/** Выигрышная ли ставка. Зеро не играет на внешних ставках. */
export function betWins(bet: Bet, result: string): boolean {
  const num = Number(result);
  switch (bet.type) {
    case 'straight': case 'split': case 'street':
    case 'corner': case 'sixline':
      return bet.numbers.includes(result);
    case 'column': case 'dozen':
      return !isZero(result) && bet.numbers.includes(result);
    case 'red':   return !isZero(result) && RED_NUMBERS.includes(num);
    case 'black': return !isZero(result) && BLACK_NUMBERS.includes(num);
    case 'odd':   return !isZero(result) && num % 2 === 1;
    case 'even':  return !isZero(result) && num % 2 === 0;
    case 'low':   return !isZero(result) && num >= 1 && num <= 18;
    case 'high':  return !isZero(result) && num >= 19 && num <= 36;
    default: return false;
  }
}

/** Выплата по ставке: ставка + выигрыш, либо 0 */
export function payout(bet: Bet, result: string): number {
  return betWins(bet, result) ? bet.amount * (PAYOUTS[bet.type] + 1) : 0;
}

/* ------------------------------------------------------------------ */
/*  Раскладка стола                                                    */
/* ------------------------------------------------------------------ */

/** Числа стола по колонкам: [[3,6,9...],[2,5,8...],[1,4,7...]] — 3 ряда × 12 */
export const TABLE_ROWS: number[][] = [
  Array.from({ length: 12 }, (_, i) => i * 3 + 3),
  Array.from({ length: 12 }, (_, i) => i * 3 + 2),
  Array.from({ length: 12 }, (_, i) => i * 3 + 1),
];

export const COLUMNS: string[][] = TABLE_ROWS.map((r) => r.map(String));

export const DOZENS: string[][] = [
  Array.from({ length: 12 }, (_, i) => String(i + 1)),
  Array.from({ length: 12 }, (_, i) => String(i + 13)),
  Array.from({ length: 12 }, (_, i) => String(i + 25)),
];

/** Номиналы фишек */
export const CHIPS = [1, 5, 10, 25, 100, 500, 1000];

export const CHIP_STYLE: Record<number, { bg: string; ring: string; text: string }> = {
  1:    { bg: '#e8eef7', ring: '#9fb0c9', text: '#1b2230' },
  5:    { bg: '#e0303a', ring: '#7d1016', text: '#fff' },
  10:   { bg: '#2d6cdf', ring: '#12336f', text: '#fff' },
  25:   { bg: '#22a355', ring: '#0c5128', text: '#fff' },
  100:  { bg: '#1b2230', ring: '#000', text: '#fff' },
  500:  { bg: '#8b46d8', ring: '#3f1a6b', text: '#fff' },
  1000: { bg: '#f6c445', ring: '#8a6205', text: '#2b1f02' },
};

/** Лимиты стола */
export const LIMITS = {
  insideMin: 1,
  insideMax: 50_000,
  outsideMin: 5,
  outsideMax: 200_000,
};
