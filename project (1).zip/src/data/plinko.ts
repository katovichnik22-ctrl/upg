/** Таблицы множителей Plinko (как в Pragmatic/BGaming) */
export type Risk = 'low' | 'medium' | 'high';
export type RowsCount = 8 | 12 | 16;

export const PLINKO_MULTIPLIERS: Record<RowsCount, Record<Risk, number[]>> = {
  8: {
    low:    [5.6, 2.1, 1.1, 1, 0.5, 1, 1.1, 2.1, 5.6],
    medium: [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
    high:   [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29],
  },
  12: {
    low:    [8.4, 3, 1.6, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 1.6, 3, 8.4],
    medium: [37, 7.7, 4.6, 1.99, 1.07, 0.61, 0.31, 0.61, 1.07, 1.99, 4.6, 7.7, 37],
    high:   [68, 18, 8.2, 2.3, 0.82, 0.23, 0.23, 0.23, 0.82, 2.3, 8.2, 18, 68],
  },
  16: {
    low:    [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.4, 1.4, 2, 9, 16],
    medium: [110, 41, 10, 5, 3, 1.5, 1, 0.5, 0.3, 0.5, 1, 1.5, 3, 5, 10, 41, 110],
    high:   [1000, 130, 26, 9, 4, 2, 0.2, 0.2, 0.2, 0.2, 0.2, 2, 4, 9, 26, 130, 1000],
  },
};

export const RISKS: Array<{ id: Risk; label: string }> = [
  { id: 'low', label: 'Низкий' },
  { id: 'medium', label: 'Средний' },
  { id: 'high', label: 'Высокий' },
];

export const ROW_OPTIONS: RowsCount[] = [8, 12, 16];

/** Цвет лотка: края — горячие, центр — холодные */
export function slotColor(i: number, total: number): string {
  const d = Math.abs(i - (total - 1) / 2) / ((total - 1) / 2);
  if (d > 0.82) return '#ff3b30';
  if (d > 0.62) return '#ff7a1a';
  if (d > 0.42) return '#ffb01a';
  if (d > 0.22) return '#e8d51a';
  return '#8ecf3a';
}
