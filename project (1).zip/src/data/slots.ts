import { themeOf, type SlotTheme } from './slotThemes';

/** Конфиг игрового автомата */
export interface SlotConfig {
  id: string;
  name: string;
  /** надпись на баннере автомата */
  banner: string;
  theme: string;
  look: SlotTheme;
  symbols: string[];
  cover: string;
  multipliers: { m5: number; m4: number; m3: number; m2: number };
  minBet: number;
  maxBet: number;
  rtp: number;
  unlockedByDefault: boolean;
  unlockPrice: number;
}

/** Низкие символы общие для всех наборов — как в классических слотах */
const LOW = ['sym_10', 'sym_j', 'sym_q', 'sym_k', 'sym_a'];
const SPECIAL = ['wild', 'bonus', 'scatter'];

/** Наборы: 5 low + 3 mid + 1 high + 3 специальных */
const SETS = {
  pack:     [...LOW, 'bone', 'paw', 'star_gold', 'wolf', ...SPECIAL],
  fruit:    [...LOW, 'cherry_pair', 'grape_bunch', 'melon_slice', 'jester', ...SPECIAL],
  reef:     [...LOW, 'fish', 'anchor', 'gem_cyan', 'mermaid', ...SPECIAL],
  frost:    [...LOW, 'snow_gem', 'gem_blue', 'crown', 'queen', ...SPECIAL],
  canyon:   [...LOW, 'revolver', 'horseshoe', 'coin_stack', 'cowboy', ...SPECIAL],
  sky:      [...LOW, 'cloud_bolt', 'star_gold', 'gem_cyan', 'angel', ...SPECIAL],
  carnival: [...LOW, 'pumpkin', 'gem_purple', 'star_gold', 'zombie', ...SPECIAL],
  tavern:   [...LOW, 'barrel', 'lantern', 'coin_stack', 'pirate', ...SPECIAL],
  heist:    [...LOW, 'cash', 'gem_green', 'seven', 'owl', ...SPECIAL],
  clover:   [...LOW, 'clover', 'gold_pot', 'horseshoe', 'leprechaun', ...SPECIAL],
} as const;

type SetKey = keyof typeof SETS;

/** Калибровка выплат под целевой RTP (замерено симуляцией) */
const PAY_SCALE: Record<SetKey, number> = {
  pack: 7.539, fruit: 8.049, reef: 7.610,
  frost: 7.055, canyon: 7.368, sky: 7.256,
  carnival: 7.393, tavern: 7.501, heist: 7.042,
  clover: 7.231,
};

function multipliers(rtp: number, set: SetKey) {
  const k = (rtp / 0.95) * PAY_SCALE[set];
  const r = (v: number) => Math.max(0.2, Math.round(v * k * 100) / 100);
  return { m5: r(50), m4: r(10), m3: r(3), m2: r(0.5) };
}

type Row = [
  id: string, name: string, banner: string, theme: SetKey, cover: string,
  minBet: number, maxBet: number, rtp: number, unlocked: boolean, price: number,
];

const ROWS: Row[] = [
  /* Лунная стая */
  ['moon-pack', 'Moon Pack', 'ЛУННАЯ СТАЯ', 'pack', 'wolf', 10, 5000, 0.95, true, 0],
  ['alpha-howl', 'Alpha Howl', 'ЗОВ ВОЖАКА', 'pack', 'bone', 50, 20000, 0.94, true, 0],
  ['night-hunt', 'Night Hunt', 'НОЧНАЯ ОХОТА', 'pack', 'paw', 200, 60000, 0.93, false, 28000],

  /* Фруктовый карнавал */
  ['fruit-fiesta', 'Fruit Fiesta', 'ФРУКТОВЫЙ КАРНАВАЛ', 'fruit', 'cherry_pair', 5, 3000, 0.96, true, 0],
  ['berry-boom', 'Berry Boom', 'ЯГОДНЫЙ БУМ', 'fruit', 'grape_bunch', 25, 12000, 0.95, true, 0],
  ['juicy-jester', 'Juicy Jester', 'СОЧНЫЙ ШУТ', 'fruit', 'jester', 100, 35000, 0.93, false, 22000],

  /* Большой улов */
  ['big-catch', 'Big Catch', 'БОЛЬШОЙ УЛОВ', 'reef', 'fish', 10, 5000, 0.95, true, 0],
  ['deep-reef', 'Deep Reef', 'ГЛУБИННЫЙ РИФ', 'reef', 'mermaid', 50, 25000, 0.94, true, 0],
  ['pearl-dive', 'Pearl Dive', 'ЗА ЖЕМЧУГОМ', 'reef', 'gem_cyan', 200, 50000, 0.93, false, 30000],

  /* Ледяная корона */
  ['frost-crown', 'Frost Crown', 'ЛЕДЯНАЯ КОРОНА', 'frost', 'queen', 25, 15000, 0.95, true, 0],
  ['ice-realm', 'Ice Realm', 'ЦАРСТВО ЛЬДА', 'frost', 'snow_gem', 10, 6000, 0.96, true, 0],
  ['winter-jewels', 'Winter Jewels', 'ЗИМНИЕ КАМНИ', 'frost', 'crown', 500, 90000, 0.92, false, 70000],

  /* Дикий каньон */
  ['wild-canyon', 'Wild Canyon', 'ДИКИЙ КАНЬОН', 'canyon', 'cowboy', 10, 5000, 0.95, true, 0],
  ['gold-rush', 'Gold Rush', 'ЗОЛОТАЯ ЛИХОРАДКА', 'canyon', 'coin_stack', 50, 25000, 0.94, true, 0],
  ['six-shooter', 'Six Shooter', 'ШЕСТИЗАРЯДНЫЙ', 'canyon', 'revolver', 200, 60000, 0.93, false, 32000],

  /* Небесный клад */
  ['sky-vault', 'Sky Vault', 'НЕБЕСНЫЙ КЛАД', 'sky', 'angel', 25, 15000, 0.95, true, 0],
  ['storm-riches', 'Storm Riches', 'БОГАТСТВА БУРИ', 'sky', 'cloud_bolt', 100, 35000, 0.93, false, 26000],

  /* Карнавал теней */
  ['shadow-carnival', 'Shadow Carnival', 'КАРНАВАЛ ТЕНЕЙ', 'carnival', 'zombie', 25, 12000, 0.95, true, 0],
  ['pumpkin-night', 'Pumpkin Night', 'ТЫКВЕННАЯ НОЧЬ', 'carnival', 'pumpkin', 50, 20000, 0.94, false, 18000],

  /* Таверна корсара */
  ['corsair-tavern', 'Corsair Tavern', 'ТАВЕРНА КОРСАРА', 'tavern', 'pirate', 10, 6000, 0.95, true, 0],
  ['rum-barrel', 'Rum Barrel', 'БОЧКА РОМА', 'tavern', 'barrel', 50, 25000, 0.94, true, 0],
  ['captain-hoard', 'Captain Hoard', 'КЛАД КАПИТАНА', 'tavern', 'coin_stack', 500, 90000, 0.92, false, 65000],

  /* Неоновый куш */
  ['neon-heist', 'Neon Heist', 'НЕОНОВЫЙ КУШ', 'heist', 'cash', 25, 15000, 0.95, true, 0],
  ['night-owl', 'Night Owl', 'НОЧНАЯ СОВА', 'heist', 'owl', 100, 40000, 0.93, false, 24000],
  ['lucky-seven', 'Lucky Seven', 'СЧАСТЛИВАЯ 7', 'heist', 'seven', 10, 8000, 0.96, true, 0],

  /* Золотой клевер */
  ['clover-gold', 'Clover Gold', 'ЗОЛОТОЙ КЛЕВЕР', 'clover', 'leprechaun', 10, 5000, 0.95, true, 0],
  ['pot-of-luck', 'Pot of Luck', 'КОТЁЛ УДАЧИ', 'clover', 'gold_pot', 100, 35000, 0.93, true, 0],
  ['emerald-isle', 'Emerald Isle', 'ИЗУМРУДНЫЙ ОСТРОВ', 'clover', 'clover', 1000, 200000, 0.91, false, 120000],

  /* хай-роллеры */
  ['high-roller', 'High Roller', 'ХАЙ-РОЛЛЕР', 'frost', 'crown', 2000, 300000, 0.90, false, 150000],
  ['whale-club', 'Whale Club', 'КЛУБ КИТОВ', 'tavern', 'pirate', 5000, 500000, 0.90, false, 250000],
];

export const SLOTS: SlotConfig[] = ROWS.map((r) => ({
  id: r[0],
  name: r[1],
  banner: r[2],
  theme: r[3],
  look: themeOf(r[3]),
  symbols: [...SETS[r[3]]],
  cover: r[4],
  multipliers: multipliers(r[7], r[3]),
  minBet: r[5],
  maxBet: r[6],
  rtp: r[7],
  unlockedByDefault: r[8],
  unlockPrice: r[9],
}));

export const SLOT_THEMES = Array.from(new Set(SLOTS.map((s) => themeOf(s.theme).label)));
export const slotById = (id: string) => SLOTS.find((s) => s.id === id);
