/** Виды рыб и математика выплат */

export type FishTier = 'small' | 'medium' | 'large' | 'boss';

export interface FishDef {
  id: string;
  label: string;
  tier: FishTier;
  /** множитель к ставке за улов */
  mult: number;
  /** сколько попаданий нужно визуально (HP) */
  hp: number;
  /** относительная частота появления */
  spawn: number;
  /** размер тела в px */
  size: number;
  /** скорость в px/сек */
  speed: number;
  body: string;
  fin: string;
}

export const FISH: FishDef[] = [
  { id: 'anchovy', label: 'Килька',    tier: 'small',  mult: 2,   hp: 1, spawn: 32, size: 26, speed: 74, body: '#7fd3e8', fin: '#3aa0bd' },
  { id: 'perch',   label: 'Окунь',     tier: 'small',  mult: 3,   hp: 1, spawn: 26, size: 32, speed: 66, body: '#8fd46a', fin: '#4d8a2c' },
  { id: 'snapper', label: 'Люциан',    tier: 'medium', mult: 5,   hp: 2, spawn: 18, size: 42, speed: 58, body: '#f0894a', fin: '#a8441a' },
  { id: 'angel',   label: 'Скалярия',  tier: 'medium', mult: 8,   hp: 2, spawn: 13, size: 46, speed: 52, body: '#f2c94c', fin: '#a8801a' },
  { id: 'tuna',    label: 'Тунец',     tier: 'large',  mult: 20,  hp: 4, spawn: 7,  size: 62, speed: 46, body: '#5b8ee0', fin: '#27508f' },
  { id: 'swordy',  label: 'Меч-рыба',  tier: 'large',  mult: 35,  hp: 5, spawn: 4,  size: 70, speed: 54, body: '#a56be0', fin: '#5a2c96' },
  { id: 'shark',   label: 'Акула',     tier: 'boss',   mult: 100, hp: 8, spawn: 1.6, size: 88, speed: 38, body: '#8fa0b8', fin: '#4a5a72' },
  { id: 'kraken',  label: 'Кракен',    tier: 'boss',   mult: 500, hp: 14, spawn: 0.4, size: 104, speed: 30, body: '#e0576b', fin: '#8a1f34' },
];

export const fishById = (id: string) => FISH.find((f) => f.id === id) ?? FISH[0];

/** Целевой RTP игры */
export const FISHING_RTP = 0.94;

/** Криты: множитель к выплате при удачном улове */
export const CRITS: Array<{ mult: number; chance: number }> = [
  { mult: 2, chance: 0.06 },
  { mult: 5, chance: 0.02 },
  { mult: 10, chance: 0.005 },
];

/** Средний вклад крита — нужен, чтобы RTP оставался целевым */
export const CRIT_AVG = CRITS.reduce(
  (a, c) => a + c.chance * (c.mult - 1), 1,
);

/**
 * Вероятность выловить рыбу при попадании.
 * p = RTP / (mult * critAvg) — тогда матожидание выплаты за результативный
 * выстрел равно ровно RTP, независимо от меткости игрока.
 */
export function killChance(f: FishDef): number {
  return Math.min(0.95, FISHING_RTP / (f.mult * CRIT_AVG));
}

/** Разыгранный множитель крита */
export function rollCrit(rnd: () => number): number {
  const r = rnd();
  let acc = 0;
  for (const c of CRITS) {
    acc += c.chance;
    if (r < acc) return c.mult;
  }
  return 1;
}

/** Выбор вида рыбы по весам появления */
export function pickFish(rnd: () => number): FishDef {
  const total = FISH.reduce((a, f) => a + f.spawn, 0);
  let r = rnd() * total;
  for (const f of FISH) {
    r -= f.spawn;
    if (r <= 0) return f;
  }
  return FISH[0];
}

export const SHOT_COSTS = [1, 5, 10, 25, 50, 100];

export const TIER_COLOR: Record<FishTier, string> = {
  small: '#7fd3e8',
  medium: '#f2c94c',
  large: '#8f7bff',
  boss: '#ff6b7d',
};
