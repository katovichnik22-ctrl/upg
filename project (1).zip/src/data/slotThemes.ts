/** Визуальные темы автоматов: корпус, фон, палитра */

export type FrameKind = 'wood' | 'neon' | 'metal';

export interface SlotTheme {
  id: string;
  label: string;
  /** корпус автомата */
  frame: FrameKind;
  frame1: string;
  frame2: string;
  accent: string;
  /** фон за барабанами */
  bg1: string;
  bg2: string;
  /** декоративные элементы фона */
  decor: 'snow' | 'bubbles' | 'clouds' | 'sparks' | 'leaves' | 'stars' | 'none';
  decorColor: string;
  /** цвета баннера-логотипа */
  titleTop: string;
  titleBottom: string;
}

export const THEMES: Record<string, SlotTheme> = {
  pack: {
    id: 'pack', label: 'Лунная стая', frame: 'wood',
    frame1: '#3b2a52', frame2: '#160e26', accent: '#b79cff',
    bg1: '#2b1f4a', bg2: '#0b0718', decor: 'stars', decorColor: '#d9ccff',
    titleTop: '#ffe9a8', titleBottom: '#a071ff',
  },
  fruit: {
    id: 'fruit', label: 'Фруктовый карнавал', frame: 'neon',
    frame1: '#7a1450', frame2: '#2a0520', accent: '#ff5fa8',
    bg1: '#8e1a5c', bg2: '#25041a', decor: 'sparks', decorColor: '#ffc2e0',
    titleTop: '#fff3b0', titleBottom: '#ff4f95',
  },
  reef: {
    id: 'reef', label: 'Большой улов', frame: 'wood',
    frame1: '#14506b', frame2: '#04202e', accent: '#57d3f5',
    bg1: '#0f5f80', bg2: '#03161f', decor: 'bubbles', decorColor: '#bdeeff',
    titleTop: '#fff3c0', titleBottom: '#2fa8d8',
  },
  frost: {
    id: 'frost', label: 'Ледяная корона', frame: 'metal',
    frame1: '#1c3d5e', frame2: '#071523', accent: '#8fd8ff',
    bg1: '#1a4870', bg2: '#04101c', decor: 'snow', decorColor: '#e6f7ff',
    titleTop: '#ffffff', titleBottom: '#4aa8e0',
  },
  canyon: {
    id: 'canyon', label: 'Дикий каньон', frame: 'wood',
    frame1: '#6b3a12', frame2: '#261205', accent: '#f0a355',
    bg1: '#8a4d18', bg2: '#200f03', decor: 'sparks', decorColor: '#ffd9a0',
    titleTop: '#fff0b8', titleBottom: '#d06a14',
  },
  sky: {
    id: 'sky', label: 'Небесный клад', frame: 'metal',
    frame1: '#2a4a86', frame2: '#0a1530', accent: '#9dc2ff',
    bg1: '#3a63a8', bg2: '#0a1730', decor: 'clouds', decorColor: '#ffffff',
    titleTop: '#fff6c8', titleBottom: '#5b8ee0',
  },
  carnival: {
    id: 'carnival', label: 'Карнавал теней', frame: 'neon',
    frame1: '#5a2470', frame2: '#1a0726', accent: '#c56bff',
    bg1: '#6b2a86', bg2: '#150520', decor: 'sparks', decorColor: '#f0c2ff',
    titleTop: '#d9ff9e', titleBottom: '#a13fd8',
  },
  tavern: {
    id: 'tavern', label: 'Таверна корсара', frame: 'wood',
    frame1: '#5e3a18', frame2: '#1f1006', accent: '#e8b76a',
    bg1: '#6b431c', bg2: '#180c04', decor: 'none', decorColor: '#ffdda8',
    titleTop: '#fff0c4', titleBottom: '#c07a2c',
  },
  heist: {
    id: 'heist', label: 'Неоновый куш', frame: 'neon',
    frame1: '#0f3f52', frame2: '#04141c', accent: '#2ff0d0',
    bg1: '#0d4f66', bg2: '#03121a', decor: 'sparks', decorColor: '#9ffff0',
    titleTop: '#e8fffb', titleBottom: '#12c9a8',
  },
  clover: {
    id: 'clover', label: 'Золотой клевер', frame: 'wood',
    frame1: '#1f5c2e', frame2: '#07200f', accent: '#7ede8a',
    bg1: '#1d6b33', bg2: '#04180b', decor: 'leaves', decorColor: '#b8f5c0',
    titleTop: '#fff3b0', titleBottom: '#2fae4f',
  },
};

export const themeOf = (id: string): SlotTheme => THEMES[id] ?? THEMES.pack;
