/** Символы барабанов. image — файл в public/slots/<id>.svg */

export type SymTier = 'low' | 'mid' | 'high' | 'wild' | 'bonus' | 'scatter';

export interface SlotSymbolDef {
  id: string;
  label: string;
  image: string;
  /** вес выпадения */
  weight: number;
  tier: SymTier;
  color: string;
  /** множитель за 5 в линию */
  pay5: number;
}

const S = (
  id: string, label: string, weight: number, tier: SymTier, color: string, pay5: number,
): SlotSymbolDef => ({ id, label, image: `/slots/${id}.svg`, weight, tier, color, pay5 });

export const SYMBOLS: Record<string, SlotSymbolDef> = {
  /* ---- low: карточные достоинства ---- */
  sym_10: S('sym_10', '10', 20, 'low', '#22b573', 5),
  sym_j:  S('sym_j',  'J',  19, 'low', '#3b82f6', 6),
  sym_q:  S('sym_q',  'Q',  18, 'low', '#8b5cf6', 7),
  sym_k:  S('sym_k',  'K',  17, 'low', '#e0455a', 8),
  sym_a:  S('sym_a',  'A',  16, 'low', '#f7c948', 10),

  /* ---- mid: предметы ---- */
  gem_red:    S('gem_red',    'Рубин',    12, 'mid', '#e03a46', 14),
  gem_blue:   S('gem_blue',   'Сапфир',   12, 'mid', '#2f6fe0', 14),
  gem_green:  S('gem_green',  'Изумруд',  12, 'mid', '#1fa85e', 15),
  gem_purple: S('gem_purple', 'Аметист',  11, 'mid', '#8b46d8', 16),
  gem_cyan:   S('gem_cyan',   'Аквамарин',11, 'mid', '#2ec9e8', 16),
  coin_stack: S('coin_stack', 'Монеты',   11, 'mid', '#f7c948', 18),
  star_gold:  S('star_gold',  'Звезда',   10, 'mid', '#f7c948', 20),
  bone:       S('bone',       'Кость',    12, 'mid', '#f4ead0', 15),
  paw:        S('paw',        'Лапа',     11, 'mid', '#c98a4b', 17),
  horseshoe:  S('horseshoe',  'Подкова',  11, 'mid', '#f7c948', 17),
  clover:     S('clover',     'Клевер',   11, 'mid', '#2fae4f', 17),
  anchor:     S('anchor',     'Якорь',    11, 'mid', '#b9c6dd', 16),
  lantern:    S('lantern',    'Фонарь',   11, 'mid', '#f7c948', 17),
  barrel:     S('barrel',     'Бочка',    11, 'mid', '#a0642c', 16),
  cherry_pair: S('cherry_pair', 'Вишня',  13, 'mid', '#d81f2c', 13),
  grape_bunch: S('grape_bunch', 'Виноград',12,'mid', '#8b46d8', 15),
  melon_slice: S('melon_slice', 'Арбуз',  12, 'mid', '#e8323f', 15),
  snow_gem:   S('snow_gem',   'Снежинка', 11, 'mid', '#bfe9ff', 17),
  revolver:   S('revolver',   'Револьвер',10, 'mid', '#8894ac', 19),
  pumpkin:    S('pumpkin',    'Тыква',    11, 'mid', '#f0821f', 17),
  cloud_bolt: S('cloud_bolt', 'Молния',   10, 'mid', '#e6efff', 19),
  cash:       S('cash',       'Купюра',   10, 'mid', '#2f9e5e', 20),
  gold_pot:   S('gold_pot',   'Котёл',     9, 'mid', '#f7c948', 22),
  fish:       S('fish',       'Рыба',     11, 'mid', '#3aa7d9', 17),
  seven:      S('seven',      'Семёрка',   7, 'mid', '#e0303a', 30),
  crown:      S('crown',      'Корона',    7, 'mid', '#f7c948', 32),

  /* ---- high: персонажи ---- */
  wolf:       S('wolf',       'Волк',      5, 'high', '#7d879b', 45),
  owl:        S('owl',        'Сова',      5, 'high', '#a9763f', 45),
  cowboy:     S('cowboy',     'Ковбой',    5, 'high', '#a0682f', 48),
  mermaid:    S('mermaid',    'Русалка',   5, 'high', '#2fae8f', 48),
  pirate:     S('pirate',     'Пират',     5, 'high', '#f0c9a0', 50),
  zombie:     S('zombie',     'Зомби',     5, 'high', '#8fbf6a', 50),
  angel:      S('angel',      'Ангел',     5, 'high', '#f2f6ff', 52),
  leprechaun: S('leprechaun', 'Лепрекон',  5, 'high', '#2fae4f', 52),
  queen:      S('queen',      'Королева',  4, 'high', '#7dd3fc', 60),
  jester:     S('jester',     'Шут',       5, 'high', '#d8365a', 50),

  /* ---- специальные ---- */
  wild:    S('wild',    'Wild',    4, 'wild',    '#f7c948', 0),
  bonus:   S('bonus',   'Bonus',   4, 'bonus',   '#ffd964', 0),
  scatter: S('scatter', 'Scatter', 4, 'scatter', '#ffd964', 0),
};

export const symbol = (id: string): SlotSymbolDef => SYMBOLS[id] ?? SYMBOLS.sym_a;

export const WILD = 'wild';
export const BONUS = 'bonus';
export const SCATTER = 'scatter';

/** Множитель Wild выбирается случайно при совпадении линии */
export const WILD_MULTS = [2, 3];

export const TIER_GLOW: Record<SymTier, string> = {
  low: '#8ea2c8',
  mid: '#42d5f5',
  high: '#c77dff',
  wild: '#f7c948',
  bonus: '#ffd964',
  scatter: '#ffd964',
};
