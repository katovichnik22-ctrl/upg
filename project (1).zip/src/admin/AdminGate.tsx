import { lazy, Suspense, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { adminLog, getPin, isAdmin, setAdmin } from './adminCore';
import { audio } from '../lib/audio';

/** Панель грузится только после успешного входа — в обычном бандле её нет */
const AdminPanel = lazy(() => import('./AdminPanel'));

/**
 * Шлюз доступа: ловит серию тапов по логотипу, спрашивает PIN
 * и только затем подгружает панель динамическим импортом.
 */
export default function AdminGate({
  askPin, onDone,
}: {
  /** внешний триггер: пользователь набрал 5 тапов */
  askPin: boolean;
  onDone: () => void;
}) {
  const [stage, setStage] = useState<'idle' | 'pin' | 'open'>(
    () => (isAdmin() ? 'idle' : 'idle'),
  );
  const [pin, setPin] = useState('');
  const [err, setErr] = useState(false);

  useEffect(() => {
    if (!askPin) return;
    /* уже авторизован — открываем сразу */
    if (isAdmin()) { setStage('open'); return; }
    setStage('pin');
    setPin('');
  }, [askPin]);

  const submit = () => {
    if (pin === getPin()) {
      setAdmin(true);
      adminLog('auth', 'вход выполнен');
      audio.coin();
      setStage('open');
    } else {
      setErr(true);
      audio.lose();
      window.setTimeout(() => setErr(false), 600);
      setPin('');
    }
  };

  const close = () => { setStage('idle'); onDone(); };

  if (stage === 'idle') return null;

  if (stage === 'pin') {
    const body = (
      <div className="fixed inset-0 z-[99] grid place-items-center bg-black/90 p-6"
        style={{ minHeight: '100dvh' }} onClick={close}>
        <div className={`panel w-full max-w-[280px] p-5 text-center ${err ? 'shake' : 'pop-in'}`}
          onClick={(e) => e.stopPropagation()}>
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">
            Введите код
          </div>
          <input
            autoFocus type="password" inputMode="numeric" value={pin}
            onChange={(e) => setPin(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
            className="input num w-full px-3 py-3 text-center text-[22px] font-extrabold tracking-[0.4em]"
          />
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button className="btn btn-ghost py-2.5 text-[12px]" onClick={close}>Отмена</button>
            <button className="btn btn-gold py-2.5 text-[12px]" onClick={submit}>Войти</button>
          </div>
        </div>
      </div>
    );
    return typeof document === 'undefined' ? null : createPortal(body, document.body);
  }

  return (
    <Suspense fallback={null}>
      <AdminPanel onClose={close} />
    </Suspense>
  );
}
