import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Coins, Package, Gamepad2, Users, BarChart3, Settings2, Ticket, LogOut,
} from 'lucide-react';
import {
  adminLog, readAdminLog, clearAdminLog, getOverrides, setOverrides, resetOverrides,
  readPromos, writePromos, readProfiles, patchProfile, setAdmin, setPin, getPin,
  type Overrides, type Promo, type ProfileRow,
} from './adminCore';
import { useGame, useSkins } from '../lib/store';
import { fmt } from '../lib/skins';
import { SkinImage } from '../components/ui';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';

type Tab = 'money' | 'inv' | 'games' | 'profiles' | 'stats' | 'sys' | 'promo';

const TABS: Array<{ id: Tab; label: string; icon: typeof Coins }> = [
  { id: 'money', label: 'Деньги', icon: Coins },
  { id: 'inv', label: 'Инвентарь', icon: Package },
  { id: 'games', label: 'Игры', icon: Gamepad2 },
  { id: 'profiles', label: 'Профили', icon: Users },
  { id: 'stats', label: 'Аналитика', icon: BarChart3 },
  { id: 'sys', label: 'Система', icon: Settings2 },
  { id: 'promo', label: 'Промо', icon: Ticket },
];

/** Автовыход при бездействии */
const IDLE_MS = 30 * 60 * 1000;

export default function AdminPanel({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('money');
  const [ovr, setOvr] = useState<Overrides>(() => getOverrides());
  const idle = useRef(Date.now());

  const patch = (p: Partial<Overrides>) => {
    setOvr(setOverrides(p));
    adminLog('override', JSON.stringify(p));
  };

  /* блокируем прокрутку фона */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  /* автоматический выход через 30 минут неактивности */
  useEffect(() => {
    const touch = () => { idle.current = Date.now(); };
    for (const e of ['pointerdown', 'keydown']) window.addEventListener(e, touch);
    const t = window.setInterval(() => {
      if (Date.now() - idle.current > IDLE_MS) { adminLog('auth', 'автовыход'); onClose(); }
    }, 30000);
    return () => {
      for (const e of ['pointerdown', 'keydown']) window.removeEventListener(e, touch);
      window.clearInterval(t);
    };
  }, [onClose]);

  const body = (
    <div className="fixed inset-0 z-[99] flex flex-col bg-[#07090f]" style={{ minHeight: '100dvh' }}>
      {/* шапка */}
      <div className="flex items-center gap-2 border-b border-rose-500/25 bg-rose-950/20 px-3 py-2.5"
        style={{ paddingTop: 'max(10px,env(safe-area-inset-top))' }}>
        <span className="rounded-md bg-rose-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-rose-300">
          admin
        </span>
        <span className="min-w-0 flex-1 truncate font-display text-[13px] font-extrabold">
          Панель управления
        </span>
        <button onClick={() => { adminLog('auth', 'выход'); setAdmin(false); onClose(); }}
          className="chip !min-h-0 px-2 py-1.5"><LogOut size={13} /></button>
        <button onClick={onClose} className="chip !min-h-0 px-2 py-1.5"><X size={14} /></button>
      </div>

      {/* вкладки */}
      <div className="chip-row border-b border-white/8 px-2 py-2">
        {TABS.map((t) => (
          <button key={t.id} className={cn('chip', tab === t.id && 'on')}
            onClick={() => { audio.click(); setTab(t.id); }}>
            <t.icon size={12} className="mr-1" />{t.label}
          </button>
        ))}
      </div>

      {/* содержимое */}
      <div className="flex-1 overflow-y-auto p-3"
        style={{ paddingBottom: 'max(16px,env(safe-area-inset-bottom))' }}>
        {tab === 'money' && <MoneyTab ovr={ovr} patch={patch} />}
        {tab === 'inv' && <InvTab />}
        {tab === 'games' && <GamesTab ovr={ovr} patch={patch} />}
        {tab === 'profiles' && <ProfilesTab />}
        {tab === 'stats' && <StatsTab />}
        {tab === 'sys' && <SysTab ovr={ovr} patch={patch} onClose={onClose} />}
        {tab === 'promo' && <PromoTab ovr={ovr} patch={patch} />}
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(body, document.body);
}

/* ------------------------------------------------------------------ */

const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="panel-inset flex items-center gap-2 p-2.5">
    <span className="min-w-0 flex-1 text-[11.5px] font-bold text-slate-300">{label}</span>
    {children}
  </div>
);

const Block = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="panel p-3">
    <div className="mb-2 font-display text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">
      {title}
    </div>
    <div className="space-y-1.5">{children}</div>
  </div>
);

const Tgl = ({ on, onClick }: { on: boolean; onClick: () => void }) => (
  <button className={cn('tgl shrink-0', on && 'on')} onClick={onClick} />
);

/* ---------------- ДЕНЬГИ ---------------- */
function MoneyTab({ ovr, patch }: { ovr: Overrides; patch: (p: Partial<Overrides>) => void }) {
  const { state, adjust, toast } = useGame();
  const [val, setVal] = useState('');

  const setBalance = () => {
    const v = Math.max(0, Number(val) || 0);
    adjust(v - state.balance);
    adminLog('money', `баланс = ${v}`);
    toast('Баланс установлен', 'win', fmt(v));
  };

  return (
    <div className="space-y-2.5">
      <Block title={`Баланс · ${fmt(state.balance)}`}>
        <div className="flex gap-2">
          <input value={val} onChange={(e) => setVal(e.target.value)} type="number"
            placeholder="Новый баланс" className="input num flex-1 px-3 py-2.5 text-[13px]" />
          <button onClick={setBalance} className="btn btn-gold px-4 text-[12px]">Задать</button>
        </div>
        <div className="chip-row">
          {([['+1к', 1000], ['+10к', 10000], ['+100к', 100000],
             ['−1к', -1000], ['−10к', -10000]] as const).map(([l, v]) => (
            <button key={l} className="chip num" onClick={() => {
              adjust(v); adminLog('money', `${v > 0 ? '+' : ''}${v}`);
            }}>{l}</button>
          ))}
          <button className="chip" onClick={() => {
            adjust(-state.balance); adminLog('money', 'обнуление');
          }}>Обнулить</button>
        </div>
      </Block>

      <Block title="Множитель выигрыша">
        <div className="chip-row">
          {[1, 2, 5, 10].map((m) => (
            <button key={m} className={cn('chip num', ovr.winMult === m && 'on')}
              onClick={() => patch({ winMult: m })}>×{m}</button>
          ))}
        </div>
      </Block>

      <Block title="Целевой RTP модулей (0 = штатный)">
        {([['Апгрейдер', 'rtpUpgrader'], ['Рулетка', 'rtpRoulette'], ['Слоты', 'rtpSlots']] as const)
          .map(([label, key]) => (
            <div key={key} className="panel-inset p-2.5">
              <div className="mb-1 flex justify-between text-[11px]">
                <span className="font-bold text-slate-300">{label}</span>
                <span className="num text-gold">{ovr[key] || '—'}{ovr[key] ? '%' : ''}</span>
              </div>
              <input type="range" min={0} max={120} value={ovr[key]}
                onChange={(e) => patch({ [key]: Number(e.target.value) } as Partial<Overrides>)}
                className="w-full" style={{ '--p': `${(ovr[key] / 120) * 100}%` } as React.CSSProperties} />
            </div>
          ))}
      </Block>

      <Block title="Лимиты ставок (0 = штатные)">
        <Row label="Минимальная">
          <input type="number" value={ovr.minBet} onChange={(e) => patch({ minBet: Number(e.target.value) || 0 })}
            className="input num w-24 px-2 py-1.5 text-center text-[12px]" />
        </Row>
        <Row label="Максимальная">
          <input type="number" value={ovr.maxBet} onChange={(e) => patch({ maxBet: Number(e.target.value) || 0 })}
            className="input num w-24 px-2 py-1.5 text-center text-[12px]" />
        </Row>
      </Block>
    </div>
  );
}

/* ---------------- ИНВЕНТАРЬ ---------------- */
function InvTab() {
  const { state, addItem, sellAll, toast } = useGame();
  const { skins } = useSkins();
  const [q, setQ] = useState('');
  const [json, setJson] = useState('');

  const found = useMemo(() => {
    if (!q.trim()) return [];
    const t = q.trim().toLowerCase();
    return skins.filter((s) => s.name.toLowerCase().includes(t)).slice(0, 12);
  }, [q, skins]);

  const giveKnives = () => {
    const knives = skins.filter((s) => s.star && !/gloves|wraps/i.test(s.weapon)).slice(0, 20);
    for (const k of knives) addItem(k);
    adminLog('inventory', `выдано ножей: ${knives.length}`);
    toast('Ножи выданы', 'win', `${knives.length} шт.`);
  };

  const exportInv = () => {
    setJson(JSON.stringify(state.inventory, null, 1));
    adminLog('inventory', 'экспорт');
  };

  const importInv = () => {
    try {
      const list = JSON.parse(json) as Array<{ name: string }>;
      for (const it of list) {
        const live = skins.find((s) => s.name === it.name);
        if (live) addItem(live);
      }
      adminLog('inventory', `импорт: ${list.length}`);
      toast('Импортировано', 'win', `${list.length} предметов`);
    } catch { toast('Неверный JSON', 'lose'); }
  };

  return (
    <div className="space-y-2.5">
      <Block title={`Выдать предмет · в инвентаре ${state.inventory.length}`}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию…"
          className="input w-full px-3 py-2.5 text-[13px]" />
        {found.map((s) => (
          <button key={s.id} onClick={() => {
            addItem(s); adminLog('inventory', `выдан ${s.name}`); toast('Выдано', 'win', s.name);
          }} className="panel-inset flex w-full items-center gap-2 p-2 text-left">
            <SkinImage skin={s} className="h-7 w-10 shrink-0" />
            <span className="min-w-0 flex-1 truncate text-[11px]" style={{ color: s.color }}>{s.name}</span>
            <span className="num price text-[10px] font-bold">{fmt(s.price)}</span>
          </button>
        ))}
      </Block>

      <Block title="Быстрые действия">
        <div className="chip-row">
          <button className="chip" onClick={giveKnives}>Все ножи ×20</button>
          <button className="chip" onClick={() => {
            const top = [...skins].sort((a, b) => b.price - a.price).slice(0, 10);
            top.forEach(addItem);
            adminLog('inventory', 'выдан топ-10');
          }}>Топ-10 дорогих</button>
          <button className="chip" onClick={() => {
            sellAll(); adminLog('inventory', 'очистка');
          }}>Очистить</button>
        </div>
      </Block>

      <Block title="Экспорт / импорт">
        <div className="chip-row">
          <button className="chip" onClick={exportInv}>Выгрузить JSON</button>
          <button className="chip" onClick={importInv} disabled={!json.trim()}>Загрузить</button>
        </div>
        <textarea value={json} onChange={(e) => setJson(e.target.value)} rows={5}
          placeholder="JSON инвентаря" className="input num w-full resize-none p-2 text-[9px]" />
      </Block>
    </div>
  );
}

/* ---------------- ИГРЫ ---------------- */
function GamesTab({ ovr, patch }: { ovr: Overrides; patch: (p: Partial<Overrides>) => void }) {
  const { state, unlockSlot, toast } = useGame();

  return (
    <div className="space-y-2.5">
      <Block title="Форсировать результат">
        <div className="chip-row">
          {([['Честно', 'off'], ['Всегда win', 'win'], ['Всегда lose', 'lose']] as const).map(([l, v]) => (
            <button key={v} className={cn('chip', ovr.force === v && 'on')}
              onClick={() => patch({ force: v })}>{l}</button>
          ))}
        </div>
        <Row label="Конкретное число (рулетка)">
          <input type="number" value={ovr.forceNumber ?? ''} placeholder="—"
            onChange={(e) => patch({ forceNumber: e.target.value === '' ? null : Number(e.target.value) })}
            className="input num w-20 px-2 py-1.5 text-center text-[12px]" />
        </Row>
      </Block>

      <Block title="Поведение">
        <Row label="Мгновенный результат (без анимации)">
          <Tgl on={ovr.noAnim} onClick={() => patch({ noAnim: !ovr.noAnim })} />
        </Row>
        <Row label={`Разблокировать все слоты (${state.unlockedSlots.length})`}>
          <button className="chip" onClick={async () => {
            const { SLOTS } = await import('../data/slots');
            SLOTS.forEach((s) => unlockSlot(s.id));
            adminLog('games', 'разблокированы все слоты');
            toast('Слоты открыты', 'win', `${SLOTS.length} шт.`);
          }}>Открыть</button>
        </Row>
      </Block>

      <Block title="Сброс статистики">
        <div className="chip-row">
          {['Апгрейдер', 'Казино', 'Кейсы', 'Всё'].map((m) => (
            <button key={m} className="chip" onClick={() => {
              adminLog('games', `сброс статистики: ${m}`);
              toast('Статистика сброшена', 'info', m);
            }}>{m}</button>
          ))}
        </div>
      </Block>
    </div>
  );
}

/* ---------------- ПРОФИЛИ ---------------- */
function ProfilesTab() {
  const { profiles, activeProfile, switchProfile, deleteProfile, toast } = useGame();
  const [rows, setRows] = useState<ProfileRow[]>(() => readProfiles());
  const refresh = () => setRows(readProfiles());

  return (
    <div className="space-y-2.5">
      <Block title={`Профили · ${rows.length}`}>
        {rows.map((p) => (
          <div key={p.id} className={cn('panel-inset p-2.5',
            p.id === activeProfile && 'border-gold/50')}>
            <div className="flex items-center gap-2">
              <span className="min-w-0 flex-1 truncate text-[12px] font-extrabold">{p.name}</span>
              <span className="rounded bg-emerald-400/15 px-1.5 py-0.5 text-[8.5px] font-bold uppercase text-emerald-300">
                кликер
              </span>
            </div>
            <div className="num mt-0.5 text-[9.5px] text-slate-500">
              {fmt(p.balance)} · {p.items} предм. · оборот {fmt(p.wagered)}
            </div>
            <div className="chip-row mt-1.5">
              {p.id !== activeProfile && (
                <button className="chip" onClick={() => { switchProfile(p.id); refresh(); }}>Войти</button>
              )}
              <button className="chip" onClick={() => {
                const name = prompt('Новое имя', p.name);
                if (name) { patchProfile(p.id, { name }); adminLog('profile', `переименован ${p.id}`); refresh(); }
              }}>Имя</button>
              <button className="chip" onClick={() => {
                const give = Number(prompt('Начислить на баланс профиля', '10000') ?? '0');
                if (!give) return;
                patchProfile(p.id, { balance: p.balance + give });
                adminLog('profile', `баланс ${p.id} += ${give}`);
                toast('Баланс изменён', 'win', fmt(p.balance + give));
                refresh();
              }}>Деньги</button>
              <button className="chip" onClick={() => {
                patchProfile(p.id, { balance: 0, inventory: [], history: [] });
                adminLog('profile', `сброс ${p.id}`);
                refresh();
              }}>Сброс</button>
              {profiles.length > 1 && (
                <button className="chip" onClick={() => {
                  deleteProfile(p.id); adminLog('profile', `удалён ${p.id}`); setTimeout(refresh, 60);
                }}>Удалить</button>
              )}
            </div>
          </div>
        ))}
      </Block>
    </div>
  );
}

/* ---------------- АНАЛИТИКА ---------------- */
function StatsTab() {
  const { state } = useGame();
  const canvas = useRef<HTMLCanvasElement>(null);
  const [filter, setFilter] = useState('all');

  const hist = useMemo(
    () => state.history.filter((h) => filter === 'all' || h.kind === filter),
    [state.history, filter],
  );

  const s = state.stats;
  const realRtp = s.wagered > 0 ? ((s.wagered + state.history.reduce((a, h) => a + h.amount, 0)) / s.wagered) * 100 : 0;
  const avgTicket = s.gamesPlayed > 0 ? s.wagered / s.gamesPlayed : 0;

  /* простой график RTP по последним операциям */
  useEffect(() => {
    const cv = canvas.current;
    const ctx = cv?.getContext('2d');
    if (!cv || !ctx) return;
    const w = cv.width = cv.clientWidth * 2;
    const h = cv.height = 120 * 2;
    ctx.clearRect(0, 0, w, h);
    const pts = [...state.history].reverse().slice(-60);
    if (pts.length < 2) return;
    let bal = 0;
    const vals = pts.map((p) => (bal += p.amount));
    const min = Math.min(...vals, 0), max = Math.max(...vals, 1);
    ctx.strokeStyle = '#f6c445'; ctx.lineWidth = 4; ctx.beginPath();
    vals.forEach((v, i) => {
      const x = (i / (vals.length - 1)) * w;
      const y = h - ((v - min) / (max - min || 1)) * (h - 16) - 8;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.15)'; ctx.lineWidth = 2;
    const zero = h - ((0 - min) / (max - min || 1)) * (h - 16) - 8;
    ctx.beginPath(); ctx.moveTo(0, zero); ctx.lineTo(w, zero); ctx.stroke();
  }, [state.history]);

  const exportCsv = () => {
    const rows = ['time,kind,text,amount', ...state.history.map(
      (h) => `${new Date(h.time).toISOString()},${h.kind},"${h.text.replace(/"/g, "'")}",${h.amount}`)];
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'nikgrager-log.csv';
    a.click();
    adminLog('stats', 'экспорт CSV');
  };

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-2 gap-1.5">
        {[
          ['Игр всего', String(s.gamesPlayed + s.upgrades)],
          ['Фактический RTP', `${realRtp.toFixed(1)}%`],
          ['Средний чек', fmt(avgTicket)],
          ['Лучший выигрыш', fmt(s.bestWin)],
        ].map(([k, v]) => (
          <div key={k} className="panel-inset p-2 text-center">
            <div className="num truncate text-[13px] font-extrabold text-gold">{v}</div>
            <div className="text-[8.5px] uppercase tracking-wider text-slate-500">{k}</div>
          </div>
        ))}
      </div>

      <Block title="График баланса">
        <canvas ref={canvas} className="h-[120px] w-full" />
      </Block>

      <Block title={`История · ${hist.length}`}>
        <div className="chip-row">
          {['all', 'upgrade', 'game', 'case', 'shop'].map((f) => (
            <button key={f} className={cn('chip', filter === f && 'on')}
              onClick={() => setFilter(f)}>{f === 'all' ? 'Все' : f}</button>
          ))}
          <button className="chip" onClick={exportCsv}>CSV</button>
        </div>
        <div className="max-h-[260px] space-y-1 overflow-y-auto">
          {hist.slice(0, 60).map((h) => (
            <div key={h.id} className="panel-inset flex items-center gap-2 px-2 py-1.5">
              <span className="min-w-0 flex-1 truncate text-[10px] text-slate-400">{h.text}</span>
              <span className={cn('num shrink-0 text-[10px] font-bold',
                h.amount >= 0 ? 'text-emerald-300' : 'text-rose-300')}>
                {h.amount >= 0 ? '+' : ''}{Math.round(h.amount)}
              </span>
            </div>
          ))}
        </div>
      </Block>

      <Block title="Журнал админа">
        <div className="max-h-[160px] space-y-1 overflow-y-auto">
          {readAdminLog().slice(0, 40).map((l, i) => (
            <div key={i} className="num panel-inset px-2 py-1 text-[9px] text-slate-500">
              {new Date(l.ts).toLocaleString('ru-RU')} · {l.type} · {l.detail.slice(0, 60)}
            </div>
          ))}
        </div>
        <button className="chip" onClick={clearAdminLog}>Очистить журнал</button>
      </Block>
    </div>
  );
}

/* ---------------- СИСТЕМА ---------------- */
function SysTab({ ovr, patch, onClose }: {
  ovr: Overrides; patch: (p: Partial<Overrides>) => void; onClose: () => void;
}) {
  const [fps, setFps] = useState(0);
  const [mem, setMem] = useState(0);
  const [pin, setPinVal] = useState('');

  useEffect(() => {
    let frames = 0, last = performance.now(), raf = 0;
    const loop = (t: number) => {
      frames++;
      if (t - last >= 1000) {
        setFps(frames); frames = 0; last = t;
        const m = (performance as Performance & { memory?: { usedJSHeapSize: number } }).memory;
        if (m) setMem(Math.round(m.usedJSHeapSize / 1048576));
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="space-y-2.5">
      <Block title="Режимы">
        <Row label="Режим бога (всегда победа, ×10 выплата)">
          <Tgl on={ovr.god} onClick={() => patch({ god: !ovr.god })} />
        </Row>
        <Row label="Офлайн (только встроенная база)">
          <Tgl on={ovr.offline} onClick={() => patch({ offline: !ovr.offline })} />
        </Row>
        <Row label="Показывать служебные поля">
          <Tgl on={ovr.showHidden} onClick={() => patch({ showHidden: !ovr.showHidden })} />
        </Row>
      </Block>

      <Block title="Диагностика">
        <div className="grid grid-cols-3 gap-1.5">
          {[['FPS', String(fps)], ['Память', mem ? `${mem} МБ` : '—'],
            ['Ядра', String(navigator.hardwareConcurrency ?? '—')]].map(([k, v]) => (
            <div key={k} className="panel-inset p-2 text-center">
              <div className="num text-[13px] font-extrabold text-gold">{v}</div>
              <div className="text-[8.5px] uppercase text-slate-500">{k}</div>
            </div>
          ))}
        </div>
      </Block>

      <Block title="PIN-код входа">
        <div className="flex gap-2">
          <input value={pin} onChange={(e) => setPinVal(e.target.value)} placeholder={`текущий: ${getPin()}`}
            className="input num flex-1 px-3 py-2.5 text-[13px]" />
          <button className="btn btn-gold px-4 text-[12px]" onClick={() => {
            if (pin.length >= 4) { setPin(pin); adminLog('auth', 'смена PIN'); setPinVal(''); }
          }}>Сменить</button>
        </div>
      </Block>

      <Block title="Опасная зона">
        <button className="btn btn-ghost w-full py-2.5 text-[12px]" onClick={() => {
          resetOverrides(); adminLog('system', 'сброс переопределений');
        }}>Сбросить все переопределения</button>
        <button className="btn btn-red w-full py-2.5 text-[12px]" onClick={() => {
          if (confirm('Полностью стереть localStorage?')) {
            localStorage.clear(); location.reload();
          }
        }}>Стереть localStorage</button>
        <button className="btn btn-ghost w-full py-2.5 text-[12px]" onClick={onClose}>Закрыть панель</button>
      </Block>
    </div>
  );
}

/* ---------------- ПРОМО ---------------- */
function PromoTab({ ovr, patch }: { ovr: Overrides; patch: (p: Partial<Overrides>) => void }) {
  const { toast } = useGame();
  const [list, setList] = useState<Promo[]>(() => readPromos());
  const [code, setCode] = useState('');
  const [amount, setAmount] = useState(1000);
  const [limit, setLimit] = useState(10);

  const add = () => {
    if (!code.trim()) return;
    const next = [...list, {
      code: code.trim().toUpperCase(), kind: 'money' as const,
      amount, limit, used: 0,
    }];
    setList(next); writePromos(next);
    adminLog('promo', `создан ${code}`);
    toast('Промокод создан', 'win', code.toUpperCase());
    setCode('');
  };

  return (
    <div className="space-y-2.5">
      <Block title="Новый промокод">
        <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="NIKGRAGER2024"
          className="input w-full px-3 py-2.5 text-[13px] uppercase" />
        <div className="flex gap-2">
          <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)}
            className="input num flex-1 px-3 py-2 text-center text-[12px]" placeholder="сумма" />
          <input type="number" value={limit} onChange={(e) => setLimit(Number(e.target.value) || 1)}
            className="input num w-20 px-2 py-2 text-center text-[12px]" placeholder="лимит" />
        </div>
        <button onClick={add} className="btn btn-gold w-full py-2.5 text-[12px]">Создать</button>
      </Block>

      <Block title={`Активные · ${list.length}`}>
        {list.length === 0 && <div className="py-3 text-center text-[11px] text-slate-500">Пусто</div>}
        {list.map((p, i) => (
          <div key={p.code} className="panel-inset flex items-center gap-2 p-2">
            <span className="num min-w-0 flex-1 truncate text-[11px] font-extrabold text-gold">{p.code}</span>
            <span className="num text-[10px] text-slate-400">{fmt(p.amount)} · {p.used}/{p.limit}</span>
            <button className="chip !min-h-0 px-2 py-1" onClick={() => {
              const next = list.filter((_, j) => j !== i);
              setList(next); writePromos(next); adminLog('promo', `удалён ${p.code}`);
            }}><X size={11} /></button>
          </div>
        ))}
      </Block>

      <Block title="Ежедневный бонус">
        <Row label="Включён">
          <Tgl on={ovr.dailyOn} onClick={() => patch({ dailyOn: !ovr.dailyOn })} />
        </Row>
        <Row label="Размер">
          <input type="number" value={ovr.dailySize}
            onChange={(e) => patch({ dailySize: Number(e.target.value) || 0 })}
            className="input num w-24 px-2 py-1.5 text-center text-[12px]" />
        </Row>
      </Block>

      <Block title="Рассылка">
        <button className="btn btn-ghost w-full py-2.5 text-[12px]" onClick={() => {
          toast('Сообщение от администрации', 'info', 'Тестовая рассылка');
          adminLog('promo', 'рассылка тоста');
        }}>Отправить тест-уведомление</button>
      </Block>
    </div>
  );
}
