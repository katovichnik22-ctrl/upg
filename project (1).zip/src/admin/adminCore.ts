/** Ядро админ-панели: доступ, флаги, журнал действий */

const K_PIN = 'nikgrager-admin-pin';
const K_FLAG = 'nikgrager-admin-on';
const K_LOG = 'nikgrager-admin-log';
const K_OVR = 'nikgrager-admin-overrides';
const K_PROMO = 'nikgrager-promos';

export const DEFAULT_PIN = '15121978';

export const getPin = (): string => {
  try { return localStorage.getItem(K_PIN) ?? DEFAULT_PIN; } catch { return DEFAULT_PIN; }
};
export const setPin = (p: string) => {
  try { localStorage.setItem(K_PIN, p); } catch { /* нет места */ }
};

export const isAdmin = (): boolean => {
  try { return localStorage.getItem(K_FLAG) === '1'; } catch { return false; }
};
export const setAdmin = (v: boolean) => {
  try {
    if (v) localStorage.setItem(K_FLAG, '1');
    else localStorage.removeItem(K_FLAG);
  } catch { /* нет места */ }
};

/* ------------------------------------------------------------------ */
/*  Журнал действий администратора                                     */
/* ------------------------------------------------------------------ */

export interface AdminLogEntry {
  ts: number;
  type: string;
  detail: string;
}

export function adminLog(type: string, detail: string): void {
  try {
    const list: AdminLogEntry[] = JSON.parse(localStorage.getItem(K_LOG) ?? '[]');
    list.unshift({ ts: Date.now(), type, detail });
    localStorage.setItem(K_LOG, JSON.stringify(list.slice(0, 500)));
  } catch { /* нет места */ }
}

export function readAdminLog(): AdminLogEntry[] {
  try { return JSON.parse(localStorage.getItem(K_LOG) ?? '[]'); } catch { return []; }
}

export function clearAdminLog(): void {
  try { localStorage.removeItem(K_LOG); } catch { /* нет записи */ }
}

/* ------------------------------------------------------------------ */
/*  Переопределения механик (читаются игровыми модулями)               */
/* ------------------------------------------------------------------ */

export interface Overrides {
  /** множитель всех выплат */
  winMult: number;
  /** целевой RTP по модулям, 0 = не трогать */
  rtpUpgrader: number;
  rtpRoulette: number;
  rtpSlots: number;
  /** лимиты ставок, 0 = по умолчанию */
  minBet: number;
  maxBet: number;
  /** принудительный исход следующего раунда */
  force: 'off' | 'win' | 'lose';
  forceNumber: number | null;
  /** мгновенный результат без анимации */
  noAnim: boolean;
  /** режим бога: бесконечный баланс и всегда победа */
  god: boolean;
  /** работать только на встроенной базе */
  offline: boolean;
  /** показывать служебные поля */
  showHidden: boolean;
  /** ежедневный бонус */
  dailyOn: boolean;
  dailySize: number;
}

export const DEFAULT_OVERRIDES: Overrides = {
  winMult: 1,
  rtpUpgrader: 0, rtpRoulette: 0, rtpSlots: 0,
  minBet: 0, maxBet: 0,
  force: 'off', forceNumber: null,
  noAnim: false, god: false, offline: false, showHidden: false,
  dailyOn: true, dailySize: 500,
};

let cache: Overrides | null = null;

export function getOverrides(): Overrides {
  if (cache) return cache;
  let next: Overrides = { ...DEFAULT_OVERRIDES };
  try {
    const raw = localStorage.getItem(K_OVR);
    if (raw) next = { ...DEFAULT_OVERRIDES, ...JSON.parse(raw) };
  } catch { /* повреждённая запись — остаются значения по умолчанию */ }
  cache = next;
  return next;
}

export function setOverrides(p: Partial<Overrides>): Overrides {
  const next = { ...getOverrides(), ...p };
  cache = next;
  try { localStorage.setItem(K_OVR, JSON.stringify(next)); } catch { /* нет места */ }
  window.dispatchEvent(new CustomEvent('ng-overrides'));
  return next;
}

export function resetOverrides(): void {
  cache = { ...DEFAULT_OVERRIDES };
  try { localStorage.removeItem(K_OVR); } catch { /* нет записи */ }
  window.dispatchEvent(new CustomEvent('ng-overrides'));
}

/**
 * Применяет админские правки к результату игры.
 * Вызывается игровыми модулями — вне админки работает как «ничего не делать».
 */
export function applyWin(payout: number): number {
  const o = getOverrides();
  if (o.god) return Math.max(payout, 1) * 10;
  return Math.round(payout * o.winMult);
}

/** Принудительный исход: true = победа, false = поражение, null = честно */
export function forcedOutcome(): boolean | null {
  const o = getOverrides();
  if (o.god) return true;
  if (o.force === 'win') return true;
  if (o.force === 'lose') return false;
  return null;
}

/* ------------------------------------------------------------------ */
/*  Промокоды                                                          */
/* ------------------------------------------------------------------ */

export interface Promo {
  code: string;
  kind: 'money' | 'skin';
  amount: number;
  skinName?: string;
  limit: number;
  used: number;
}

export const readPromos = (): Promo[] => {
  try { return JSON.parse(localStorage.getItem(K_PROMO) ?? '[]'); } catch { return []; }
};
export const writePromos = (list: Promo[]) => {
  try { localStorage.setItem(K_PROMO, JSON.stringify(list)); } catch { /* нет места */ }
};

/** Список всех профилей для вкладки «Профили» */
export interface ProfileRow {
  id: string;
  name: string;
  balance: number;
  items: number;
  economy: string;
  wagered: number;
}

export function readProfiles(): ProfileRow[] {
  try {
    const idx = JSON.parse(localStorage.getItem('nikgrager-profiles-v1') ?? '{}');
    const list: Array<{ id: string; name: string }> = idx.list ?? [];
    return list.map((p) => {
      let data: Record<string, unknown> = {};
      try { data = JSON.parse(localStorage.getItem(`upgrader-save-v2::${p.id}`) ?? '{}'); } catch { /* пусто */ }
      const stats = (data.stats ?? {}) as { wagered?: number };
      return {
        id: p.id,
        name: (data.name as string) ?? p.name,
        balance: (data.balance as number) ?? 0,
        items: Array.isArray(data.inventory) ? data.inventory.length : 0,
        economy: (data.economy as string) ?? 'donate',
        wagered: stats.wagered ?? 0,
      };
    });
  } catch { return []; }
}

/** Прямая правка сохранения профиля (для вкладки «Профили») */
export function patchProfile(id: string, patch: Record<string, unknown>): void {
  const key = `upgrader-save-v2::${id}`;
  try {
    const data = JSON.parse(localStorage.getItem(key) ?? '{}');
    localStorage.setItem(key, JSON.stringify({ ...data, ...patch }));
  } catch { /* нет записи */ }
}
