/** Типы предметов маркета CS2 */

export type ItemType =
  | 'skin'      // оружие
  | 'knife'     // ножи (★)
  | 'glove'     // перчатки (★)
  | 'sticker'   // наклейки
  | 'music'     // музыкальные наборы
  | 'case'      // кейсы
  | 'capsule'   // капсулы
  | 'graffiti'  // графити
  | 'charm'     // брелоки
  | 'agent';    // агенты

/** Износ (exterior) */
export type Wear = 'FN' | 'MW' | 'FT' | 'WW' | 'BS';

export type RarityId =
  | 'consumer'
  | 'industrial'
  | 'milspec'
  | 'restricted'
  | 'classified'
  | 'covert'
  | 'contraband'
  | 'extraordinary';

export interface RarityInfo {
  id: RarityId;
  /** оригинальное имя из API */
  api: string;
  ru: string;
  color: string;
}

/** Категория оружия для фильтров магазина */
export type WeaponCat =
  | 'rifle' | 'pistol' | 'smg' | 'heavy' | 'sniper'
  | 'knife' | 'glove' | 'other';

/** Единый предмет маркета */
export interface MarketItem {
  id: string;
  /** полное рыночное имя */
  name: string;
  /** оружие / коллекция */
  weapon: string;
  type: ItemType;
  cat: WeaponCat;
  rarity: string;
  rarityRu: string;
  color: string;
  /** цена в рублях за текущий износ/вариант */
  price: number;
  image: string;
  wear?: Wear;
  stattrak?: boolean;
  souvenir?: boolean;
  /** ★ нож или перчатки */
  star: boolean;
}
