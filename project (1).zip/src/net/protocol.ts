import type { Skin } from '../lib/types';

/** Версия протокола — несовместимые пиры отсекаются на hello */
export const PROTO_VERSION = 1;

export interface PeerIdentity {
  id: string;
  name: string;
  level: number;
}

/** Предмет, передаваемый по сети (без локальных uid-ов хранилища) */
export interface NetItem {
  uid: string;
  name: string;
  price: number;
  color: string;
  image: string;
  rarity: string;
  rarityRu: string;
  weapon: string;
  star: boolean;
}

export const toNetItem = (s: Skin & { uid?: string }): NetItem => ({
  uid: s.uid ?? s.id,
  name: s.name,
  price: s.price,
  color: s.color,
  image: s.image,
  rarity: s.rarity,
  rarityRu: s.rarityRu,
  weapon: s.weapon,
  star: s.star,
});

/* ------------------------------------------------------------------ */
/*  Сообщения                                                          */
/* ------------------------------------------------------------------ */

export type Msg =
  | { t: 'hello'; v: number; me: PeerIdentity }
  | { t: 'ping'; ts: number }
  | { t: 'pong'; ts: number }
  | { t: 'chat'; id: string; text: string; ts: number }
  | { t: 'chat:seen'; ids: string[] }

  /* --- обмен предметами --- */
  | { t: 'trade:open' }
  | { t: 'trade:offer'; items: NetItem[] }
  | { t: 'trade:lock'; locked: boolean }
  | { t: 'trade:confirm' }
  | { t: 'trade:cancel'; reason?: string }
  | { t: 'trade:done' }

  /* --- дуэль 1v1 --- */
  | { t: 'duel:invite'; stake: NetItem[] }
  | { t: 'duel:accept'; stake: NetItem[] }
  | { t: 'duel:decline' }
  | { t: 'duel:commit'; hash: string }
  | { t: 'duel:reveal'; seed: string }
  | { t: 'duel:result'; roll: number; winner: string }

  /* --- баттл-рояль --- */
  | { t: 'battle:join'; me: PeerIdentity; stake: NetItem[] }
  | { t: 'battle:state'; players: BattlePlayer[]; phase: BattlePhase }
  | { t: 'battle:commit'; hash: string }
  | { t: 'battle:reveal'; seed: string }
  | { t: 'battle:start' }
  | { t: 'battle:result'; roll: number; winner: string }
  | { t: 'battle:leave' };

export type BattlePhase = 'lobby' | 'commit' | 'reveal' | 'spin' | 'done';

export interface BattlePlayer {
  id: string;
  name: string;
  stake: NetItem[];
  /** суммарная стоимость вклада — определяет размер сектора */
  value: number;
  ready: boolean;
}

/* ------------------------------------------------------------------ */
/*  Локальные сущности                                                 */
/* ------------------------------------------------------------------ */

export interface Friend {
  id: string;
  name: string;
  /** последний рабочий код подключения */
  code?: string;
  added: number;
  lastSeen: number;
}

export interface ChatMsg {
  id: string;
  from: 'me' | 'them';
  text: string;
  ts: number;
  /** не доставлено — лежит в оффлайн-очереди */
  pending?: boolean;
}

export const REACTIONS = ['👍', '🔥', '😂', '😮', '💀', 'GG'];
