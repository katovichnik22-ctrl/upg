import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState,
} from 'react';
import { Room, myPeerId, type RoomState } from './room';
import type { ChatMsg, Friend, Msg, PeerIdentity } from './protocol';
import { PROTO_VERSION } from './protocol';

const K_FRIENDS = 'nikgrager-friends';
const K_CHAT = (id: string) => `nikgrager-chat-${id}`;
const K_ROOMS = 'nikgrager-rooms';
const K_NET = 'nikgrager-net-settings';

export interface NetSettings {
  /** свой брокер комнат; пусто = публичный по умолчанию */
  signal: string;
  autoConnect: boolean;
}

const loadJSON = <T,>(k: string, def: T): T => {
  try {
    const raw = localStorage.getItem(k);
    return raw ? { ...def, ...JSON.parse(raw) } as T : def;
  } catch { return def; }
};
const loadArr = <T,>(k: string): T[] => {
  try { return JSON.parse(localStorage.getItem(k) ?? '[]') as T[]; } catch { return []; }
};
const save = (k: string, v: unknown) => {
  try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* нет места */ }
};

interface NetCtx {
  myId: string;
  me: PeerIdentity;
  state: RoomState;
  /** короткий код текущей комнаты */
  code: string;
  isHost: boolean;
  /** последняя ошибка подключения */
  error: string;
  remote: PeerIdentity | null;

  friends: Friend[];
  addFriend: (f: Omit<Friend, 'added' | 'lastSeen'>) => void;
  removeFriend: (id: string) => void;

  chat: ChatMsg[];
  chatWith: string | null;
  openChat: (id: string | null) => void;
  sendChat: (text: string) => void;

  rooms: string[];
  settings: NetSettings;
  setSettings: (p: Partial<NetSettings>) => void;

  /** создать комнату — вернёт код из 5 символов */
  host: () => Promise<string>;
  /** войти по коду */
  join: (code: string) => Promise<void>;
  disconnect: () => void;

  send: (m: Msg) => void;
  on: (fn: (m: Msg) => void) => () => void;
  ping: number;
}

const Ctx = createContext<NetCtx>(null as unknown as NetCtx);

export function NetProvider({
  children, name, level,
}: { children: React.ReactNode; name: string; level: number }) {
  const myId = useMemo(() => myPeerId(), []);
  const me = useMemo<PeerIdentity>(() => ({ id: myId, name, level }), [myId, name, level]);

  const [state, setState] = useState<RoomState>('idle');
  const [code, setCode] = useState('');
  const [isHost, setIsHost] = useState(false);
  const [error, setError] = useState('');
  const [remote, setRemote] = useState<PeerIdentity | null>(null);
  const [friends, setFriends] = useState<Friend[]>(() => loadArr<Friend>(K_FRIENDS));
  const [chatWith, setChatWith] = useState<string | null>(null);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [rooms, setRooms] = useState<string[]>(() => loadArr<string>(K_ROOMS));
  const [settings, setSettingsState] = useState<NetSettings>(
    () => loadJSON<NetSettings>(K_NET, { signal: '', autoConnect: false }),
  );
  const [ping, setPing] = useState(0);

  const roomRef = useRef<Room | null>(null);
  const subs = useRef<Set<(m: Msg) => void>>(new Set());
  const meRef = useRef(me);
  const chatWithRef = useRef(chatWith);
  const remoteRef = useRef(remote);
  meRef.current = me;
  chatWithRef.current = chatWith;
  remoteRef.current = remote;

  useEffect(() => save(K_FRIENDS, friends), [friends]);
  useEffect(() => save(K_ROOMS, rooms), [rooms]);
  useEffect(() => save(K_NET, settings), [settings]);

  useEffect(() => {
    setChat(chatWith ? loadArr<ChatMsg>(K_CHAT(chatWith)) : []);
  }, [chatWith]);

  const pushChat = useCallback((peerId: string, m: ChatMsg) => {
    const list = [...loadArr<ChatMsg>(K_CHAT(peerId)), m].slice(-200);
    save(K_CHAT(peerId), list);
    if (peerId === chatWithRef.current) setChat(list);
  }, []);

  /** входящие сообщения */
  const handle = useCallback((m: Msg) => {
    if (m.t === 'hello') {
      if (m.v !== PROTO_VERSION) return;
      setRemote(m.me);
      setFriends((cur) => {
        const i = cur.findIndex((f) => f.id === m.me.id);
        if (i >= 0) {
          const next = [...cur];
          next[i] = { ...next[i], name: m.me.name, lastSeen: Date.now() };
          return next;
        }
        return [...cur, { id: m.me.id, name: m.me.name, added: Date.now(), lastSeen: Date.now() }];
      });
      /* отправляем накопленную оффлайн-очередь */
      const q = loadArr<ChatMsg>(K_CHAT(m.me.id)).filter((x) => x.pending);
      for (const p of q) roomRef.current?.send({ t: 'chat', id: p.id, text: p.text, ts: p.ts });
      if (q.length) {
        const all = loadArr<ChatMsg>(K_CHAT(m.me.id)).map((x) => ({ ...x, pending: false }));
        save(K_CHAT(m.me.id), all);
        if (chatWithRef.current === m.me.id) setChat(all);
      }
      return;
    }
    if (m.t === 'ping') { roomRef.current?.send({ t: 'pong', ts: m.ts }); return; }
    if (m.t === 'pong') { setPing(Date.now() - m.ts); return; }
    if (m.t === 'chat') {
      const from = remoteRef.current?.id;
      if (from) pushChat(from, { id: m.id, from: 'them', text: m.text, ts: m.ts });
      return;
    }
    subs.current.forEach((fn) => fn(m));
  }, [pushChat]);

  const handleRef = useRef(handle);
  handleRef.current = handle;

  const makeRoom = useCallback(() => {
    roomRef.current?.close();
    const r = new Room({
      onState: (s, info) => {
        setState(s);
        if (s === 'error') setError(info ?? 'Ошибка подключения');
        if (s === 'waiting' && info) setCode(info);
        if (s === 'online') {
          setError('');
          r.send({ t: 'hello', v: PROTO_VERSION, me: meRef.current });
          r.send({ t: 'ping', ts: Date.now() });
        }
        if (s === 'closed' || s === 'idle') setRemote(null);
      },
      onMsg: (m) => handleRef.current(m),
    });
    roomRef.current = r;
    return r;
  }, []);

  const host = useCallback(async () => {
    setError('');
    setIsHost(true);
    const c = await makeRoom().host();
    setCode(c);
    setRooms((cur) => [c, ...cur.filter((x) => x !== c)].slice(0, 5));
    return c;
  }, [makeRoom]);

  const join = useCallback(async (raw: string) => {
    setError('');
    setIsHost(false);
    const r = makeRoom();
    await r.join(raw);
    setCode(r.code);
    setRooms((cur) => [r.code, ...cur.filter((x) => x !== r.code)].slice(0, 5));
  }, [makeRoom]);

  const disconnect = useCallback(() => {
    roomRef.current?.close();
    roomRef.current = null;
    setRemote(null);
    setCode('');
    setState('idle');
  }, []);

  const send = useCallback((m: Msg) => { roomRef.current?.send(m); }, []);

  const on = useCallback((fn: (m: Msg) => void) => {
    subs.current.add(fn);
    return () => { subs.current.delete(fn); };
  }, []);

  const sendChat = useCallback((text: string) => {
    const target = chatWithRef.current;
    if (!target || !text.trim()) return;
    const m: ChatMsg = {
      id: Math.random().toString(36).slice(2),
      from: 'me', text: text.trim(), ts: Date.now(),
    };
    const ok = roomRef.current?.online
      && roomRef.current.send({ t: 'chat', id: m.id, text: m.text, ts: m.ts });
    pushChat(target, { ...m, pending: !ok });
  }, [pushChat]);

  const addFriend = useCallback((f: Omit<Friend, 'added' | 'lastSeen'>) => {
    setFriends((cur) => cur.some((x) => x.id === f.id)
      ? cur
      : [...cur, { ...f, added: Date.now(), lastSeen: 0 }]);
  }, []);

  const removeFriend = useCallback((id: string) => {
    setFriends((cur) => cur.filter((f) => f.id !== id));
    try { localStorage.removeItem(K_CHAT(id)); } catch { /* нет записи */ }
  }, []);

  const setSettings = useCallback((p: Partial<NetSettings>) => {
    setSettingsState((s) => ({ ...s, ...p }));
  }, []);

  useEffect(() => {
    const t = window.setInterval(() => {
      if (roomRef.current?.online) roomRef.current.send({ t: 'ping', ts: Date.now() });
    }, 5000);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => () => roomRef.current?.close(), []);

  const value = useMemo<NetCtx>(() => ({
    myId, me, state, code, isHost, error, remote,
    friends, addFriend, removeFriend,
    chat, chatWith, openChat: setChatWith, sendChat,
    rooms, settings, setSettings,
    host, join, disconnect, send, on, ping,
  }), [myId, me, state, code, isHost, error, remote, friends, addFriend, removeFriend,
    chat, chatWith, sendChat, rooms, settings, setSettings, host, join, disconnect, send, on, ping]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useNet = () => useContext(Ctx);
