import Peer, { type DataConnection } from 'peerjs';
import type { Msg } from './protocol';

/**
 * Комнаты по короткому коду из 5 символов.
 *
 * Код — это и есть идентификатор пира у публичного брокера PeerJS:
 * хост регистрируется под `ng-<КОД>`, гость подключается по тому же коду.
 * Обмен SDP берёт на себя брокер, поэтому длинные коды больше не нужны.
 */

export type RoomState = 'idle' | 'opening' | 'waiting' | 'connecting' | 'online' | 'closed' | 'error';

/** Без похожих символов: 0/O, 1/I, 5/S */
const ALPHABET = 'ABCDEFGHJKLMNPQRTUVWXYZ23469';
const CODE_LEN = 5;
const NS = 'ng-';

/** Стабильный идентификатор этого устройства (для списка друзей) */
export function myPeerId(): string {
  const KEY = 'nikgrager-peer-id';
  let id = localStorage.getItem(KEY);
  if (!id) {
    const a = new Uint8Array(6);
    crypto.getRandomValues(a);
    id = Array.from(a).map((x) => x.toString(16).padStart(2, '0')).join('');
    localStorage.setItem(KEY, id);
  }
  return id;
}

export function makeCode(): string {
  const a = new Uint8Array(CODE_LEN);
  crypto.getRandomValues(a);
  let out = '';
  for (let i = 0; i < CODE_LEN; i++) out += ALPHABET[a[i] % ALPHABET.length];
  return out;
}

export const normalizeCode = (s: string) =>
  s.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, CODE_LEN);

interface Handlers {
  onState?: (s: RoomState, info?: string) => void;
  onMsg?: (m: Msg) => void;
}

export class Room {
  private peer: Peer | null = null;
  private conn: DataConnection | null = null;
  private h: Handlers;
  private queue: Msg[] = [];
  state: RoomState = 'idle';
  code = '';
  isHost = false;

  constructor(h: Handlers = {}) { this.h = h; }

  private set(s: RoomState, info?: string) {
    if (this.state === s) return;
    this.state = s;
    this.h.onState?.(s, info);
  }

  private bind(conn: DataConnection) {
    this.conn = conn;
    conn.on('open', () => {
      this.set('online');
      for (const m of this.queue) conn.send(m);
      this.queue = [];
    });
    conn.on('data', (d) => {
      try { this.h.onMsg?.(d as Msg); } catch { /* мусорный пакет */ }
    });
    conn.on('close', () => this.set('closed'));
    conn.on('error', () => this.set('error', 'Соединение разорвано'));
  }

  /** Создать комнату. Возвращает короткий код для второго игрока. */
  host(): Promise<string> {
    return new Promise((resolve, reject) => {
      this.close();
      this.isHost = true;
      this.set('opening');

      const tryCode = (attempt: number) => {
        const code = makeCode();
        const peer = new Peer(NS + code, { debug: 0 });
        this.peer = peer;

        peer.on('open', () => {
          this.code = code;
          this.set('waiting', code);
          resolve(code);
        });
        peer.on('connection', (conn) => {
          this.set('connecting');
          this.bind(conn);
        });
        peer.on('error', (e: Error & { type?: string }) => {
          /* код занят — пробуем другой */
          if (e.type === 'unavailable-id' && attempt < 4) {
            peer.destroy();
            tryCode(attempt + 1);
            return;
          }
          this.set('error', describe(e));
          if (!this.code) reject(e);
        });
      };
      tryCode(0);
    });
  }

  /** Войти в комнату по коду */
  join(raw: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const code = normalizeCode(raw);
      if (code.length !== CODE_LEN) { reject(new Error('Код из 5 символов')); return; }
      this.close();
      this.isHost = false;
      this.code = code;
      this.set('connecting');

      const peer = new Peer({ debug: 0 });
      this.peer = peer;

      peer.on('open', () => {
        const conn = peer.connect(NS + code, { reliable: true });
        this.bind(conn);
        conn.on('open', () => resolve());
        /* комната не отвечает — скорее всего кода не существует */
        window.setTimeout(() => {
          if (this.state !== 'online') {
            this.set('error', 'Комната не найдена');
            reject(new Error('Комната не найдена'));
          }
        }, 12000);
      });
      peer.on('error', (e: Error & { type?: string }) => {
        this.set('error', describe(e));
        reject(e);
      });
    });
  }

  send(m: Msg): boolean {
    if (this.conn?.open) { this.conn.send(m); return true; }
    this.queue.push(m);
    return false;
  }

  get online() { return !!this.conn?.open; }

  close() {
    try { this.conn?.close(); } catch { /* уже закрыт */ }
    try { this.peer?.destroy(); } catch { /* уже закрыт */ }
    this.conn = null;
    this.peer = null;
    this.queue = [];
    this.code = '';
    this.set('idle');
  }
}

function describe(e: Error & { type?: string }): string {
  switch (e.type) {
    case 'peer-unavailable': return 'Комната не найдена';
    case 'network': return 'Нет связи с сервером комнат';
    case 'unavailable-id': return 'Код занят, создайте новый';
    case 'browser-incompatible': return 'Браузер не поддерживает P2P';
    default: return 'Не удалось подключиться';
  }
}
