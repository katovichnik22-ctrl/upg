/**
 * Честная рандомизация commit-reveal на Web Crypto.
 *
 * Схема: каждая сторона генерирует секретный сид, присылает только его
 * SHA-256. После обмена хэшами стороны раскрывают сиды и проверяют их.
 * Итоговый сид = XOR всех сидов, поэтому ни один участник не может
 * выбрать результат: его вклад фиксируется до того, как он узнает чужой.
 */

const enc = new TextEncoder();

const toHex = (b: ArrayBuffer): string =>
  Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join('');

/** Случайный 32-байтовый сид в hex */
export function makeSeed(): string {
  const a = new Uint8Array(32);
  crypto.getRandomValues(a);
  return Array.from(a).map((x) => x.toString(16).padStart(2, '0')).join('');
}

export async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return toHex(buf);
}

/** Проверка: раскрытый сид действительно соответствует присланному хэшу */
export async function verify(seed: string, hash: string): Promise<boolean> {
  return (await sha256(seed)) === hash;
}

/** XOR нескольких hex-сидов одинаковой длины */
export function combine(seeds: string[]): string {
  if (seeds.length === 0) return '0'.repeat(64);
  const len = Math.min(...seeds.map((s) => s.length));
  let out = '';
  for (let i = 0; i < len; i++) {
    let v = 0;
    for (const s of seeds) v ^= parseInt(s[i], 16);
    out += v.toString(16);
  }
  return out;
}

/**
 * Результат раунда: число [0,1) из объединённого сида.
 * Берём первые 13 hex-символов — это ~52 бита, хватает с запасом.
 */
export function rollFrom(combined: string): number {
  const slice = combined.slice(0, 13);
  const v = parseInt(slice, 16);
  return v / Math.pow(16, slice.length);
}

/** Целое [0, n) из объединённого сида */
export const rollInt = (combined: string, n: number): number =>
  Math.floor(rollFrom(combined) * n);

/** Состояние commit-reveal одной стороны */
export interface FairRound {
  mySeed: string;
  myHash: string;
  theirHash?: string;
  theirSeed?: string;
}

export async function startRound(): Promise<FairRound> {
  const mySeed = makeSeed();
  return { mySeed, myHash: await sha256(mySeed) };
}
