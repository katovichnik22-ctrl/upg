import { useEffect, useRef, useState } from 'react';
import { Activity } from 'lucide-react';
import type { Skin } from '../lib/types';
import { useSkins } from '../lib/store';
import { fmt } from '../lib/skins';
import { SkinImage } from './ui';

interface FeedEntry {
  id: number;
  nick: string;
  skin: Skin;
  mult: number;
}

const NICKS = [
  'dimon_ace', 'krya228', 's1mple_fan', 'pro100vova', 'neo_tlt', 'xX_sniper_Xx',
  'm4a1s_king', 'karapuz', 'toxic_13', 'begemot', 'shadow_fiend', 'zxcursed',
  'vanek1337', 'p90_rush', 'silent_bob', 'kraken777', 'low_skill', 'dendi_w',
];

let feedId = 0;

function makeEntry(skins: Skin[]): FeedEntry | null {
  if (skins.length < 10) return null;
  const stake = skins[Math.floor(Math.random() * skins.length)];
  const mult = [1.5, 2, 2.5, 3, 4, 5, 8, 10, 15, 25][Math.floor(Math.random() * 10)];
  const targetValue = stake.price * mult;
  let best = skins[0];
  let bd = Infinity;
  for (let i = 0; i < 220; i++) {
    const c = skins[Math.floor(Math.random() * skins.length)];
    const d = Math.abs(c.price - targetValue);
    if (d < bd) { bd = d; best = c; }
  }
  return {
    id: ++feedId,
    nick: NICKS[Math.floor(Math.random() * NICKS.length)],
    skin: best,
    mult: Math.max(1.1, Math.round((best.price / Math.max(1, stake.price)) * 10) / 10),
  };
}

export default function WinsFeed() {
  const { skins } = useSkins();
  const [items, setItems] = useState<FeedEntry[]>([]);
  const timer = useRef<number>(0);

  useEffect(() => {
    const initial: FeedEntry[] = [];
    for (let i = 0; i < 9; i++) {
      const e = makeEntry(skins);
      if (e) initial.push(e);
    }
    setItems(initial);

    const tick = () => {
      setItems((cur) => {
        const e = makeEntry(skins);
        if (!e) return cur;
        return [e, ...cur].slice(0, 26);
      });
      timer.current = window.setTimeout(tick, 3800 + Math.random() * 5200);
    };
    timer.current = window.setTimeout(tick, 2500);
    return () => window.clearTimeout(timer.current);
  }, [skins]);

  return (
    <div className="panel sticky top-[76px] flex max-h-[calc(100vh-92px)] min-h-0 flex-col overflow-hidden p-3">
      <div className="mb-2.5 flex items-center gap-2 px-1">
        <Activity size={14} className="text-gold" />
        <h2 className="font-display text-[11px] font-bold uppercase tracking-[0.18em] text-slate-300">Выбивают</h2>
        <span className="relative ml-auto flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold opacity-60" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-gold" />
        </span>
      </div>
      <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto pr-0.5">
        {items.map((e, i) => (
          <div key={e.id} className={i === 0 ? 'feed-in feed-card flex items-center gap-2 p-2' : 'feed-card flex items-center gap-2 p-2'}>
            <SkinImage skin={e.skin} className="h-10 w-14 shrink-0" imgClassName="max-h-10" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[10px] font-bold leading-tight text-slate-200" title={e.skin.name}>
                {e.skin.name.replace('★ ', '')}
              </div>
              <div className="mt-0.5 flex items-center justify-between gap-1">
                <span className="num price text-[10px] font-bold">{fmt(e.skin.price)}</span>
              </div>
              <div className="truncate text-[8.5px] text-slate-600">{e.nick}</div>
            </div>
            <span className="num shrink-0 rounded-md bg-gold/12 px-1.5 py-0.5 text-[10px] font-extrabold text-gold ring-1 ring-gold/25">
              x{e.mult}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
