import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Zap, BatteryCharging, RefreshCw, Bot, Target, Flame,
  Gift, CheckCircle2, ArrowRightLeft, ListChecks,
} from 'lucide-react';
import { useGame } from '../lib/store';
import {
  UPGRADES, TASKS, upgradeCost, recalc, applyOffline, dailyReward, COIN_RATE, MIN_EXCHANGE,
  type UpgradeDef,
} from '../lib/clicker';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { SlotSymbol } from './SlotSymbol';
import { SectionTitle } from './ui';
import { cn } from '../utils/cn';

const ICONS: Record<string, typeof Zap> = {
  zap: Zap, battery: BatteryCharging, refresh: RefreshCw,
  bot: Bot, target: Target, flame: Flame,
};

const nf = (n: number) => Math.floor(n).toLocaleString('ru-RU');

interface Pop { id: number; x: number; y: number; v: number; crit: boolean }

export default function Clicker() {
  const { state, setClicker, adjust, log, toast } = useGame();
  const c = state.clicker;

  const [pops, setPops] = useState<Pop[]>([]);
  const [punch, setPunch] = useState(false);
  const [tab, setTab] = useState<'up' | 'tasks'>('up');
  const popId = useRef(0);
  const offlineDone = useRef(false);

  /* офлайн-доход при входе */
  useEffect(() => {
    if (offlineDone.current) return;
    offlineDone.current = true;
    const { next, earned, secs } = applyOffline(recalc(c));
    setClicker(next);
    if (earned > 0) {
      toast('Пока вас не было', 'win', `Автокликер принёс ${nf(earned)} монет за ${Math.floor(secs / 60)} мин`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* тик: энергия + пассивный доход */
  useEffect(() => {
    const t = window.setInterval(() => {
      setClicker((cur) => ({
        energy: Math.min(cur.maxEnergy, cur.energy + cur.regen),
        coins: cur.coins + cur.auto,
        lastSeen: Date.now(),
      }));
    }, 1000);
    return () => window.clearInterval(t);
  }, [setClicker]);

  const tap = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    if (c.energy < 1) {
      toast('Нет энергии', 'lose', 'Подождите восстановления');
      return;
    }
    const crit = Math.random() < c.critChance;
    const gain = Math.round(c.perClick * (crit ? c.critMult : 1));

    setClicker((cur) => ({
      coins: cur.coins + gain,
      energy: Math.max(0, cur.energy - 1),
      totalClicks: cur.totalClicks + 1,
      lastSeen: Date.now(),
    }));

    /* всплывающее «+N» в точке касания */
    const box = e.currentTarget.getBoundingClientRect();
    const id = ++popId.current;
    setPops((p) => [...p.slice(-9), {
      id,
      x: e.clientX - box.left,
      y: e.clientY - box.top,
      v: gain,
      crit,
    }]);
    window.setTimeout(() => setPops((p) => p.filter((x) => x.id !== id)), 750);

    setPunch(true);
    window.setTimeout(() => setPunch(false), 90);

    if (crit) audio.coin(); else audio.blip(760 + Math.random() * 180, 0.03, 'triangle', 0.07);
    try { navigator.vibrate?.(crit ? 26 : 9); } catch { /* не поддерживается */ }
  }, [c.energy, c.perClick, c.critChance, c.critMult, setClicker, toast]);

  const buy = (u: UpgradeDef) => {
    const lvl = c.upgrades[u.id] ?? 0;
    if (lvl >= u.maxLevel) return;
    const cost = upgradeCost(u, lvl);
    if (c.coins < cost) {
      toast('Не хватает монет', 'lose', `Нужно ${nf(cost)}`);
      return;
    }
    audio.click();
    setClicker((cur) => {
      const ups = { ...cur.upgrades, [u.id]: lvl + 1 };
      return { ...recalc({ ...cur, upgrades: ups }), coins: cur.coins - cost, upgrades: ups };
    });
    toast('Апгрейд куплен', 'win', `${u.name} · ур. ${lvl + 1}`);
  };

  const claimDaily = () => {
    const today = new Date().toDateString();
    if (c.lastDaily === today) {
      toast('Бонус уже получен', 'info', 'Возвращайтесь завтра');
      return;
    }
    const yest = new Date(Date.now() - 864e5).toDateString();
    const streak = c.lastDaily === yest ? Math.min(7, c.streak + 1) : 1;
    const reward = dailyReward(streak);
    setClicker({ coins: c.coins + reward, streak, lastDaily: today });
    audio.win();
    toast('Ежедневный бонус', 'win', `+${nf(reward)} монет · день ${streak}/7`);
  };

  const claimTask = (id: string, reward: number) => {
    if (c.tasksDone.includes(id)) return;
    setClicker((cur) => ({ coins: cur.coins + reward, tasksDone: [...cur.tasksDone, id] }));
    audio.win();
    toast('Задание выполнено', 'win', `+${nf(reward)} монет`);
  };

  const exchange = () => {
    const coins = Math.floor(c.coins);
    if (coins < MIN_EXCHANGE) {
      toast('Слишком мало', 'lose', `Минимум ${nf(MIN_EXCHANGE)} монет`);
      return;
    }
    const money = Math.floor(coins * COIN_RATE);
    setClicker({ coins: c.coins - coins });
    adjust(money);
    audio.coin();
    log({ kind: 'bonus', text: `Обмен ${nf(coins)} монет кликера`, amount: money, success: true });
    toast('Обменяно', 'win', `+${fmt(money)} на баланс`);
  };

  const energyPct = (c.energy / c.maxEnergy) * 100;
  const today = new Date().toDateString();

  return (
    <div className="fade-up space-y-3">
      {/* статистика */}
      <div className="panel p-3">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">Монеты</div>
            <div className="num font-display text-[24px] font-extrabold leading-none text-gold">{nf(c.coins)}</div>
          </div>
          <button onClick={exchange} className="btn btn-gold-outline shrink-0 px-3 py-2 text-[11.5px]">
            <ArrowRightLeft size={13} /> В рубли
          </button>
        </div>

        <div className="mt-1 text-[9px] text-slate-600">
          курс {COIN_RATE} ₽ за монету · минимум {nf(MIN_EXCHANGE)}
        </div>

        <div className="mt-2.5">
          <div className="mb-1 flex justify-between text-[10px] font-bold text-slate-500">
            <span>Энергия</span>
            <span className="num">{Math.floor(c.energy)} / {c.maxEnergy}</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-white/8">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#ffd964] to-[#e8a013] transition-[width] duration-300"
              style={{ width: `${energyPct}%` }}
            />
          </div>
        </div>

        <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-center">
          <div className="panel-inset px-1 py-1.5">
            <div className="num text-[13px] font-extrabold text-slate-100">+{nf(c.perClick)}</div>
            <div className="text-[8.5px] uppercase tracking-wider text-slate-500">за клик</div>
          </div>
          <div className="panel-inset px-1 py-1.5">
            <div className="num text-[13px] font-extrabold text-emerald-300">+{nf(c.auto)}/с</div>
            <div className="text-[8.5px] uppercase tracking-wider text-slate-500">авто</div>
          </div>
          <div className="panel-inset px-1 py-1.5">
            <div className="num text-[13px] font-extrabold text-rose-300">{Math.round(c.critChance * 100)}%</div>
            <div className="text-[8.5px] uppercase tracking-wider text-slate-500">крит ×{c.critMult}</div>
          </div>
        </div>
      </div>

      {/* кнопка тапа */}
      <div className="panel relative overflow-hidden p-4">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-gold/8 to-transparent" />
        <button
          onPointerDown={tap}
          disabled={c.energy < 1}
          className={cn(
            'relative mx-auto grid aspect-square w-full max-w-[260px] place-items-center rounded-full transition-transform duration-75 select-none',
            punch ? 'scale-95' : 'scale-100',
            c.energy < 1 && 'opacity-50',
          )}
          style={{
            background: 'radial-gradient(circle at 38% 30%, #1d2637, #0b0f18 72%)',
          }}
        >
          {/* кольца */}
          <span className="absolute inset-0 rounded-full border-2 border-gold/35" />
          <span className={cn('absolute inset-3 rounded-full border border-gold/20', punch && 'animate-ping')} />
          <span
            className="absolute inset-6 rounded-full"
            style={{ background: 'radial-gradient(circle at 40% 32%, rgba(246,196,69,.28), rgba(10,13,19,.9) 70%)' }}
          />
          <SlotSymbol name="case" size={128} />

          {/* всплывающие «+N» */}
          {pops.map((p) => (
            <span
              key={p.id}
              className={cn(
                'pointer-events-none absolute z-10 select-none font-display text-[18px] font-extrabold',
                p.crit ? 'text-rose-300' : 'text-gold',
              )}
              style={{
                left: p.x, top: p.y,
                animation: 'popFloat .75s ease-out forwards',
                textShadow: '0 2px 10px rgba(0,0,0,.8)',
              }}
            >
              +{nf(p.v)}{p.crit && '!'}
            </span>
          ))}
        </button>

        <div className="mt-2 text-center text-[10.5px] font-bold uppercase tracking-wider text-slate-500">
          {c.energy < 1 ? 'энергия кончилась — ждём' : 'тапай, чтобы заработать'}
        </div>

        <button
          onClick={claimDaily}
          disabled={c.lastDaily === today}
          className={cn('btn mt-2.5 w-full py-3 text-[12.5px]', c.lastDaily === today ? 'btn-ghost' : 'btn-gold btn-shine')}
        >
          {c.lastDaily === today
            ? <><CheckCircle2 size={14} /> Бонус получен · серия {c.streak}/7</>
            : <><Gift size={14} /> Ежедневный бонус +{nf(dailyReward(Math.min(7, c.streak + 1)))}</>}
        </button>
      </div>

      {/* вкладки */}
      <div className="grid grid-cols-2 gap-2">
        <button className={cn('chip chip-lg justify-center', tab === 'up' && 'on')} onClick={() => { audio.click(); setTab('up'); }}>
          <Zap size={13} className="mr-1.5" /> Апгрейды
        </button>
        <button className={cn('chip chip-lg justify-center', tab === 'tasks' && 'on')} onClick={() => { audio.click(); setTab('tasks'); }}>
          <ListChecks size={13} className="mr-1.5" /> Задания
        </button>
      </div>

      {tab === 'up' && (
        <div className="panel p-3">
          <SectionTitle icon={<Zap size={15} className="text-gold" />} title="Улучшения" />
          <div className="space-y-2">
            {UPGRADES.map((u) => {
              const lvl = c.upgrades[u.id] ?? 0;
              const maxed = lvl >= u.maxLevel;
              const cost = upgradeCost(u, lvl);
              const can = !maxed && c.coins >= cost;
              const Icon = ICONS[u.icon] ?? Zap;
              return (
                <div key={u.id} className="panel-inset flex items-center gap-2.5 p-2.5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gold/10 text-gold ring-1 ring-gold/20">
                    <Icon size={17} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-[12.5px] font-bold">{u.name}</span>
                      <span className="num shrink-0 rounded bg-white/6 px-1 text-[9.5px] font-bold text-slate-400">ур.{lvl}</span>
                    </div>
                    <div className="truncate text-[10px] text-slate-500">
                      {maxed ? 'максимум' : u.gain(lvl)}
                    </div>
                  </div>
                  <button
                    onClick={() => buy(u)}
                    disabled={!can}
                    className={cn('btn shrink-0 px-2.5 py-2 text-[11px]', can ? 'btn-gold' : 'btn-ghost')}
                  >
                    {maxed ? 'MAX' : nf(cost)}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'tasks' && (
        <div className="panel p-3">
          <SectionTitle icon={<ListChecks size={15} className="text-gold" />} title="Задания" />
          <div className="space-y-2">
            {TASKS.map((t) => {
              const claimed = c.tasksDone.includes(t.id);
              const ready = t.done(c) && !claimed;
              return (
                <div key={t.id} className={cn('panel-inset flex items-center gap-2.5 p-2.5', claimed && 'opacity-55')}>
                  <div className={cn(
                    'grid h-9 w-9 shrink-0 place-items-center rounded-xl ring-1',
                    claimed ? 'bg-emerald-500/12 text-emerald-300 ring-emerald-400/25' : 'bg-white/5 text-slate-400 ring-white/10',
                  )}>
                    {claimed ? <CheckCircle2 size={16} /> : <Target size={16} />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] font-bold">{t.name}</div>
                    <div className="num text-[10px] text-slate-500">{t.progress(c)} · +{nf(t.reward)}</div>
                  </div>
                  <button
                    onClick={() => claimTask(t.id, t.reward)}
                    disabled={!ready}
                    className={cn('btn shrink-0 px-2.5 py-2 text-[11px]', ready ? 'btn-gold' : 'btn-ghost')}
                  >
                    {claimed ? 'Готово' : 'Забрать'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <style>{`@keyframes popFloat{0%{opacity:1;transform:translate(-50%,-50%) scale(.8)}100%{opacity:0;transform:translate(-50%,-190%) scale(1.25)}}`}</style>
    </div>
  );
}
