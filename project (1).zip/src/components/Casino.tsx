import { useState } from 'react';
import { Disc3, Cherry, Spade, Rocket, Bomb, Plane, CircleDollarSign, CircleDot, CircleDashed, Goal, Fish } from 'lucide-react';
import type { GameId } from '../lib/types';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';
import Roulette from './Roulette';
import CasinoRoulette from './roulette/Roulette';
import Plinko from './games/Plinko';
import Penalty from './games/Penalty';
import Slots from './games/Slots';
import Blackjack from './games/BlackjackTable';
import Fishing from './games/Fishing';
import Crash from './games/Crash';
import Mines from './games/Mines';
import CoinFlip from './games/CoinFlip';
import Aviator from './games/Aviator';

const GAMES: Array<{ id: GameId; label: string; icon: typeof Disc3; tint: string }> = [
  { id: 'casino-roulette', label: 'Рулетка', icon: CircleDot, tint: 'text-emerald-400' },
  { id: 'slots', label: 'Слоты', icon: Cherry, tint: 'text-pink-400' },
  { id: 'aviator', label: 'Авиатор', icon: Plane, tint: 'text-gold' },
  { id: 'coinflip', label: 'Орёл и решка', icon: CircleDollarSign, tint: 'text-amber-300' },
  { id: 'roulette', label: 'CS-лента', icon: Disc3, tint: 'text-rose-400' },
  { id: 'fishing', label: 'Рыбалка', icon: Fish, tint: 'text-cyan-300' },
  { id: 'plinko', label: 'Плинко', icon: CircleDashed, tint: 'text-amber-300' },
  { id: 'penalty', label: 'Пенальти', icon: Goal, tint: 'text-lime-400' },
  { id: 'blackjack', label: 'Блэкджек', icon: Spade, tint: 'text-emerald-400' },
  { id: 'crash', label: 'Краш', icon: Rocket, tint: 'text-orange-300' },
  { id: 'mines', label: 'Мины', icon: Bomb, tint: 'text-sky-400' },
];

export default function Casino() {
  const [game, setGame] = useState<GameId>('casino-roulette');

  return (
    <div className="fade-up space-y-4">
      {/* game switcher */}
      <div className="panel chip-row items-center p-2.5 md:flex md:flex-wrap md:gap-2">
        {GAMES.map((g) => {
          const active = game === g.id;
          return (
            <button
              key={g.id}
              onClick={() => { audio.click(); setGame(g.id); }}
              className={cn(
                'group flex items-center justify-center gap-2 rounded-xl border px-4 py-2.5 text-[12.5px] font-bold transition-all md:flex-1 lg:flex-none lg:px-5',
                active
                  ? 'border-gold/50 bg-gold/10 text-gold'
                  : 'border-transparent bg-[#1a2029] text-slate-400 hover:bg-[#222938] hover:text-white',
              )}
            >
              <g.icon size={16} className={cn('transition-transform group-hover:scale-110', active ? 'text-gold' : g.tint)} />
              {g.label}
            </button>
          );
        })}
      </div>

      {game === 'casino-roulette' && <CasinoRoulette />}
      {game === 'roulette' && <Roulette />}
      {game === 'slots' && <Slots />}
      {game === 'blackjack' && <Blackjack />}
      {game === 'crash' && <Crash />}
      {game === 'mines' && <Mines />}
      {game === 'plinko' && <Plinko />}
      {game === 'penalty' && <Penalty />}
      {game === 'fishing' && <Fishing />}
      {game === 'coinflip' && <CoinFlip />}
      {game === 'aviator' && <Aviator />}
    </div>
  );
}
