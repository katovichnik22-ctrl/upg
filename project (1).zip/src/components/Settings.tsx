import { useState } from 'react';
import {
  Volume2, VolumeX, Gauge, RotateCcw, Settings as SettingsIcon, ShieldCheck, Database, Info, TriangleAlert,
  MonitorSmartphone, Smartphone, Monitor, Wand2, Zap,
} from 'lucide-react';
import type { ViewMode } from '../lib/types';
import NetSettings from './NetSettings';
import { useGame, useSkins } from '../lib/store';
import { audio } from '../lib/audio';
import { SectionTitle } from './ui';
import { cn } from '../utils/cn';

function Row({ icon, title, sub, control }: { icon: React.ReactNode; title: string; sub?: string; control: React.ReactNode }) {
  return (
    <div className="panel-inset flex items-center gap-3.5 px-4 py-3.5">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-500/12 text-blue-300">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="text-[13.5px] font-bold">{title}</div>
        {sub && <div className="text-[11px] text-slate-500">{sub}</div>}
      </div>
      {control}
    </div>
  );
}

export default function Settings() {
  const { state, setSettings, reset, toast } = useGame();
  const { skins } = useSkins();
  const [confirmReset, setConfirmReset] = useState(false);

  const Tgl = ({ on, onClick }: { on: boolean; onClick: () => void }) => (
    <button className={cn('tgl shrink-0', on && 'on')} onClick={onClick} aria-pressed={on} />
  );

  return (
    <div className="fade-up mx-auto max-w-[680px] space-y-4">
      <div className="panel p-5">
        <SectionTitle icon={<SettingsIcon size={15} className="text-blue-300" />} title="Настройки" />
        <div className="space-y-2.5">
          <Row
            icon={state.settings.sound ? <Volume2 size={18} /> : <VolumeX size={18} />}
            title="Звуковые эффекты"
            sub="Тики барабана, фанфары победы"
            control={
              <Tgl
                on={state.settings.sound}
                onClick={() => {
                  const v = !state.settings.sound;
                  setSettings({ sound: v });
                  if (v) setTimeout(() => audio.click(), 30);
                }}
              />
            }
          />
          <Row
            icon={<Volume2 size={18} />}
            title="Громкость"
            sub={`${Math.round(state.settings.volume * 100)}%`}
            control={
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(state.settings.volume * 100)}
                onChange={(e) => setSettings({ volume: Number(e.target.value) / 100 })}
                onMouseUp={() => audio.coin()}
                className="w-40"
                style={{ '--p': `${Math.round(state.settings.volume * 100)}%` } as React.CSSProperties}
              />
            }
          />
          <Row
            icon={<Zap size={18} />}
            title="Производительность"
            sub="Отключает размытия и тени — для слабых телефонов"
            control={
              <Tgl
                on={state.settings.lite}
                onClick={() => { setSettings({ lite: !state.settings.lite }); audio.click(); }}
              />
            }
          />
          <Row
            icon={<Gauge size={18} />}
            title="Быстрая анимация"
            sub="Ускоренные прокруты колеса и рулетки"
            control={
              <Tgl
                on={state.settings.fast}
                onClick={() => { setSettings({ fast: !state.settings.fast }); audio.click(); }}
              />
            }
          />
        </div>
      </div>

      <div className="panel p-5">
        <SectionTitle icon={<MonitorSmartphone size={15} className="text-gold" />} title="Вид интерфейса" />
        <div className="grid grid-cols-3 gap-2">
          {([
            { id: 'auto', label: 'Авто', sub: 'по устройству', icon: Wand2 },
            { id: 'mobile', label: 'Телефон', sub: 'узкая раскладка', icon: Smartphone },
            { id: 'desktop', label: 'ПК', sub: 'широкая раскладка', icon: Monitor },
          ] as Array<{ id: ViewMode; label: string; sub: string; icon: typeof Monitor }>).map((v) => {
            const on = state.settings.view === v.id;
            return (
              <button
                key={v.id}
                onClick={() => { audio.click(); setSettings({ view: v.id }); }}
                className={cn(
                  'flex flex-col items-center gap-1 rounded-xl border px-2 py-3 transition-all',
                  on
                    ? 'border-gold/50 bg-gold/10 text-gold'
                    : 'border-white/8 bg-[#151a26] text-slate-400 hover:text-white',
                )}
              >
                <v.icon size={19} />
                <span className="text-[12px] font-extrabold">{v.label}</span>
                <span className="text-center text-[9px] uppercase tracking-wider opacity-60">{v.sub}</span>
              </button>
            );
          })}
        </div>
        <div className="mt-2 text-[10.5px] leading-relaxed text-slate-600">
          «ПК» разворачивает полную версию сайта на телефоне — можно приближать пальцами.
          «Телефон» включает компактную раскладку с нижним меню на любом экране.
        </div>
      </div>

      <NetSettings />

      <div className="panel p-5">
        <SectionTitle icon={<Database size={15} className="text-violet-300" />} title="Данные" />
        <div className="panel-inset flex items-center gap-3.5 px-4 py-3.5">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-violet-500/12 text-violet-300">
            <Database size={18} />
          </div>
          <div className="flex-1">
            <div className="text-[13.5px] font-bold">База скинов CS2</div>
            <div className="num text-[11px] text-slate-500">{skins.length.toLocaleString('ru-RU')} предметов · прогресс сохраняется в браузере</div>
          </div>
        </div>
        <button
          onClick={() => {
            audio.click();
            if (!confirmReset) {
              setConfirmReset(true);
              setTimeout(() => setConfirmReset(false), 3500);
            } else {
              reset();
              setConfirmReset(false);
              toast('Прогресс сброшен', 'info', 'Баланс и инвентарь восстановлены');
            }
          }}
          className={cn('btn mt-3 w-full py-3 text-[13px]', confirmReset ? 'btn-red' : 'btn-ghost')}
        >
          {confirmReset ? (
            <><TriangleAlert size={15} /> Точно сбросить? Нажмите ещё раз</>
          ) : (
            <><RotateCcw size={15} /> Сбросить прогресс</>
          )}
        </button>
      </div>

      <div className="panel p-5">
        <SectionTitle icon={<Info size={15} className="text-emerald-300" />} title="О проекте" />
        <div className="panel-inset flex items-start gap-3.5 px-4 py-4">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-500/12 text-emerald-300">
            <ShieldCheck size={18} />
          </div>
          <div className="text-[12.5px] leading-relaxed text-slate-400">
            <b className="text-slate-200">Бесплатный демо-режим.</b> Вся валюта виртуальная, пополнение — мгновенное и бесплатное.
            Скины нельзя вывести, игра ведётся исключительно ради развлечения.
            Названия предметов и изображения являются собственностью Valve Corporation.
          </div>
        </div>
      </div>
    </div>
  );
}
