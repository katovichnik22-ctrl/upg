import { useState } from 'react';
import { Network, Copy, Check, Server } from 'lucide-react';
import { useNet } from '../net/netStore';
import { SectionTitle } from './ui';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';

/** Секция «Сеть» в настройках */
export default function NetSettings() {
  const net = useNet();
  const [copied, setCopied] = useState(false);

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(net.myId);
      setCopied(true);
      audio.click();
      window.setTimeout(() => setCopied(false), 1500);
    } catch { /* буфер недоступен */ }
  };

  return (
    <div className="panel p-5">
      <SectionTitle icon={<Network size={15} className="text-gold" />} title="Сеть" />

      <div className="panel-inset flex items-center gap-3.5 px-4 py-3.5">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gold/12 text-gold">
          <Network size={18} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-bold">Мой идентификатор</div>
          <div className="num truncate text-[10px] text-slate-500">{net.myId}</div>
        </div>
        <button onClick={copyId} className="chip !min-h-0 shrink-0 px-2 py-1.5">
          {copied ? <Check size={13} /> : <Copy size={13} />}
        </button>
      </div>

      <div className="panel-inset mt-2 px-4 py-3.5">
        <div className="mb-1.5 flex items-center gap-2">
          <Server size={14} className="text-slate-400" />
          <span className="text-[12.5px] font-bold">Сервер комнат</span>
        </div>
        <input
          value={net.settings.signal}
          onChange={(e) => net.setSettings({ signal: e.target.value })}
          placeholder="пусто = публичный брокер"
          className="input w-full px-3 py-2 text-[11.5px]"
        />
        <p className="mt-1.5 text-[10px] leading-relaxed text-slate-600">
          Короткие коды лобби работают через публичный брокер. Он нужен только
          для момента соединения — сама игра идёт напрямую между устройствами.
        </p>
      </div>

      <div className="panel-inset mt-2 flex items-center gap-3.5 px-4 py-3.5">
        <div className="min-w-0 flex-1">
          <div className="text-[12.5px] font-bold">Автоподключение</div>
          <div className="text-[10px] text-slate-500">Переподключаться к последней комнате</div>
        </div>
        <button
          className={cn('tgl shrink-0', net.settings.autoConnect && 'on')}
          onClick={() => { audio.click(); net.setSettings({ autoConnect: !net.settings.autoConnect }); }}
        />
      </div>

      {net.rooms.length > 0 && (
        <div className="mt-2">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Недавние комнаты
          </div>
          <div className="space-y-1">
            {net.rooms.map((r, i) => (
              <div key={i} className="num panel-inset truncate px-2 py-1.5 text-[9.5px] text-slate-500">
                {r}…
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
