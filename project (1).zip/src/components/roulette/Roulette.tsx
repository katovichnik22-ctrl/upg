import { useEffect, useRef, useState } from 'react';
import {
  RotateCcw, Trash2, Copy, Play, BarChart3,
} from 'lucide-react';
import {
  CHIPS, LIMITS, colorOf, isZero, type BetType, type Variant,
} from '../../data/roulette';
import { useRoulette } from '../../lib/useRoulette';
import { useGame } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import RouletteWheel, { type WheelHandle } from './RouletteWheel';
import { RouletteTable } from './RouletteTable';
import { ChipButton } from './BetChip';
import { ConfettiBurst } from '../ui';
import { cn } from '../../utils/cn';

export default function Roulette() {
  const { state, adjust, log, addStats, toast } = useGame();
  const [variant, setVariant] = useState<Variant>('eu');
  const [chip, setChip] = useState(10);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [burst, setBurst] = useState(0);
  const [showStats, setShowStats] = useState(false);

  const r = useRoulette(variant);
  const wheelRef = useRef<WheelHandle>(null);
  const stakedRef = useRef(0);

  /* текущий стрик по цвету — только отображение, на результат не влияет */
  const streak = (() => {
    let n = 0; let color: string | null = null;
    for (const h of r.history) {
      const c = colorOf(h);
      if (c === 'green') break;
      if (color === null) color = c;
      if (c === color) n++; else break;
    }
    return { color, n };
  })();

  /* статистика за последние 100 спинов (как табло в казино) */
  const last100 = r.history.slice(0, 100);
  const rc = last100.filter((h) => colorOf(h) === 'red').length;
  const bc = last100.filter((h) => colorOf(h) === 'black').length;
  const zc = last100.filter((h) => isZero(h)).length;

  /* смена варианта сбрасывает стол */
  useEffect(() => { r.clear(); setResult(null); /* eslint-disable-next-line */ }, [variant]);

  const place = (type: BetType, numbers: string[]) => {
    if (spinning) return;
    const min = ['straight', 'split', 'street', 'corner', 'sixline'].includes(type)
      ? LIMITS.insideMin : LIMITS.outsideMin;
    const add = Math.max(min, chip);
    if (state.balance < r.total + add) {
      toast('Недостаточно средств', 'lose',
        'Заработайте монеты в кликере');
      return;
    }
    if (!r.place(type, numbers, add)) {
      toast('Лимит стола', 'info', 'Максимальная ставка достигнута');
      return;
    }
    audio.blip(1180, 0.03, 'square', 0.05);
  };

  const spin = () => {
    if (spinning) return;
    if (r.total <= 0) {
      toast('Нет ставок', 'info', 'Поставьте фишки на стол');
      return;
    }
    if (state.balance < r.total) {
      toast('Недостаточно средств', 'lose', 'Уменьшите ставку');
      return;
    }
    audio.click();
    adjust(-r.total);
    stakedRef.current = r.total;
    setResult(null);
    setSpinning(true);
    wheelRef.current?.spin(r.drawResult());
  };

  const onEnd = (res: string) => {
    const { staked, won, bestMult } = r.resolve(res);
    setResult(res);
    setSpinning(false);

    if (won > 0) {
      adjust(won);
      addStats({
        gamesPlayed: 1, gameWins: 1, wagered: staked,
        bestWin: Math.max(0, won - state.stats.bestWin),
      });
      log({ kind: 'game', text: `Рулетка: ${res} · выигрыш`, amount: won - staked, success: true });
      if (bestMult >= 35) { setBurst((b) => b + 1); audio.bigWin(); } else audio.win();
      toast('Выигрыш!', 'win', `Выпало ${res} · +${fmt(won)}`);
    } else {
      addStats({ gamesPlayed: 1, wagered: staked });
      log({ kind: 'game', text: `Рулетка: ${res} · проигрыш`, amount: -staked, success: false });
      audio.lose();
      toast('Не повезло', 'lose', `Выпало ${res}`);
    }
  };

  const resColor = result ? colorOf(result) : null;

  return (
    <div className="fade-up space-y-3">
      {/* шапка: вариант и история */}
      <div className="panel p-2.5">
        <div className="mb-2 flex items-center gap-2">
          <div className="chip-row">
            <button className={cn('chip', variant === 'eu' && 'on')} disabled={spinning}
              onClick={() => { audio.click(); setVariant('eu'); }}>
              Европейская
            </button>
            <button className={cn('chip', variant === 'us' && 'on')} disabled={spinning}
              onClick={() => { audio.click(); setVariant('us'); }}>
              Американская
            </button>
          </div>
          <button className="chip ml-auto shrink-0" onClick={() => { audio.click(); setShowStats((v) => !v); }}>
            <BarChart3 size={13} />
          </button>
        </div>

        {/* история спинов */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {r.history.length === 0 && (
            <span className="py-1 text-[10px] text-slate-600">История пуста</span>
          )}
          {r.history.map((h, i) => {
            const c = colorOf(h);
            return (
              <span key={i}
                className={cn(
                  'grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-extrabold text-white',
                  i === 0 && 'pop-in ring-2 ring-gold/70',
                )}
                style={{
                  background: c === 'red' ? '#c0262f' : c === 'black' ? '#14171f' : '#0f8a46',
                  border: '1px solid rgba(255,255,255,.18)',
                }}
              >
                {h}
              </span>
            );
          })}
        </div>

        {(streak.n >= 2 || last100.length >= 5) && (
          <div className="mt-1.5 flex items-center gap-2 text-[9.5px] font-bold">
            {streak.n >= 2 && streak.color && (
              <span
                className="rounded-md px-2 py-0.5 text-white"
                style={{ background: streak.color === 'red' ? '#c0262f' : '#14171f' }}
              >
                {streak.color === 'red' ? 'Красное' : 'Чёрное'} ×{streak.n}
              </span>
            )}
            {last100.length >= 5 && (
              <span className="num ml-auto text-slate-500">
                за {last100.length}: <span className="text-rose-400">R {rc}</span> /{' '}
                <span className="text-slate-300">B {bc}</span> /{' '}
                <span className="text-emerald-400">0 {zc}</span>
              </span>
            )}
          </div>
        )}

        {showStats && (
          <div className="fade-up mt-2 grid grid-cols-4 gap-1.5">
            {[
              ['Спинов', String(r.stats.spins)],
              ['Ставки', fmt(r.stats.wagered)],
              ['Выплаты', fmt(r.stats.won)],
              ['RTP', `${r.rtp.toFixed(0)}%`],
            ].map(([k, v]) => (
              <div key={k} className="panel-inset px-1 py-1.5 text-center">
                <div className="num truncate text-[11px] font-extrabold">{v}</div>
                <div className="text-[8px] uppercase tracking-wider text-slate-500">{k}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* колесо */}
      <div className="panel relative overflow-hidden p-3">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-gold/6 to-transparent" />
        <RouletteWheel ref={wheelRef} variant={variant} onEnd={onEnd} />
        {burst > 0 && <ConfettiBurst key={burst} />}

        {/* результат */}
        <div className="mt-1 flex h-[46px] items-center justify-center">
          {spinning ? (
            <div className="pulse-soft text-[11px] font-bold uppercase tracking-[0.24em] text-gold">
              шарик в игре…
            </div>
          ) : result ? (
            <div className="pop-in flex items-center gap-2.5">
              <span
                className="grid h-11 w-11 place-items-center rounded-full font-display text-[18px] font-extrabold text-white"
                style={{
                  background: resColor === 'red' ? '#c0262f' : resColor === 'black' ? '#14171f' : '#0f8a46',
                  boxShadow: '0 0 20px rgba(246,196,69,.55)',
                  border: '2px solid #f6c445',
                }}
              >
                {result}
              </span>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                {resColor === 'red' ? 'Красное' : resColor === 'black' ? 'Чёрное' : 'Зеро'}
              </span>
            </div>
          ) : (
            <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-600">
              сделайте ставки
            </div>
          )}
        </div>
      </div>

      {/* номиналы фишек */}
      <div className="panel p-2.5">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Фишка</span>
          <span className="num text-[11px] font-bold text-slate-400">
            На столе: <span className="text-gold">{fmt(r.total)}</span>
          </span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1.5 pt-1">
          {CHIPS.map((v) => (
            <ChipButton key={v} value={v} active={chip === v} onClick={() => { audio.click(); setChip(v); }} />
          ))}
        </div>

        <div className="chip-row mt-2">
          <button className="chip" disabled={spinning || !r.bets.length} onClick={() => { audio.click(); r.undo(); }}>
            <RotateCcw size={12} className="mr-1" /> Отменить
          </button>
          <button className="chip" disabled={spinning || !r.bets.length} onClick={() => { audio.click(); r.clear(); }}>
            <Trash2 size={12} className="mr-1" /> Очистить
          </button>
          <button className="chip" disabled={spinning || !r.hasLast()} onClick={() => { audio.click(); r.repeat(); }}>
            <Copy size={12} className="mr-1" /> Повтор
          </button>
          <button className="chip" disabled={spinning || !r.bets.length} onClick={() => { audio.click(); r.double(); }}>
            ×2
          </button>
        </div>
      </div>

      {/* стол */}
      <RouletteTable
        variant={variant}
        bets={r.bets}
        disabled={spinning}
        winning={spinning ? null : result}
        onPlace={place}
      />

      {/* спин */}
      <button
        onClick={spin}
        disabled={spinning || r.total <= 0}
        className={cn(
          'btn btn-gold btn-shine w-full py-4 font-display text-[15px] font-extrabold uppercase tracking-[0.14em]',
          r.total > 0 && !spinning && 'animate-pulse',
        )}
      >
        <Play size={17} /> {spinning ? 'Вращение…' : `Крутить · ${fmt(r.total)}`}
      </button>

      <div className="pb-1 text-center text-[9.5px] leading-relaxed text-slate-600">
        Выплаты: число 35:1 · сплит 17:1 · улица 11:1 · угол 8:1 · линия 5:1 · дюжина и колонка 2:1 · равные шансы 1:1
      </div>
    </div>
  );
}
