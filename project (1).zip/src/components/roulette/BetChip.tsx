import { memo } from 'react';
import { CHIP_STYLE } from '../../data/roulette';

const label = (v: number) => (v >= 1000 ? `${v / 1000}K` : String(v));

/** Ближайший «номинал» для окраски стопки фишек */
function styleFor(amount: number) {
  const keys = Object.keys(CHIP_STYLE).map(Number).sort((a, b) => b - a);
  const hit = keys.find((k) => amount >= k) ?? keys[keys.length - 1];
  return CHIP_STYLE[hit];
}

/** Фишка на столе. size — диаметр в px */
export const BetChip = memo(function BetChip({
  amount, size = 26, drop, onClick,
}: {
  amount: number;
  size?: number;
  /** анимация падения на стол */
  drop?: boolean;
  onClick?: (e: React.MouseEvent) => void;
}) {
  const s = styleFor(amount);
  return (
    <span
      onClick={onClick}
      className={drop ? 'chip-drop' : undefined}
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        background: `radial-gradient(circle at 36% 30%, ${s.bg}, ${s.ring})`,
        border: `${Math.max(1.5, size * 0.09)}px dashed ${s.ring}`,
        boxShadow: `0 2px 6px rgba(0,0,0,.6), inset 0 0 0 1px rgba(255,255,255,.25)`,
        color: s.text,
        fontSize: size * 0.36,
        fontWeight: 800,
        display: 'grid',
        placeItems: 'center',
        lineHeight: 1,
        userSelect: 'none',
      }}
    >
      {label(amount)}
    </span>
  );
});

/** Кнопка выбора номинала */
export const ChipButton = memo(function ChipButton({
  value, active, onClick,
}: {
  value: number;
  active: boolean;
  onClick: () => void;
}) {
  const s = CHIP_STYLE[value];
  return (
    <button
      onClick={onClick}
      className="shrink-0 transition-transform active:scale-95"
      style={{
        width: 46,
        height: 46,
        borderRadius: '50%',
        background: `radial-gradient(circle at 36% 30%, ${s.bg}, ${s.ring})`,
        border: `3px dashed ${active ? '#ffd964' : s.ring}`,
        boxShadow: active
          ? '0 0 0 2px #ffd964, 0 4px 14px rgba(246,196,69,.5)'
          : '0 3px 8px rgba(0,0,0,.6)',
        color: s.text,
        fontSize: 13,
        fontWeight: 800,
        transform: active ? 'translateY(-4px)' : undefined,
      }}
    >
      {label(value)}
    </button>
  );
});
