import { memo, useMemo } from 'react';
import {
  colorOf, COLUMNS, DOZENS, type Bet, type BetType, type Variant,
} from '../../data/roulette';
import { BetChip } from './BetChip';

const ROWS = 12;
const CELL_H = 44;                 // тач-таргет ячейки не меньше 44px
const ZERO_H = 44;
const GAP = 2;
const GRID_TOP = ZERO_H + GAP;
const GRID_H = ROWS * CELL_H;
const HOT_W = 46;                  // точка внутренней ставки: широкая по X…
const HOT_H = CELL_H / 2;          // …и ровно в полуячейку по Y, чтобы не перекрывались
const EDGE_PAD = 18;               // место под краевые точки (улица / линия)

/**
 * Раскладка настоящего стола, развёрнутая вертикально под телефон:
 * читается сверху вниз, справа налево — 3-2-1, 6-5-4, 9-8-7 … 36-35-34.
 * Левая колонка — числа, кратные 3, правая — 3k+1.
 */
const posOf = (n: number) => ({ row: Math.floor((n - 1) / 3), col: 2 - ((n - 1) % 3) });
/** число по координатам сетки */
const numAt = (row: number, col: number) => row * 3 + (3 - col);

const colX = (c: number) => `${(c * 100) / 3 + 100 / 6}%`;  // центр колонки
const edgeX = (i: number) => `${(i * 100) / 3}%`;           // граница колонок

const WHITE_LINE = 'rgba(255,255,255,.6)';

interface Props {
  variant: Variant;
  bets: Bet[];
  disabled?: boolean;
  winning?: string | null;
  onPlace: (type: BetType, numbers: string[]) => void;
}

export const RouletteTable = memo(function RouletteTable({
  variant, bets, disabled, winning, onPlace,
}: Props) {
  /** суммы ставок по ключу «тип:числа» */
  const amounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const b of bets) m.set(b.id, b.amount);
    return m;
  }, [bets]);

  const amt = (type: BetType, numbers: string[]) =>
    amounts.get(`${type}:${numbers.join('-')}`) ?? 0;

  const tap = (type: BetType, numbers: string[]) => {
    if (!disabled) onPlace(type, numbers);
  };

  /* ---------- точки внутренних ставок ---------- */
  const hotspots = useMemo(() => {
    const hs: Array<{ key: string; x: string; y: number; type: BetType; nums: string[] }> = [];

    for (let r = 0; r < ROWS; r++) {
      const base = r * 3;
      const yMid = GRID_TOP + r * CELL_H + CELL_H / 2;
      const yEnd = GRID_TOP + (r + 1) * CELL_H;

      /* сплиты внутри ряда (соседние колонки) */
      for (let c = 0; c < 2; c++) {
        const a = numAt(r, c);
        const b = numAt(r, c + 1);
        const pair = [Math.min(a, b), Math.max(a, b)].map(String);
        hs.push({ key: `sh-${pair[0]}`, x: edgeX(c + 1), y: yMid, type: 'split', nums: pair });
      }

      /* улица — правый край ряда */
      hs.push({
        key: `st-${base + 1}`, x: '100%', y: yMid,
        type: 'street', nums: [base + 1, base + 2, base + 3].map(String),
      });

      if (r < ROWS - 1) {
        /* сплиты по вертикали (одна колонка, соседние ряды) */
        for (let c = 0; c < 3; c++) {
          const pair = [numAt(r, c), numAt(r + 1, c)].map(String);
          hs.push({ key: `sv-${pair[0]}`, x: colX(c), y: yEnd, type: 'split', nums: pair });
        }
        /* углы — пересечение четырёх чисел */
        for (let c = 0; c < 2; c++) {
          const ns = [numAt(r, c), numAt(r, c + 1), numAt(r + 1, c), numAt(r + 1, c + 1)]
            .sort((p, q) => p - q).map(String);
          hs.push({ key: `co-${ns[0]}`, x: edgeX(c + 1), y: yEnd, type: 'corner', nums: ns });
        }
        /* линия из шести — левый край на стыке двух улиц */
        hs.push({
          key: `sl-${base + 1}`, x: '0%', y: yEnd,
          type: 'sixline',
          nums: Array.from({ length: 6 }, (_, i) => String(base + 1 + i)),
        });
      }
    }

    /* сплиты с зеро: 0 стоит над «3», 00 — над «2» */
    hs.push({ key: 'z03', x: colX(0), y: GRID_TOP, type: 'split', nums: ['0', '3'] });
    if (variant === 'us') {
      hs.push({ key: 'z002', x: colX(1), y: GRID_TOP, type: 'split', nums: ['00', '2'] });
      hs.push({ key: 'z000', x: edgeX(1), y: ZERO_H / 2, type: 'split', nums: ['0', '00'] });
    }
    return hs;
  }, [variant]);

  /* ---------- внешняя ставка ---------- */
  const Outside = ({
    type, numbers, label, bg,
  }: {
    type: BetType; numbers: string[]; label: string; bg?: string;
  }) => {
    const a = amt(type, numbers);
    return (
      <button
        onClick={() => tap(type, numbers)}
        disabled={disabled}
        className="relative grid min-h-[46px] place-items-center rounded-[3px] text-[12px] font-extrabold uppercase tracking-wide text-white active:brightness-125"
        style={{ background: bg ?? '#0d6b3f', border: `1px solid ${WHITE_LINE}` }}
      >
        <span style={{ textShadow: '0 1px 2px rgba(0,0,0,.85)' }}>{label}</span>
        {a > 0 && (
          <span className="absolute -top-1.5 right-1 z-10"><BetChip amount={a} size={26} drop /></span>
        )}
      </button>
    );
  };

  const zeroCell = (z: string) => {
    const a = amt('straight', [z]);
    const win = winning === z;
    return (
      <button
        key={z}
        onClick={() => tap('straight', [z])}
        disabled={disabled}
        className="relative grid place-items-center text-[16px] font-extrabold text-white active:brightness-125"
        style={{
          height: ZERO_H,
          background: '#0f8a46',
          boxShadow: win ? 'inset 0 0 0 2px #f6c445, 0 0 18px #f6c445' : undefined,
        }}
      >
        <span style={{ textShadow: '0 1px 2px rgba(0,0,0,.85)' }}>{z}</span>
        {a > 0 && <span className="absolute z-10"><BetChip amount={a} size={26} drop /></span>}
      </button>
    );
  };

  return (
    <div
      className="rounded-xl border-2 border-[#d8b871]/70 bg-[#0b5c36] py-2"
      style={{ boxShadow: 'inset 0 0 46px rgba(0,0,0,.5)', paddingLeft: EDGE_PAD, paddingRight: EDGE_PAD }}
    >
      {/* зеро + числа + точки внутренних ставок */}
      <div className="relative" style={{ height: GRID_TOP + GRID_H }}>

        {/* ряд с зеро: обычная ячейка слева сверху */}
        <div
          className="absolute inset-x-0 top-0 grid"
          style={{
            height: ZERO_H,
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 1,
            background: WHITE_LINE,
            border: `1px solid ${WHITE_LINE}`,
          }}
        >
          {zeroCell('0')}
          {variant === 'us' ? zeroCell('00') : <div style={{ background: '#0b5c36' }} />}
          <div style={{ background: '#0b5c36' }} />
        </div>

        {/* сетка чисел: тонкие белые линии делаются просветами */}
        <div
          className="absolute inset-x-0 grid"
          style={{
            top: GRID_TOP,
            height: GRID_H,
            gridTemplateColumns: 'repeat(3, 1fr)',
            gridTemplateRows: `repeat(${ROWS}, 1fr)`,
            gap: 1,
            background: WHITE_LINE,
            border: `1px solid ${WHITE_LINE}`,
          }}
        >
          {Array.from({ length: 36 }, (_, i) => i + 1).map((num) => {
            const { row, col } = posOf(num);
            const red = colorOf(String(num)) === 'red';
            const a = amt('straight', [String(num)]);
            const win = winning === String(num);
            return (
              <button
                key={num}
                onClick={() => tap('straight', [String(num)])}
                disabled={disabled}
                style={{
                  gridColumn: col + 1,
                  gridRow: row + 1,
                  background: red ? '#c0262f' : '#14171f',
                  boxShadow: win ? 'inset 0 0 0 2px #f6c445, 0 0 18px #f6c445' : undefined,
                }}
                className="relative grid place-items-center text-[15px] font-extrabold text-white active:brightness-150"
              >
                <span style={{ textShadow: '0 1px 2px rgba(0,0,0,.85)' }}>{num}</span>
                {a > 0 && <span className="absolute z-10"><BetChip amount={a} size={26} drop /></span>}
              </button>
            );
          })}
        </div>

        {/* точки: сплиты, углы, улицы, линии */}
        {hotspots.map((h) => {
          const a = amt(h.type, h.nums);
          return (
            <button
              key={h.key}
              onClick={() => tap(h.type, h.nums)}
              disabled={disabled}
              aria-label={`${h.type} ${h.nums.join(', ')}`}
              className="absolute z-20 grid place-items-center rounded-full"
              style={{
                left: h.x, top: h.y, width: HOT_W, height: HOT_H,
                transform: 'translate(-50%,-50%)',
                background: a > 0 ? 'transparent' : 'rgba(255,255,255,.07)',
              }}
            >
              {a > 0
                ? <BetChip amount={a} size={26} drop />
                : <span className="h-1.5 w-1.5 rounded-full bg-white/45" />}
            </button>
          );
        })}
      </div>

      {/* колонки 2:1 — под своими колонками чисел */}
      <div className="mt-0.5 grid grid-cols-3 gap-px">
        {COLUMNS.map((nums, i) => (
          <Outside key={i} type="column" numbers={nums} label="2:1" />
        ))}
      </div>

      {/* дюжины */}
      <div className="mt-0.5 grid grid-cols-3 gap-px">
        {DOZENS.map((nums, i) => (
          <Outside key={i} type="dozen" numbers={nums} label={['1-12', '13-24', '25-36'][i]} />
        ))}
      </div>

      {/* равные шансы */}
      <div className="mt-0.5 grid grid-cols-2 gap-px">
        <Outside type="low" numbers={[]} label="1–18" />
        <Outside type="high" numbers={[]} label="19–36" />
        <Outside type="even" numbers={[]} label="Чёт" />
        <Outside type="odd" numbers={[]} label="Нечёт" />
        <Outside type="red" numbers={[]} label="Красное" bg="#c0262f" />
        <Outside type="black" numbers={[]} label="Чёрное" bg="#14171f" />
      </div>
    </div>
  );
});
