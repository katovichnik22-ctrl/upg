import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef } from 'react';
import { colorOf, wheelOrder, type Variant } from '../../data/roulette';
import { audio } from '../../lib/audio';

export interface WheelHandle {
  /** Запустить вращение до указанного сектора */
  spin: (result: string) => void;
  readonly spinning: boolean;
}

const TAU = Math.PI * 2;
/** Верх колеса — точка, где шарик падает в карман */
const TOP = -Math.PI / 2;

const POCKET_FILL: Record<string, string> = {
  red: '#c0262f',
  black: '#14171f',
  green: '#0f8a46',
};

const RouletteWheel = forwardRef<WheelHandle, {
  variant: Variant;
  duration?: number;
  onEnd: (result: string) => void;
}>(({ variant, duration = 7000, onEnd }, ref) => {
  const order = useMemo(() => wheelOrder(variant), [variant]);
  const n = order.length;
  const seg = TAU / n;

  const plateRef = useRef<SVGGElement>(null);
  const ballRef = useRef<SVGGElement>(null);
  const glowRef = useRef<SVGCircleElement>(null);

  const raf = useRef(0);
  const st = useRef({
    spinning: false, start: 0, dur: duration,
    plateFrom: 0, plateTo: 0,
    ballFrom: 0, ballTo: 0,
    result: '', idx: 0, lastTick: -1,
  });
  const idleRef = useRef(0);
  const onEndRef = useRef(onEnd);
  onEndRef.current = onEnd;

  useImperativeHandle(ref, () => ({
    get spinning() { return st.current.spinning; },
    spin(result: string) {
      const s = st.current;
      if (s.spinning) return;
      const idx = Math.max(0, order.indexOf(result));

      /* Колесо крутится по часовой, шарик — против (как в казино).
         Колесо доводим так, чтобы выигрышный карман встал ровно под
         верхнюю метку, шарик приземляем в ту же точку. */
      const pocketAngle = idx * seg + seg / 2;
      const plateFrom = idleRef.current;
      const plateTurns = 5 + Math.floor(Math.random() * 2);
      let plateTo = TOP - pocketAngle;
      while (plateTo < plateFrom + plateTurns * TAU) plateTo += TAU;

      const ballFrom = 0;
      const ballTurns = 9 + Math.floor(Math.random() * 2);
      let ballTo = TOP;
      while (ballTo > ballFrom - ballTurns * TAU) ballTo -= TAU;

      s.spinning = true;
      s.start = performance.now();
      s.dur = duration;
      s.plateFrom = plateFrom;
      s.plateTo = plateTo;
      s.ballFrom = ballFrom;
      s.ballTo = ballTo;
      s.result = result;
      s.idx = idx;
      s.lastTick = -1;
      if (glowRef.current) glowRef.current.style.opacity = '0';
    },
  }), [order, seg, duration]);

  useEffect(() => {
    const loop = (t: number) => {
      const s = st.current;
      const plate = plateRef.current;
      const ball = ballRef.current;

      if (s.spinning) {
        const p = Math.min(1, (t - s.start) / s.dur);
        /* колесо: плавное замедление */
        const ep = 1 - Math.pow(1 - p, 3);
        const plateAng = s.plateFrom + (s.plateTo - s.plateFrom) * ep;
        /* шарик: дольше держит скорость, затем резко тормозит */
        const eb = 1 - Math.pow(1 - p, 4.2);
        const ballAng = s.ballFrom + (s.ballTo - s.ballFrom) * eb;

        /* радиус шарика: сначала по ободу, в конце падает в карман */
        const drop = p < 0.72 ? 0 : (p - 0.72) / 0.28;
        const r = 43 - Math.pow(drop, 1.6) * 12;
        /* лёгкие подскоки на финише */
        const bounce = p > 0.72 && p < 0.95
          ? Math.sin((p - 0.72) * 46) * (1 - drop) * 0.8
          : 0;

        if (plate) plate.style.transform = `rotate(${plateAng}rad)`;
        if (ball) {
          ball.style.transform =
            `translate(${Math.cos(ballAng) * (r + bounce)}px, ${Math.sin(ballAng) * (r + bounce)}px)`;
        }

        /* стук по разделителям при замедлении */
        const tickIdx = Math.floor((ballAng / seg));
        if (tickIdx !== s.lastTick) {
          s.lastTick = tickIdx;
          if (p > 0.25) {
            const vol = Math.min(0.09, 0.02 + (p - 0.25) * 0.1);
            audio.blip(420 + Math.random() * 260, 0.022, 'square', vol);
          }
        }

        if (p >= 1) {
          s.spinning = false;
          idleRef.current = s.plateTo;
          if (glowRef.current) glowRef.current.style.opacity = '1';
          const res = s.result;
          window.setTimeout(() => onEndRef.current(res), 200);
        }
      } else {
        /* лёгкое холостое вращение */
        idleRef.current += 0.0012;
        if (plate) plate.style.transform = `rotate(${idleRef.current}rad)`;
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, [seg]);

  /* сброс подсветки при новом спине */
  useEffect(() => {
    if (glowRef.current) glowRef.current.style.opacity = '0';
  }, [variant]);

  return (
    <svg viewBox="-55 -55 110 110" className="block w-full select-none" style={{ maxHeight: 340 }}>
      <defs>
        <radialGradient id="rimGrad" cx="0.35" cy="0.3">
          <stop offset="0" stopColor="#c8922f" />
          <stop offset="0.5" stopColor="#8a5c16" />
          <stop offset="1" stopColor="#4a2f08" />
        </radialGradient>
        <radialGradient id="woodGrad" cx="0.4" cy="0.35">
          <stop offset="0" stopColor="#6b3d1c" />
          <stop offset="1" stopColor="#2f1a0b" />
        </radialGradient>
        <radialGradient id="coneGrad" cx="0.35" cy="0.3">
          <stop offset="0" stopColor="#fff7de" />
          <stop offset="0.45" stopColor="#d9b45e" />
          <stop offset="1" stopColor="#6b4a12" />
        </radialGradient>
        <radialGradient id="ballGrad" cx="0.35" cy="0.3">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.6" stopColor="#dfe6f2" />
          <stop offset="1" stopColor="#8e9ab0" />
        </radialGradient>
      </defs>

      {/* внешний обод */}
      <circle r="54" fill="url(#woodGrad)" />
      <circle r="49" fill="url(#rimGrad)" />
      <circle r="46.5" fill="#0d1017" />

      {/* вращающаяся тарелка */}
      <g ref={plateRef} style={{ transformOrigin: '0px 0px' }}>
        {order.map((num, i) => {
          const a0 = i * seg;
          const a1 = a0 + seg;
          const x0 = Math.cos(a0) * 41, y0 = Math.sin(a0) * 41;
          const x1 = Math.cos(a1) * 41, y1 = Math.sin(a1) * 41;
          const xi0 = Math.cos(a0) * 17, yi0 = Math.sin(a0) * 17;
          const xi1 = Math.cos(a1) * 17, yi1 = Math.sin(a1) * 17;
          const mid = a0 + seg / 2;
          const tx = Math.cos(mid) * 34, ty = Math.sin(mid) * 34;
          const deg = (mid * 180) / Math.PI + 90;
          return (
            <g key={`${num}-${i}`}>
              <path
                d={`M${x0} ${y0}A41 41 0 0 1 ${x1} ${y1}L${xi1} ${yi1}A17 17 0 0 0 ${xi0} ${yi0}Z`}
                fill={POCKET_FILL[colorOf(num)]}
                stroke="#d8b871"
                strokeWidth="0.35"
              />
              <text
                x={tx} y={ty}
                fill="#fff"
                fontSize={num.length > 1 ? 4.4 : 5}
                fontWeight="700"
                textAnchor="middle"
                dominantBaseline="central"
                transform={`rotate(${deg} ${tx} ${ty})`}
                style={{ paintOrder: 'stroke', stroke: '#00000088', strokeWidth: 0.5 }}
              >
                {num}
              </text>
            </g>
          );
        })}

        {/* разделители карманов */}
        {order.map((_, i) => {
          const a = i * seg;
          return (
            <line
              key={`sep-${i}`}
              x1={Math.cos(a) * 17} y1={Math.sin(a) * 17}
              x2={Math.cos(a) * 41} y2={Math.sin(a) * 41}
              stroke="#e2c785" strokeWidth="0.35" opacity="0.75"
            />
          );
        })}

        {/* металлический конус в центре */}
        <circle r="17" fill="url(#coneGrad)" stroke="#5b3f0d" strokeWidth="0.6" />
        <circle r="11" fill="none" stroke="#8a6a22" strokeWidth="0.5" opacity="0.7" />
        <ellipse cx="-4" cy="-5" rx="7" ry="4.5" fill="#fff" opacity="0.28" />
        <circle r="4.5" fill="#3b2a08" />
        <circle r="2" fill="#d9b45e" />
      </g>

      {/* дорожка шарика */}
      <circle r="44.5" fill="none" stroke="#000" strokeWidth="2.4" opacity="0.45" />
      <circle r="44.5" fill="none" stroke="#f0d79a" strokeWidth="0.4" opacity="0.35" />

      {/* шарик */}
      <g ref={ballRef} style={{ transformOrigin: '0px 0px' }}>
        <circle r="2.9" fill="url(#ballGrad)" />
        <circle cx="-0.9" cy="-0.9" r="0.9" fill="#fff" opacity="0.9" />
      </g>

      {/* подсветка выигрышного кармана (всегда сверху) */}
      <circle
        ref={glowRef}
        cx={0} cy={-29} r={7}
        fill="none" stroke="#ffd964" strokeWidth="1.8"
        style={{ opacity: 0, transition: 'opacity .25s', filter: 'drop-shadow(0 0 3px #f6c445)' }}
      />

      {/* метка верхней точки */}
      <path d="M0 -50.5l2.6 4.6h-5.2z" fill="#ffd964" />
    </svg>
  );
});

RouletteWheel.displayName = 'RouletteWheel';
export default RouletteWheel;
