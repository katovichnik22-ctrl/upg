import { useState } from 'react';
import { createPortal } from 'react-dom';
import { MousePointerClick, ShieldCheck } from 'lucide-react';
import type { Economy } from '../lib/store';
import { audio } from '../lib/audio';
import { LogoMark } from './TopBar';

/**
 * Создание профиля. Режим экономики один — честный кликер:
 * баланс зарабатывается только игрой, пополнения нет.
 */
export default function EconomyPicker({
  title = 'Новый профиль',
  initialName = '',
  onDone,
  onCancel,
}: {
  title?: string;
  initialName?: string;
  onDone: (name: string, economy: Economy) => void;
  onCancel?: () => void;
}) {
  const [name, setName] = useState(initialName);

  const body = (
    <div
      className="fixed inset-0 z-[98] flex items-center justify-center overflow-y-auto bg-black/88 p-3 backdrop-blur-md"
      style={{ minHeight: '100dvh' }}
    >
      <div className="pop-in panel my-auto w-full max-w-[440px] p-4">
        <div className="mb-3 flex items-center gap-2.5">
          <LogoMark size={34} />
          <div>
            <div className="font-display text-[14px] font-extrabold">{title}</div>
            <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">
              NIKGRAGER
            </div>
          </div>
        </div>

        <input
          value={name}
          maxLength={18}
          autoFocus
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && name.trim()) { audio.coin(); onDone(name.trim(), 'clicker'); }
          }}
          placeholder="Имя профиля"
          className="input mb-3 w-full px-3 py-3 text-[14px] font-bold"
        />

        <div className="rounded-2xl border border-emerald-400/40 bg-emerald-400/10 p-3">
          <div className="flex items-center gap-2.5">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-400/15 text-emerald-300 ring-1 ring-emerald-400/30">
              <MousePointerClick size={18} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-extrabold text-emerald-300">Честный режим</div>
              <div className="text-[10.5px] leading-snug text-slate-400">
                Весь баланс зарабатывается в кликере и играх. Пополнения нет.
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-start gap-2 rounded-xl bg-white/4 p-2.5 text-[10px] leading-relaxed text-slate-500">
          <ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-400" />
          Прогресс идёт медленно и честно — быстрых денег в игре нет.
        </div>

        <div className="mt-3 grid gap-2" style={{ gridTemplateColumns: onCancel ? '1fr 1fr' : '1fr' }}>
          {onCancel && (
            <button className="btn btn-ghost py-3 text-[12.5px]" onClick={() => { audio.click(); onCancel(); }}>
              Отмена
            </button>
          )}
          <button
            disabled={!name.trim()}
            onClick={() => { audio.coin(); onDone(name.trim(), 'clicker'); }}
            className="btn btn-gold btn-shine py-3 text-[12.5px] font-extrabold uppercase tracking-wider"
          >
            Начать игру
          </button>
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(body, document.body);
}
