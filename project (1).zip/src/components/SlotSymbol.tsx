import { memo, useState } from 'react';
import { symbol } from '../data/slotSymbols';
import { cn } from '../utils/cn';

/** Символ барабана: картинка из public/slots, при ошибке — цветной плейсхолдер */
export const SlotSymbol = memo(function SlotSymbol({
  name, size = 48, dim,
}: {
  name: string;
  size?: number;
  dim?: boolean;
}) {
  const def = symbol(name);
  const [err, setErr] = useState(false);

  if (err) {
    return (
      <div
        className="grid place-items-center rounded-lg font-display font-extrabold"
        style={{
          width: size,
          height: size,
          background: `linear-gradient(160deg, ${def.color}44, ${def.color}14)`,
          border: `1.5px solid ${def.color}77`,
          color: def.color,
          fontSize: size * 0.42,
        }}
      >
        {def.label[0]}
      </div>
    );
  }

  return (
    <img
      src={def.image}
      alt={def.label}
      draggable={false}
      onError={() => setErr(true)}
      className={cn('select-none object-contain', dim && 'opacity-70')}
      style={{
        width: size,
        height: size,
        filter: 'drop-shadow(0 3px 6px rgba(0,0,0,.55))',
      }}
    />
  );
});
