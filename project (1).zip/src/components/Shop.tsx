import { useMemo, useRef, useState } from 'react';
import {
  ShoppingBag, Gift, PackageOpen, Banknote, BadgeCheck, MousePointerClick,
} from 'lucide-react';
import type { Skin } from '../lib/types';
import { useGame, useSkins } from '../lib/store';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { SectionTitle } from './ui';
import Market from './Market';
import PromoBox from './PromoBox';
import MultiCaseOpening, { type OpenedLine } from './MultiCaseOpening';
import { CASES, CATEGORIES, reelPool, rollCaseDrop, type CaseDef, type CaseCat } from '../lib/cases';
import { cn } from '../utils/cn';

export default function Shop({ onGoClicker }: { onGoClicker: () => void }) {
  const { state, adjust, addItem, sellItem, log, addStats, claimBonus, toast } = useGame();
  const { skins } = useSkins();
  const [opened, setOpened] = useState<{ c: CaseDef; lines: OpenedLine[] } | null>(null);
  const [qty, setQty] = useState(1);
  const [cat, setCat] = useState<CaseCat | 'all'>('all');

  const shownCases = useMemo(
    () => (cat === 'all' ? CASES : CASES.filter((c) => c.cat === cat)),
    [cat],
  );

  const bonusTaken = state.lastBonus === new Date().toDateString();

  const bonus = () => {
    if (claimBonus()) toast('Ежедневный бонус получен', 'win', '+500 ₽');
    else toast('Бонус уже получен сегодня', 'info', 'Возвращайтесь завтра');
  };

  /* a ref guard — the state closure inside timers is stale after "open again" */
  const busyRef = useRef(false);

  const openCase = (c: CaseDef, count = qty) => {
    if (busyRef.current) return;
    const total = c.price * count;
    if (state.balance < total) {
      toast('Недостаточно средств', 'lose', `Нужно ${fmt(total)}`);
      return;
    }
    busyRef.current = true;
    audio.click();
    adjust(-total);

    const pool = reelPool(skins, c);
    const lines: OpenedLine[] = [];
    let won = 0;
    for (let i = 0; i < count; i++) {
      const skin = rollCaseDrop(skins, c);
      lines.push({ winner: addItem(skin), pool });
      won += skin.price;
    }
    addStats({
      casesOpened: count, wagered: total,
      bestWin: Math.max(0, Math.max(...lines.map((l) => l.winner.price)) - state.stats.bestWin),
    });
    log({
      kind: 'case',
      text: count > 1 ? `${c.name} ×${count}` : `${c.name}: выпал ${lines[0].winner.name}`,
      amount: won - total,
      success: won >= total,
    });
    setOpened({ c, lines });
  };

  const closeCase = () => {
    busyRef.current = false;
    setOpened(null);
  };

  const buy = (s: Skin) => {
    if (state.balance < s.price) {
      toast('Недостаточно средств', 'lose', `Не хватает ${fmt(s.price - state.balance)}`);
      return;
    }
    /* buy at full price, sell back at 94% — no risk-free arbitrage */
    adjust(-s.price);
    addItem(s);
    audio.coin();
    log({ kind: 'shop', text: `Куплен ${s.name}`, amount: -s.price, success: true });
    toast('Покупка совершена', 'win', s.name);
  };

  return (
    <div className="fade-up mx-auto max-w-[1100px] space-y-4">
      {/* bonus + deposit */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="panel relative overflow-hidden p-5">
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-emerald-400/15 blur-3xl" />
          <SectionTitle icon={<Gift size={15} className="text-emerald-300" />} title="Ежедневный бонус" />
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="font-display text-2xl font-extrabold text-emerald-300 text-glow-green">+500 ₽</div>
              <div className="mt-1 text-xs text-slate-500">Бесплатно каждый день</div>
            </div>
            <button
              onClick={bonus}
              disabled={bonusTaken}
              className={cn('btn btn-shine px-5 py-3 text-[13px]', bonusTaken ? 'btn-ghost' : 'btn-green')}
            >
              {bonusTaken ? (
                <><BadgeCheck size={15} /> Получен</>
              ) : (
                'Забрать'
              )}
            </button>
          </div>
          {bonusTaken && <div className="mt-2 text-[11px] text-slate-500">Следующий бонус — завтра</div>}
        </div>

        <div className="panel p-5">
          <SectionTitle
            icon={<Banknote size={15} className="text-amber-300" />}
            title="Заработок"
            right={<span className="rounded-md bg-emerald-400/10 px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider text-emerald-300">честный режим</span>}
          />
          <div className="space-y-2">
            <div className="panel-inset p-3 text-[11px] leading-relaxed text-slate-400">
              Пополнения нет. Монеты зарабатываются в кликере и обмениваются
              на баланс по курсу.
            </div>
            <button onClick={onGoClicker} className="btn btn-gold btn-shine w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider">
              <MousePointerClick size={15} /> Заработать в кликере
            </button>
          </div>
        </div>
      </div>

      <PromoBox />

      {/* cases */}
      <div className="panel p-4 sm:p-5">
        <SectionTitle
          icon={<PackageOpen size={15} className="text-gold" />}
          title={`Кейсы · ${shownCases.length}`}
          right={
            <span className="num rounded-md bg-white/5 px-1.5 py-0.5 text-[10.5px] font-bold text-slate-400">
              {CASES.length} всего
            </span>
          }
        />

        <div className="chip-row mb-3 sm:flex-wrap">
          {CATEGORIES.map((k) => (
            <button
              key={k.id}
              className={cn('chip', cat === k.id && 'on')}
              onClick={() => { audio.click(); setCat(k.id); }}
            >
              {k.label}
            </button>
          ))}
        </div>

        <div className="chip-row mb-3">
          <span className="chip pointer-events-none text-slate-500">Открыть</span>
          {[1, 2, 3, 5].map((n) => (
            <button
              key={n}
              className={cn('chip num', qty === n && 'on')}
              onClick={() => { audio.click(); setQty(n); }}
            >
              ×{n}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
          {shownCases.map((c) => {
            const cost = c.price * qty;
            const afford = state.balance >= cost;
            return (
              <div
                key={c.id}
                className="group relative overflow-hidden rounded-2xl border p-3 text-center transition-transform hover:-translate-y-1"
                style={{
                  borderColor: `${c.accent}33`,
                  background: `linear-gradient(170deg, ${c.c1}2e, ${c.c2}40 60%, #0d1119)`,
                }}
              >
                <div
                  className="pointer-events-none absolute -right-6 -top-8 h-24 w-24 rounded-full blur-2xl transition-opacity group-hover:opacity-80"
                  style={{ background: `${c.accent}30` }}
                />
                <div className="relative mx-auto grid h-[68px] place-items-center">
                  <img
                    src={`/cases/${c.cover ?? 'steel'}.svg`}
                    alt={c.name}
                    draggable={false}
                    className="h-[66px] w-auto select-none"
                    style={{ filter: `drop-shadow(0 3px 8px ${c.accent}66)` }}
                  />
                </div>
                <div className="relative mt-2 truncate text-[12.5px] font-extrabold">{c.name}</div>
                <div className="relative truncate text-[9.5px] uppercase tracking-wider text-white/45">{c.desc}</div>
                <div className="relative mt-1.5 flex items-center justify-center gap-1">
                  <span
                    className="num rounded-md bg-black/30 px-1.5 py-0.5 text-[9px] font-extrabold ring-1 ring-white/10"
                    style={{ color: c.accent }}
                  >
                    до {fmt(c.price * 15)}
                  </span>
                  {c.starChance > 0 && (
                    <span className="rounded-md bg-black/30 px-1.5 py-0.5 text-[9px] font-extrabold text-gold ring-1 ring-gold/25">
                      ★ {(c.starChance * 100).toFixed(0)}%
                    </span>
                  )}
                </div>
                <button
                  onClick={() => openCase(c)}
                  disabled={!!opened}
                  className={cn('btn btn-shine relative mt-2.5 w-full py-2.5 text-[12px]', afford ? 'btn-gold' : 'btn-ghost')}
                >
                  {fmt(cost)}{qty > 1 && <span className="ml-1 opacity-70">×{qty}</span>}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <Market onBuy={buy} />

      {/* открытие контейнеров */}
      {opened && (
        <MultiCaseOpening
          key={opened.lines[0]?.winner.uid}
          caseDef={opened.c}
          lines={opened.lines}
          fast={state.settings.fast}
          totalCost={opened.c.price * opened.lines.length}
          canAgain={state.balance >= opened.c.price * opened.lines.length}
          onKeep={() => { audio.click(); closeCase(); }}
          onSellAll={() => {
            let sum = 0;
            for (const l of opened.lines) {
              sum += Math.max(1, Math.round(l.winner.price * 0.94));
              sellItem(l.winner.uid);
            }
            toast('Предметы проданы', 'info', `+${fmt(sum)}`);
            closeCase();
          }}
          onAgain={() => {
            const c = opened.c;
            const n = opened.lines.length;
            closeCase();
            window.setTimeout(() => openCase(c, n), 90);
          }}
        />
      )}

      <div className="text-center text-[11px] text-slate-600">
        <ShoppingBag size={11} className="mr-1 inline -translate-y-px" />
        Демо-магазин: все покупки совершаются за виртуальную валюту
      </div>
    </div>
  );
}
