import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, RotateCcw, Banknote, Sparkles } from 'lucide-react';
import type { OwnedSkin, Skin } from '../lib/types';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { SkinImage } from './ui';
import { cn } from '../utils/cn';

const GAP = 8;
const STRIP = 62;
const WIN_INDEX = 52;

function calcItemW(w: number): number {
  if (w <= 0) return 82;
  if (w < 360) return 72;
  if (w < 440) return 82;
  if (w < 640) return 96;
  return 124;
}

interface Props {
  caseName: string;
  pool: Skin[];
  winner: OwnedSkin;
  fast: boolean;
  onSell: () => void;
  onKeep: () => void;
  onAgain: () => void;
  canAgain: boolean;
  casePrice: number;
}

export default function CaseOpening({
  caseName, pool, winner, fast, onSell, onKeep, onAgain, canAgain, casePrice,
}: Props) {
  const [strip] = useState<Skin[]>(() => {
    const arr: Skin[] = [];
    for (let i = 0; i < STRIP; i++) {
      arr.push(i === WIN_INDEX ? winner : pool[Math.floor(Math.random() * pool.length)] ?? winner);
    }
    return arr;
  });
  const [done, setDone] = useState(false);
  const [itemW, setItemW] = useState(() => {
    const winW = typeof window !== 'undefined' ? window.innerWidth : 360;
    return calcItemW(Math.min(winW - 24, 840));
  });

  const trackRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<HTMLDivElement>(null);
  const raf = useRef(0);
  const tickRef = useRef(-1);
  const startedRef = useRef(false);
  const jitterRef = useRef(0);
  const doneRef = useRef(false);

  /* lock the page background while modal is open */
  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  /* measure container with ResizeObserver for exact pixel accuracy */
  useLayoutEffect(() => {
    const view = viewRef.current;
    if (!view) return;
    const apply = () => {
      const w = view.clientWidth;
      if (w > 0) setItemW(calcItemW(w));
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(view);
    return () => ro.disconnect();
  }, []);

  /* roll animation */
  useEffect(() => {
    if (!itemW) return;
    const track = trackRef.current;
    const view = viewRef.current;
    if (!track || !view) return;

    const full = itemW + GAP;
    const centerOffset = view.clientWidth / 2 - itemW / 2;

    if (doneRef.current) {
      track.style.transition = 'none';
      track.style.transform = `translate3d(${-(WIN_INDEX * full + jitterRef.current - centerOffset)}px,0,0)`;
      return;
    }
    if (startedRef.current) return;
    startedRef.current = true;

    jitterRef.current = Math.round((Math.random() - 0.5) * (itemW * 0.45));

    const target = -(WIN_INDEX * full + jitterRef.current - centerOffset);
    const from = -(6 * full);
    const dur = fast ? 3000 : 5200;
    const t0 = performance.now();

    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 5);
      const x = from + (target - from) * e;
      track.style.transform = `translate3d(${x}px,0,0)`;
      const idx = Math.floor(-x / full);
      if (idx !== tickRef.current) {
        tickRef.current = idx;
        audio.reelTick();
      }
      if (p < 1) {
        raf.current = requestAnimationFrame(step);
      } else {
        doneRef.current = true;
        setDone(true);
        if (winner.price >= casePrice * 3) audio.bigWin(); else audio.win();
      }
    };
    track.style.transform = `translate3d(${from}px,0,0)`;
    raf.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemW]);

  const profit = winner.price - casePrice;
  const cardH = itemW < 78 ? 102 : itemW < 90 ? 112 : itemW < 110 ? 124 : 142;
  const imgH = Math.round(cardH * 0.44);

  const modalContent = (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto overscroll-contain bg-black/85 p-3 pt-[max(12px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] backdrop-blur-md"
      style={{ minHeight: '100dvh' }}
    >
      <div className="relative my-auto w-full max-w-[840px] min-w-0">
        {/* header */}
        <div className="mb-2 flex items-center justify-between gap-2 px-1">
          <div className="min-w-0">
            <div className="truncate font-display text-[12.5px] font-extrabold uppercase tracking-[0.12em] text-slate-200 sm:text-[14px]">
              {caseName}
            </div>
            <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">
              {done ? 'предмет получен' : 'открываем…'}
            </div>
          </div>
          {done && (
            <button
              onClick={onKeep}
              className="shrink-0 rounded-lg bg-white/10 p-2 text-slate-300 transition-colors hover:bg-white/20 hover:text-white"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* reel */}
        <div
          ref={viewRef}
          className="reel-mask relative w-full overflow-hidden rounded-2xl border border-white/10 bg-[#0b0f18] py-3 sm:py-4"
          style={done ? { boxShadow: `inset 0 0 60px -20px ${winner.color}` } : undefined}
        >
          {/* center indicator */}
          <div className="pointer-events-none absolute left-1/2 top-0 z-20 h-full w-[2px] -translate-x-1/2 bg-gold/80 shadow-[0_0_12px_rgba(246,196,69,.9)]" />
          <div className="pointer-events-none absolute left-1/2 top-0 z-20 -translate-x-1/2 border-x-[6px] border-t-[8px] border-x-transparent border-t-gold" />
          <div className="pointer-events-none absolute bottom-0 left-1/2 z-20 -translate-x-1/2 border-x-[6px] border-b-[8px] border-x-transparent border-b-gold" />

          {/* reel track */}
          <div
            ref={trackRef}
            className="flex w-max will-change-transform"
            style={{ gap: GAP }}
          >
            {strip.map((s, i) => (
              <div
                key={i}
                style={{
                  width: itemW,
                  height: cardH,
                  background: `linear-gradient(180deg, ${s.color}18, transparent 65%), #141926`,
                  borderColor: `${s.color}55`,
                }}
                className="relative flex shrink-0 flex-col items-center justify-center overflow-hidden rounded-xl border p-1"
              >
                <span className="absolute inset-x-0 top-0 h-[3px]" style={{ background: s.color, boxShadow: `0 0 10px ${s.color}` }} />
                <div className="flex w-full items-center justify-center" style={{ height: imgH }}>
                  <SkinImage skin={s} className="h-full w-full" />
                </div>
                <div className="mt-0.5 w-full truncate text-center text-[8px] font-bold uppercase tracking-tight text-slate-500">
                  {s.name.replace('★ ', '').split(' | ')[0]}
                </div>
                <div className="w-full truncate text-center text-[9px] font-bold leading-tight" style={{ color: s.color }}>
                  {s.name.replace('★ ', '').split(' | ').slice(1).join(' | ') || '—'}
                </div>
                <div className="num price mt-0.5 truncate text-[8.5px] font-extrabold">{fmt(s.price)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* result panel */}
        {done && (
          <div className="pop-in panel mt-2.5 p-3 sm:p-4">
            <div className="flex flex-col items-center gap-3 sm:flex-row sm:gap-4">
              <div
                className="reveal-glow relative grid h-[88px] w-[130px] shrink-0 place-items-center rounded-xl border sm:h-[96px] sm:w-[140px]"
                style={{
                  borderColor: `${winner.color}66`,
                  background: `radial-gradient(75% 75% at 50% 60%, ${winner.color}22, transparent 72%)`,
                  boxShadow: `0 0 32px -10px ${winner.color}`,
                }}
              >
                <SkinImage skin={winner} className="h-[74px] w-full px-1.5 float-y sm:h-[82px]" imgClassName="max-h-[74px] sm:max-h-[82px]" />
              </div>

              <div className="min-w-0 flex-1 text-center sm:text-left">
                <div className="truncate text-[9.5px] font-bold uppercase tracking-wider text-slate-500">
                  {winner.name.replace('★ ', '').split(' | ')[0]} · {winner.rarityRu}
                </div>
                <div
                  className="truncate font-display text-[14px] font-extrabold leading-tight sm:text-[16.5px]"
                  style={{ color: winner.color }}
                >
                  {winner.name.replace('★ ', '')}
                </div>
                <div className="num mt-1 flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                  <span className="price text-[15px] font-extrabold sm:text-[16px]">{fmt(winner.price)}</span>
                  <span className={cn(
                    'rounded-md px-1.5 py-0.5 text-[10px] font-extrabold',
                    profit >= 0 ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300',
                  )}>
                    {profit >= 0 ? '+' : '−'}{fmt(Math.abs(profit))}
                  </span>
                </div>
              </div>

              <div className="grid w-full shrink-0 grid-cols-2 gap-2 sm:w-auto sm:grid-cols-1 md:grid-cols-2">
                <button onClick={onKeep} className="btn btn-gold min-w-0 px-3.5 py-2.5 text-[12px]">
                  <Sparkles size={14} className="shrink-0" />
                  <span className="truncate">Забрать</span>
                </button>
                <button onClick={onSell} className="btn btn-ghost min-w-0 px-3.5 py-2.5 text-[12px]">
                  <Banknote size={14} className="shrink-0" />
                  <span className="num truncate">{fmt(Math.max(1, Math.round(winner.price * 0.94)))}</span>
                </button>
              </div>
            </div>

            <button
              onClick={onAgain}
              disabled={!canAgain}
              className="btn btn-ghost mt-2.5 w-full py-2.5 text-[12px] hover:bg-gold/12!"
            >
              <RotateCcw size={13} /> Открыть ещё раз · {fmt(casePrice)}
            </button>
          </div>
        )}
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(modalContent, document.body);
}
