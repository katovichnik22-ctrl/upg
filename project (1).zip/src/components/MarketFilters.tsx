import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, RotateCcw, Check } from 'lucide-react';
import { WEAPON_CATS } from '../data/skins';
import { ITEM_TYPES } from '../data/misc';
import { RARITIES, WEARS } from '../data/rarity';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';

export interface Filters {
  q: string;
  types: string[];     // категории предметов
  cats: string[];      // модели оружия
  rarities: string[];
  wears: string[];
  stattrak: 'all' | 'yes' | 'no';
  souvenir: 'all' | 'yes' | 'no';
  min: number;
  max: number;         // 0 = без ограничения
}

export const EMPTY_FILTERS: Filters = {
  q: '', types: [], cats: [], rarities: [], wears: [],
  stattrak: 'all', souvenir: 'all', min: 0, max: 0,
};

const KEY = 'nikgrager-market-filters';

export function loadFilters(): Filters {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...EMPTY_FILTERS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return EMPTY_FILTERS;
}

export function saveFilters(f: Filters) {
  try { localStorage.setItem(KEY, JSON.stringify(f)); } catch { /* ignore */ }
}

/** Сколько фильтров активно — для счётчика на кнопке */
export function countActive(f: Filters): number {
  return (f.q ? 1 : 0) + f.types.length + f.cats.length + f.rarities.length + f.wears.length
    + (f.stattrak !== 'all' ? 1 : 0) + (f.souvenir !== 'all' ? 1 : 0)
    + (f.min > 0 ? 1 : 0) + (f.max > 0 ? 1 : 0);
}

const toggle = (arr: string[], v: string) =>
  arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v];

/** Шторка с подробными фильтрами маркета */
export default function MarketFilters({
  value, onApply, onClose,
}: {
  value: Filters;
  onApply: (f: Filters) => void;
  onClose: () => void;
}) {
  const [f, setF] = useState<Filters>(value);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  const set = <K extends keyof Filters>(k: K, v: Filters[K]) => setF((s) => ({ ...s, [k]: v }));

  const Tri = ({ label, k }: { label: string; k: 'stattrak' | 'souvenir' }) => (
    <div>
      <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">{label}</div>
      <div className="chip-row">
        {([['all', 'Все'], ['yes', 'Только да'], ['no', 'Только нет']] as const).map(([v, t]) => (
          <button key={v} className={cn('chip', f[k] === v && 'on')}
            onClick={() => { audio.click(); set(k, v); }}>{t}</button>
        ))}
      </div>
    </div>
  );

  const body = (
    <div className="fixed inset-0 z-[97] flex items-end justify-center bg-black/75 backdrop-blur-sm"
      style={{ minHeight: '100dvh' }} onClick={onClose}>
      <div
        className="panel w-full max-w-[480px] rounded-b-none p-4"
        style={{ maxHeight: '88dvh', overflowY: 'auto', paddingBottom: 'calc(16px + env(safe-area-inset-bottom))' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-[14px] font-extrabold">Фильтры</h2>
          <button onClick={onClose} className="rounded-lg bg-white/6 p-2 text-slate-400"><X size={16} /></button>
        </div>

        <div className="space-y-3.5">
          {/* поиск */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Название</div>
            <input
              value={f.q}
              onChange={(e) => set('q', e.target.value)}
              placeholder="AK-47, Dragon Lore, Karambit…"
              className="input w-full px-3 py-2.5 text-[13px]"
            />
          </div>

          {/* категория */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Категория</div>
            <div className="flex flex-wrap gap-1.5">
              {ITEM_TYPES.filter((t) => t.id !== 'all').map((t) => (
                <button key={t.id} className={cn('chip', f.types.includes(t.id) && 'on')}
                  onClick={() => { audio.click(); set('types', toggle(f.types, t.id)); }}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* модель оружия */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Модель</div>
            <div className="flex flex-wrap gap-1.5">
              {WEAPON_CATS.filter((c) => c.id !== 'all').map((c) => (
                <button key={c.id} className={cn('chip', f.cats.includes(c.id) && 'on')}
                  onClick={() => { audio.click(); set('cats', toggle(f.cats, c.id)); }}>
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* цена */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Цена, ₽</div>
            <div className="flex items-center gap-2">
              <input type="number" min={0} inputMode="numeric" placeholder="от"
                value={f.min || ''} onChange={(e) => set('min', Math.max(0, Number(e.target.value) || 0))}
                className="input num w-full px-3 py-2.5 text-center text-[13px]" />
              <span className="text-slate-600">—</span>
              <input type="number" min={0} inputMode="numeric" placeholder="до"
                value={f.max || ''} onChange={(e) => set('max', Math.max(0, Number(e.target.value) || 0))}
                className="input num w-full px-3 py-2.5 text-center text-[13px]" />
            </div>
            <input
              type="range" min={0} max={500000} step={1000}
              value={f.max || 500000}
              onChange={(e) => set('max', Number(e.target.value) >= 500000 ? 0 : Number(e.target.value))}
              className="mt-2 w-full"
              style={{ '--p': `${((f.max || 500000) / 500000) * 100}%` } as React.CSSProperties}
            />
            <div className="chip-row mt-1.5">
              {[1000, 10000, 50000, 200000].map((v) => (
                <button key={v} className={cn('chip num', f.max === v && 'on')}
                  onClick={() => { audio.click(); set('max', v); }}>до {v.toLocaleString('ru-RU')}</button>
              ))}
            </div>
          </div>

          {/* редкость */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Редкость</div>
            <div className="flex flex-wrap gap-1.5">
              {RARITIES.map((r) => {
                const on = f.rarities.includes(r.api);
                return (
                  <button key={r.id} className={cn('chip', on && 'on')}
                    style={on ? { borderColor: r.color, color: r.color } : undefined}
                    onClick={() => { audio.click(); set('rarities', toggle(f.rarities, r.api)); }}>
                    <span className="mr-1 inline-block h-2 w-2 rounded-full" style={{ background: r.color }} />
                    {r.ru}
                  </button>
                );
              })}
            </div>
          </div>

          {/* износ */}
          <div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Состояние</div>
            <div className="flex flex-wrap gap-1.5">
              {WEARS.map((w) => (
                <button key={w.id} className={cn('chip', f.wears.includes(w.id) && 'on')}
                  onClick={() => { audio.click(); set('wears', toggle(f.wears, w.id)); }}>
                  {w.short}
                </button>
              ))}
            </div>
          </div>

          <Tri label="StatTrak™" k="stattrak" />
          <Tri label="Сувенирное" k="souvenir" />
        </div>

        {/* действия */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn btn-ghost py-3 text-[12.5px]"
            onClick={() => { audio.click(); setF(EMPTY_FILTERS); }}>
            <RotateCcw size={14} /> Сбросить
          </button>
          <button className="btn btn-gold py-3 text-[12.5px] font-extrabold"
            onClick={() => { audio.click(); saveFilters(f); onApply(f); onClose(); }}>
            <Check size={14} /> Применить
          </button>
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(body, document.body);
}
