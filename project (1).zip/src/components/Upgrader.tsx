import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Search, ChevronsUp, Package, Sparkles, SlidersHorizontal, X,
  Dices, MousePointerClick, Coins,
} from 'lucide-react';
import type { Skin } from '../lib/types';
import { useGame, useSkins } from '../lib/store';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import Wheel, { type WheelHandle } from './Wheel';
import WinsFeed from './WinsFeed';
import { SkinCard, SkinImage, SectionTitle, EmptyState, StarBadge, ConfettiBurst } from './ui';
import { cn } from '../utils/cn';

const MAX_CHANCE = 90;
/** максимум предметов в одной ставке */
const MAX_STAKE_ITEMS = 6;
/* phones render fewer cards per page — huge win on scroll/paint cost */
const PAGE = typeof window !== 'undefined' && window.innerWidth < 640 ? 24 : 60;

type Mode = 'auto' | 'manual';

const RARITY_FILTERS = [
  { id: 'all', label: 'Все' },
  { id: 'star', label: '★ Ножи' },
  { id: 'Covert', label: 'Тайное' },
  { id: 'Classified', label: 'Засекреч.' },
  { id: 'Restricted', label: 'Запрещ.' },
  { id: 'Mil-Spec Grade', label: 'Армейск.' },
];

const fmtMult = (m: number) => m.toFixed(2).replace(/\.?0+$/, '');

/* ---------------- auto skin matcher ---------------- */

function findMatch(skins: Skin[], value: number): Skin | null {
  if (skins.length === 0) return null;
  const tol = Math.max(8, value * 0.05);
  const pool = skins.filter((s) => Math.abs(s.price - value) <= tol);
  if (pool.length > 0) return pool[Math.floor(Math.random() * pool.length)];
  let best = skins[0];
  let bd = Infinity;
  for (const s of skins) {
    const d = Math.abs(s.price - value);
    if (d < bd) { bd = d; best = s; }
  }
  return best;
}

/* ---------------- reusable picker panel ---------------- */

export const PickerPanel = memo(function PickerPanel({
  title, icon, skins, selectedId, selectedIds, onPick, searchable = true, showFilters,
  emptyText, footerOf, wide, minPrice,
}: {
  title: string;
  icon: React.ReactNode;
  skins: Skin[];
  selectedId?: string | null;
  selectedIds?: string[];
  onPick?: (s: Skin) => void;
  searchable?: boolean;
  showFilters?: boolean;
  emptyText?: string;
  footerOf?: (s: Skin) => React.ReactNode;
  wide?: boolean;
  minPrice?: number;
}) {
  const [q, setQ] = useState('');
  const [rar, setRar] = useState('all');
  const [sort, setSort] = useState<'desc' | 'asc'>('desc');
  const [count, setCount] = useState(PAGE);

  const filtered = useMemo(() => {
    let arr = skins;
    if (minPrice) arr = arr.filter((x) => x.price > minPrice);
    if (q.trim()) {
      const s = q.trim().toLowerCase();
      arr = arr.filter((x) => x.name.toLowerCase().includes(s));
    }
    if (rar === 'star') arr = arr.filter((x) => x.star);
    else if (rar !== 'all') arr = arr.filter((x) => x.rarity === rar);
    arr = [...arr].sort((a, b) => (sort === 'desc' ? b.price - a.price : a.price - b.price));
    return arr;
  }, [skins, q, rar, sort, minPrice]);

  useEffect(() => setCount(PAGE), [q, rar, sort]);

  return (
    <div className="panel flex min-h-0 flex-1 flex-col p-3.5">
      <SectionTitle icon={icon} title={title}
        right={<span className="num rounded-md bg-white/5 px-1.5 py-0.5 text-[10.5px] font-bold text-slate-400">{filtered.length}</span>} />
      {searchable && (
        <div className="relative mb-2.5">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск по названию или цене..."
            className="input w-full py-2 pl-9 pr-8 text-[13px]"
          />
          {q && (
            <button onClick={() => setQ('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
              <X size={14} />
            </button>
          )}
        </div>
      )}
      {showFilters && (
        <div className="mb-2.5 flex flex-wrap items-center gap-1.5">
          {RARITY_FILTERS.map((f) => (
            <button key={f.id} className={cn('chip', rar === f.id && 'on')} onClick={() => { audio.click(); setRar(f.id); }}>
              {f.label}
            </button>
          ))}
          {minPrice && (
            <span className="num chip pointer-events-none border-gold/40 bg-gold/5 text-gold! text-[10px]">
              дороже {fmt(minPrice)}
            </span>
          )}
          <button
            className="chip ml-auto"
            onClick={() => { audio.click(); setSort((s) => (s === 'desc' ? 'asc' : 'desc')); }}
            title="Сортировка по цене"
          >
            <SlidersHorizontal size={12} className="mr-1" />
            {sort === 'desc' ? 'Сначала дорогие' : 'Сначала дешёвые'}
          </button>
        </div>
      )}
      <div className={cn(
        'grid gap-2 overflow-y-auto pr-1',
        wide
          ? 'max-h-[420px] grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:max-h-[600px] 2xl:grid-cols-5'
          : 'max-h-[340px] grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 xl:max-h-[400px]',
      )}>
        {filtered.slice(0, count).map((s) => (
          <SkinCard
            key={(s as Skin & { uid?: string }).uid ?? s.id}
            skin={s}
            compact
            selected={(() => {
              const key = (s as Skin & { uid?: string }).uid ?? s.name;
              return selectedIds ? selectedIds.includes(key) : selectedId === key;
            })()}
            onClick={onPick ? () => onPick(s) : undefined}
            badge={s.star ? <StarBadge /> : undefined}
            footer={footerOf?.(s)}
          />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full">
            <EmptyState icon={<Package size={26} />} text={emptyText ?? 'Ничего не найдено'} sub="Попробуйте изменить запрос" />
          </div>
        )}
      </div>
      {count < filtered.length && (
        <button className="btn btn-ghost mt-2.5 w-full py-2 text-xs" onClick={() => { audio.click(); setCount((c) => c + PAGE); }}>
          Показать ещё ({filtered.length - count})
        </button>
      )}
    </div>
  );
});

/* ---------------- stake / target panel ---------------- */

const ItemPanel = memo(function ItemPanel({ label, skin, onClear, tag, onReroll, hot, empty }: {
  label: string;
  skin?: Skin | null;
  onClear?: () => void;
  tag?: string;
  onReroll?: () => void;
  hot?: boolean;
  empty: string;
}) {
  const star = skin?.name.startsWith('★');
  const clean = skin?.name.replace('★ ', '') ?? '';
  const parts = clean.split(' | ');
  return (
    <div
      className={cn(
        'panel-inset relative flex min-h-[190px] flex-col items-center justify-center gap-1 p-3 text-center transition-all sm:min-h-[240px] xl:min-h-[270px]',
        hot && skin && 'border-rose-500/60',
      )}
      style={hot && skin ? { boxShadow: '0 0 28px -8px rgba(244,63,94,.4), inset 0 0 34px -20px rgba(244,63,94,.5)' } : undefined}
    >
      <span className="absolute left-3 top-2.5 text-[9.5px] font-bold uppercase tracking-[0.18em] text-slate-500">{label}</span>
      {tag && (
        <span className="absolute right-3 top-2.5 rounded-md bg-gold/12 px-1.5 py-0.5 text-[8.5px] font-extrabold uppercase tracking-wider text-gold ring-1 ring-gold/30">
          {tag}
        </span>
      )}
      {skin ? (
        <>
          <SkinImage key={skin.id} skin={skin} className="h-32 w-full pop-in" imgClassName="max-h-32" />
          <div className="w-full min-w-0 px-1">
            <div className="truncate text-[9px] font-bold uppercase tracking-wider text-slate-500">{parts[0]}</div>
            <div className="truncate text-[13px] font-extrabold leading-tight" style={{ color: skin.color }} title={skin.name}>
              {star && '★ '}{parts.slice(1).join(' | ') || parts[0]}
            </div>
            <div className="num price mt-0.5 text-[13px] font-extrabold">{fmt(skin.price)}</div>
          </div>
          <div className="absolute bottom-2 right-2 flex gap-1">
            {onReroll && (
              <button
                onClick={onReroll}
                title="Подобрать другой скин"
                className="rounded-md bg-white/8 p-1.5 text-gold transition-all hover:bg-gold/20"
              >
                <Dices size={13} />
              </button>
            )}
            {onClear && (
              <button onClick={onClear} className="rounded-md bg-white/8 p-1.5 text-slate-400 transition-colors hover:text-white">
                <X size={13} />
              </button>
            )}
          </div>
        </>
      ) : (
          <div className="flex flex-col items-center gap-2 px-3 py-4">
          <div className="grid h-12 w-12 place-items-center rounded-xl border border-dashed border-slate-600/60 text-slate-600">
            <Package size={20} />
          </div>
          <div className="max-w-[200px] text-[11px] leading-snug text-slate-500">{empty}</div>
        </div>
      )}
    </div>
  );
});

/** Панель ставки: до 6 предметов с суммарной стоимостью */
const StakePanel = memo(function StakePanel({
  items, total, spinning, onRemove, onClear,
}: {
  items: Array<Skin & { uid: string }>;
  total: number;
  spinning: boolean;
  onRemove: (uid: string) => void;
  onClear: () => void;
}) {
  const slots = Array.from({ length: MAX_STAKE_ITEMS }, (_, i) => items[i]);
  return (
    <div className="panel-inset relative flex min-h-[190px] flex-col p-2.5 sm:min-h-[240px] xl:min-h-[270px]">
      <div className="mb-1.5 flex items-center gap-1.5">
        <span className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-slate-500">
          Ваша ставка
        </span>
        <span className="num rounded bg-white/6 px-1.5 text-[9.5px] font-bold text-slate-400">
          {items.length}/{MAX_STAKE_ITEMS}
        </span>
        {items.length > 0 && !spinning && (
          <button onClick={onClear} className="ml-auto rounded-md bg-white/6 p-1 text-slate-400">
            <X size={12} />
          </button>
        )}
      </div>

      <div className="grid flex-1 grid-cols-3 gap-1.5">
        {slots.map((s, i) => (
          <div
            key={s?.uid ?? `empty-${i}`}
            onClick={() => s && !spinning && onRemove(s.uid)}
            className="relative grid place-items-center rounded-lg border p-1"
            style={{
              minHeight: 58,
              borderColor: s ? `${s.color}66` : 'rgba(148,163,216,.18)',
              borderStyle: s ? 'solid' : 'dashed',
              background: s ? `${s.color}12` : 'transparent',
            }}
          >
            {s ? (
              <>
                <SkinImage skin={s} className="h-[34px] w-full" />
                <span className="num price w-full truncate text-center text-[8.5px] font-extrabold">
                  {fmt(s.price)}
                </span>
              </>
            ) : (
              <Package size={14} className="text-slate-700" />
            )}
          </div>
        ))}
      </div>

      <div className="mt-1.5 flex items-center justify-between border-t border-white/8 pt-1.5">
        <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">Итого</span>
        <span className="num price text-[13px] font-extrabold">{fmt(total)}</span>
      </div>
    </div>
  );
});

/* ---------------- main page ---------------- */

interface Pending {
  items: Skin[];
  target: Skin;
  stake: number;
  chance: number;
}

export default function Upgrader() {
  const { state, addItem, removeItem, log, addStats, toast } = useGame();
  /* catalog = оружие + наклейки + брелоки + кейсы и прочее,
     поэтому апгрейдить можно во всё, что есть на рынке */
  const { catalog, byName } = useSkins();
  const skins = catalog;

  const inv = useMemo(
    () => state.inventory.map((i) => {
      const live = byName.get(i.name);
      return live ? { ...i, ...live, uid: i.uid } : i;
    }),
    [state.inventory, byName],
  );

  const [selUids, setSelUids] = useState<string[]>([]);
  const [mode, setMode] = useState<Mode>('auto');
  const [mult, setMult] = useState(2);
  const [manualTarget, setManualTarget] = useState<Skin | null>(null);
  const [rollSeed, setRollSeed] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [flash, setFlash] = useState<'win' | 'lose' | null>(null);
  const [burstKey, setBurstKey] = useState(0);
  const [lockedChance, setLockedChance] = useState<number | null>(null);

  const wheelRef = useRef<WheelHandle>(null);
  const pendingRef = useRef<Pending | null>(null);
  const flashTimer = useRef<number>(0);

  /* выбранные предметы с актуальными ценами из базы */
  const picked = useMemo(
    () => selUids
      .map((uid) => inv.find((i) => i.uid === uid))
      .filter((x): x is typeof inv[number] => !!x),
    [selUids, inv],
  );
  const stakeTotal = useMemo(() => picked.reduce((a, s2) => a + s2.price, 0), [picked]);
  /* «виртуальный предмет» ставки — чтобы вся математика осталась прежней */
  const item = picked.length
    ? { ...picked[0], price: stakeTotal, name: picked.length > 1
        ? `${picked.length} предмета` : picked[0].name }
    : null;

  const fast = state.settings.fast;
  const duration = fast ? 2400 : 4600;

  /* highest multiplier the skin database can actually deliver for this item */
  const maxSkinPrice = useMemo(
    () => skins.reduce((m, s) => (s.price > m ? s.price : m), 0),
    [skins],
  );
  const maxMult = item ? Math.max(1.02, maxSkinPrice / item.price) : 500;
  /* clamp so the shown chance always matches a real, findable target */
  const effAuto = Math.min(mult, maxMult);

  /* auto-picked skin for the chosen multiplier */
  const autoTarget = useMemo(() => {
    if (!item) return null;
    return findMatch(skins, item.price * effAuto);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stakeTotal, skins, effAuto, rollSeed]);

  const target = mode === 'auto' ? autoTarget : manualTarget;

  /* chance always derives from the real target price, so x2 = 50% and
     re-rolling a slightly pricier skin can never inflate the odds */
  const chance = useMemo(() => {
    if (!item || !target) return 0;
    return Math.min(MAX_CHANCE, (item.price / Math.max(1, target.price)) * 100);
  }, [item, target]);

  const ready = !!item && !!target && !spinning;

  /* chance stays frozen while the wheel spins — the green zone must not collapse */
  const shownChance = lockedChance ?? chance;

  const doUpgrade = () => {
    if (!ready || !item || !target) return;
    audio.click();
    const stake = stakeTotal;
    /* the wheel itself rolls the outcome against this exact chance, draws the
       zone from it and lands the pointer to match — then reports via onEnd */
    pendingRef.current = { items: picked.map((x) => ({ ...x })), target, stake, chance };
    /* a pending flash timer from the previous round must not unlock this one */
    window.clearTimeout(flashTimer.current);
    setLockedChance(chance);
    for (const it of picked) removeItem(it.uid);
    setSelUids([]);
    setSpinning(true);
    setFlash(null);
    wheelRef.current?.spin(chance);
  };

  const onWheelEnd = (win: boolean) => {
    const p = pendingRef.current;
    setSpinning(false);
    setFlash(win ? 'win' : 'lose');
    if (win) setBurstKey((k) => k + 1);
    window.clearTimeout(flashTimer.current);
    flashTimer.current = window.setTimeout(() => { setFlash(null); setLockedChance(null); }, 1900);
    if (!p) return;

    if (win) {
      if (p.target.price >= p.stake * 10) audio.bigWin(); else audio.win();
      addItem(p.target);
      toast('Апгрейд успешен!', 'win', `Вы получили: ${p.target.name}`);
      addStats({ upgrades: 1, upgradeWins: 1, wagered: p.stake, bestWin: Math.max(0, p.target.price - state.stats.bestWin) });
      const names = p.items.length > 1 ? `${p.items.length} предм.` : p.items[0]?.name ?? '';
      log({ kind: 'upgrade', text: `Апгрейд: ${names} → ${p.target.name}`, amount: p.target.price, success: true });
    } else {
      audio.lose();
      addStats({ upgrades: 1, wagered: p.stake });
      const lost = p.items.length > 1 ? `${p.items.length} предм.` : p.items[0]?.name ?? '';
      log({ kind: 'upgrade', text: `Провал: ${lost} (${p.chance.toFixed(1)}%)`, amount: -p.stake, success: false });
      toast('Апгрейд не удался', 'lose', `${lost} · шанс был ${p.chance.toFixed(1)}%`);
    }
  };

  const setPercent = (p: number) => {
    setMode('auto');
    setMult(Math.min(500, Math.max(1.02, 100 / Math.min(MAX_CHANCE, Math.max(1, p)))));
  };
  const setMultChip = (m: number) => {
    audio.click();
    setPercent(100 / m);
  };
  /* stable identities so the memoized pickers don't re-render on every tick */
  const pickManual = useCallback((s: Skin) => {
    setMode('manual');
    setManualTarget(s);
  }, []);

  const pickOwn = useCallback((s: Skin) => {
    const uid = (s as Skin & { uid?: string }).uid;
    if (!uid) return;
    setSelUids((cur) => {
      if (cur.includes(uid)) return cur.filter((x) => x !== uid);
      if (cur.length >= MAX_STAKE_ITEMS) return cur;   // не больше 6
      return [...cur, uid];
    });
  }, []);

  const chanceStr = shownChance >= 10 ? shownChance.toFixed(1) : shownChance.toFixed(2);
  const effMult = mode === 'auto' ? effAuto : (item && target ? target.price / item.price : 0);
  const tier = shownChance <= 0 ? '' : shownChance < 35 ? 'низкий шанс' : shownChance < 70 ? 'средний шанс' : 'высокий шанс';
  const tierCls = shownChance < 35 ? 'text-rose-400' : shownChance < 70 ? 'text-amber-300' : 'text-emerald-400';

  return (
    <div className="fade-up grid items-start gap-4 2xl:grid-cols-[244px_minmax(0,1fr)]">
      {/* live wins feed */}
      <div className="hidden 2xl:block">
        <WinsFeed />
      </div>

      <div className="min-w-0">
        {/* ---------- game zone ---------- */}
        <div className="panel relative overflow-hidden p-4 sm:p-5">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-gold/4 to-transparent" />

          <div className="relative grid items-stretch gap-3 xl:grid-cols-[280px_minmax(0,1fr)_280px]">
            {/* stake */}
            <div className="order-1">
              <StakePanel
                items={picked}
                total={stakeTotal}
                spinning={spinning}
                onRemove={(uid) => setSelUids((c) => c.filter((x) => x !== uid))}
                onClear={() => setSelUids([])}
              />
            </div>

            {/* gauge */}
            <div className="order-2 xl:order-2">
              <div
                className={cn(
                  'relative mx-auto w-full max-w-[400px] rounded-full',
                  flash === 'win' && 'flash-win',
                  flash === 'lose' && 'flash-lose',
                )}
              >
                <Wheel ref={wheelRef} chance={shownChance} duration={duration} onEnd={onWheelEnd} />
                {flash === 'win' && <ConfettiBurst key={burstKey} />}
                {/* gauge labels */}
                <span className="pointer-events-none absolute left-1/2 top-[10%] -translate-x-1/2 text-[10px] font-bold text-slate-500">100%</span>
                <span className="pointer-events-none absolute left-[6%] top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-500">50%</span>
                <span className="pointer-events-none absolute right-[6%] top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-500">50%</span>
                {/* center */}
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                  <div
                    className={cn(
                      'font-display num text-[36px] font-extrabold leading-none sm:text-[44px]',
                      shownChance > 0 ? 'text-[#7fe33f] text-glow-green' : 'text-slate-600',
                      spinning && 'pulse-soft',
                    )}
                    style={shownChance > 0 ? undefined : { textShadow: 'none' }}
                  >
                    {shownChance > 0 ? `${chanceStr}%` : '—'}
                  </div>
                  {tier && !spinning && (
                    <div className={cn('mt-1.5 text-[9.5px] font-bold uppercase tracking-[0.24em]', tierCls)}>{tier}</div>
                  )}
                  {spinning && (
                    <div className="mt-1.5 text-[9.5px] font-bold uppercase tracking-[0.24em] text-gold pulse-soft">прокачка…</div>
                  )}
                </div>
              </div>
            </div>

            {/* target */}
            <div className="order-3">
              <ItemPanel
                label="Цель"
                skin={target}
                hot={mode === 'manual'}
                tag={mode === 'auto' && target ? `авто x${fmtMult(effAuto)}` : target ? 'ваш выбор' : undefined}
                onReroll={mode === 'auto' && target && !spinning ? () => { audio.click(); setRollSeed((s) => s + 1); } : undefined}
                onClear={mode === 'manual' && manualTarget && !spinning ? () => { audio.click(); setManualTarget(null); setMode('auto'); } : undefined}
                empty="Скин подберётся автоматически под кэф — или выберите его в списке справа"
              />
            </div>
          </div>

          {/* chance slider */}
          <div className="mx-auto mt-4 max-w-[560px]">
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-500">Шанс</span>
              <input
                type="range"
                min={1}
                max={90}
                step={1}
                value={Math.round(shownChance || 1)}
                disabled={spinning}
                onChange={(e) => { setPercent(Number(e.target.value)); }}
                className="flex-1"
                style={{ '--p': `${(Math.round(shownChance || 1) / 90) * 100}%` } as React.CSSProperties}
              />
              <span className="num min-w-[52px] rounded-lg bg-gold/10 px-2 py-1 text-center text-[12px] font-extrabold text-gold ring-1 ring-gold/30">
                {shownChance > 0 ? `${chanceStr}%` : '—'}
              </span>
            </div>
          </div>

          {/* main action */}
          <button
            onClick={doUpgrade}
            disabled={!ready}
            className="btn btn-gold btn-shine mx-auto mt-3 flex w-full max-w-[560px] py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]"
          >
            <ChevronsUp size={18} strokeWidth={2.8} />
            {spinning
              ? 'Прокачиваем…'
              : !item
                ? 'Выберите предметы'
                : !target
                  ? 'Выберите цель'
                  : picked.length > 1 ? `Прокачать ${picked.length} предм.` : 'Прокачать'}
          </button>

          {/* quick coefficients / percents — scrolls horizontally on phones */}
          <div className="chip-row mx-auto mt-3 max-w-[560px] sm:flex-wrap sm:justify-center">
            {[2, 4, 8].map((m) => (
              <button key={m} className={cn('chip', mode === 'auto' && Math.abs(effAuto - m) < 0.01 && 'on')} onClick={() => setMultChip(m)}>
                x{m}
              </button>
            ))}
            <span className="mx-1 h-5 w-px shrink-0 self-center bg-white/10" />
            {[1, 10, 25, 50, 75, 90].map((p) => (
              <button
                key={p}
                className={cn('chip', mode === 'auto' && Math.abs(shownChance - p) < 0.6 && 'on')}
                onClick={() => { audio.click(); setPercent(p); }}
              >
                {p}%
              </button>
            ))}
          </div>

          {/* equation */}
          <div className="mt-3 flex items-center justify-center gap-2 text-[11px] font-bold text-slate-500">
            <Coins size={12} className="text-gold" />
            {item && target ? (
              <span className="num">
                {fmt(item.price)} <span className="text-slate-600">×</span> x{fmtMult(effMult)} <span className="text-slate-600">≈</span> <span className="price">{fmt(target.price)}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5"><MousePointerClick size={12} className="text-gold" /> Выберите до 6 предметов из «Мои скины» — цель подберётся сама</span>
            )}
          </div>

          {state.history.some((h) => h.kind === 'upgrade') && (
            <div className="mt-3 flex items-center justify-center gap-1.5">
              <span className="mr-1 text-[9px] font-bold uppercase tracking-[0.22em] text-slate-600">недавние</span>
              {state.history.filter((h) => h.kind === 'upgrade').slice(0, 12).map((h) => (
                <span
                  key={h.id}
                  title={h.text}
                  className={cn('h-2.5 w-2.5 rounded-full', h.success ? 'bg-emerald-400 shadow-[0_0_8px_rgba(34,197,94,.8)]' : 'bg-rose-500/70')}
                />
              ))}
            </div>
          )}
        </div>

        {/* ---------- lists ---------- */}
        <div className="mt-4 grid items-start gap-4 xl:grid-cols-2">
          <PickerPanel
            title={`Мои скины · ${inv.length}`}
            icon={<Package size={15} className="text-gold" />}
            skins={inv}
            selectedIds={selUids}
            onPick={pickOwn}
            emptyText="Инвентарь пуст"
            showFilters
          />
          <PickerPanel
            title="Выберите скин"
            icon={<Sparkles size={15} className="text-gold" />}
            skins={skins}
            selectedId={mode === 'manual' ? manualTarget?.name : null}
            onPick={pickManual}
            showFilters
            minPrice={item ? item.price : undefined}
            emptyText="Нет скинов дороже ставки"
          />
        </div>
      </div>
    </div>
  );
}
