import { useState } from 'react';
import { createPortal } from 'react-dom';
import { Ticket, Gift } from 'lucide-react';
import { useGame } from '../lib/store';
import { redeem } from '../lib/promo';
import { fmt } from '../lib/skins';
import { SectionTitle } from './ui';
import { audio } from '../lib/audio';

/** Поле ввода промокодов в магазине */
export default function PromoBox() {
  const { adjust, log, toast } = useGame();
  const [code, setCode] = useState('');
  const [banner, setBanner] = useState<string | null>(null);

  const apply = () => {
    const res = redeem(code);
    if (!res.ok) {
      audio.lose();
      toast(res.title, 'lose');
      return;
    }
    adjust(res.amount);
    log({
      kind: 'bonus',
      text: `Промокод ${code.trim().toUpperCase()}`,
      amount: res.amount,
      success: true,
    });
    audio.coin();
    toast(res.title, 'win', `+${fmt(res.amount)}`);
    if (res.banner) setBanner(res.banner);
    setCode('');
  };

  return (
    <>
      <div className="panel p-5">
        <SectionTitle icon={<Ticket size={15} className="text-gold" />} title="Промокод" />
        <div className="flex gap-2">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            onKeyDown={(e) => { if (e.key === 'Enter') apply(); }}
            placeholder="ВВЕДИТЕ КОД"
            className="input flex-1 px-3 py-3 text-[13px] font-bold uppercase tracking-wider"
          />
          <button
            onClick={apply}
            disabled={!code.trim()}
            className="btn btn-gold px-5 text-[12.5px] font-extrabold uppercase"
          >
            <Gift size={15} /> Ввести
          </button>
        </div>
        <p className="mt-2 text-[10px] text-slate-600">
          Каждый код можно активировать один раз на устройстве.
        </p>
      </div>

      {banner && createPortal(
        <div
          onClick={() => setBanner(null)}
          className="fixed inset-0 z-[96] grid place-items-center bg-black/85 p-6"
          style={{ minHeight: '100dvh' }}
        >
          <div className="pop-in text-center">
            <div
              className="font-display text-[34px] font-black uppercase leading-tight"
              style={{
                color: '#ffd964',
                textShadow: '0 3px 0 #7a3a00, 0 0 24px rgba(255,214,64,.7)',
              }}
            >
              {banner}
            </div>
            <div className="mt-4 text-[11px] font-bold uppercase tracking-wider text-white/45">
              нажмите, чтобы закрыть
            </div>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
