import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Crosshair, CheckCircle2, XCircle, Info, Check, Star } from 'lucide-react';
import type { Skin, Toast } from '../lib/types';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';

/* ---------------- Skin image with graceful fallback ---------------- */

export const SkinImage = React.memo(function SkinImage({ skin, className, imgClassName }: { skin: Skin; className?: string; imgClassName?: string }) {
  const [err, setErr] = useState(false);
  if (!skin.image || err) {
    return (
      <div
        className={cn('flex items-center justify-center', className)}
        style={{ background: `radial-gradient(80% 80% at 50% 60%, ${skin.color}22, transparent 70%)` }}
      >
        <div className="flex flex-col items-center gap-1 px-1">
          <Crosshair size={26} style={{ color: skin.color }} className="opacity-70" />
          <span className="text-[9px] font-bold uppercase tracking-wide text-center leading-tight" style={{ color: skin.color }}>
            {skin.weapon || skin.name.split(' | ')[0]}
          </span>
        </div>
      </div>
    );
  }
  return (
    <div className={cn('flex items-center justify-center', className)}>
      <img
        src={skin.image}
        alt=""
        loading="lazy"
        decoding="async"
        /* фиксируем пропорции, чтобы не было пересчёта раскладки при загрузке */
        width={96}
        height={72}
        referrerPolicy="no-referrer"
        draggable={false}
        onError={() => setErr(true)}
        className={cn('max-h-full max-w-full object-contain', imgClassName)}
        style={{ contentVisibility: 'auto' }}
      />
    </div>
  );
});

/* ---------------- Skin card ---------------- */

export const SkinCard = React.memo(function SkinCard({
  skin, selected, onClick, compact, footer, badge,
}: {
  skin: Skin;
  selected?: boolean;
  onClick?: () => void;
  compact?: boolean;
  footer?: React.ReactNode;
  badge?: React.ReactNode;
}) {
  const star = skin.name.startsWith('★');
  const clean = skin.name.replace('★ ', '');
  const parts = clean.split(' | ');
  const weapon = parts[0];
  const pattern = parts.slice(1).join(' | ');
  return (
    <div
      className={cn('skin-card p-2', selected && 'sel')}
      
      style={{ '--rc': skin.color } as React.CSSProperties}
      onClick={() => { audio.click(); onClick?.(); }}
    >
      {badge}
      {selected && (
        <span className="absolute right-1.5 top-1.5 z-10 grid h-5 w-5 place-items-center rounded-full bg-emerald-500 shadow-[0_0_12px_rgba(34,197,94,.9)]">
          <Check size={12} strokeWidth={3.2} className="text-white" />
        </span>
      )}
      <SkinImage skin={skin} className={cn('w-full', compact ? 'h-16' : 'h-20 sm:h-24')} />
      <div className="mt-1.5 min-w-0 relative z-10">
        <div className="truncate text-[9px] font-bold uppercase tracking-wider text-slate-500" title={skin.name}>
          {weapon}
        </div>
        <div className="truncate text-[11.5px] font-bold leading-tight" style={{ color: skin.color }} title={skin.name}>
          {star && '★ '}{pattern || weapon}
        </div>
        <div className="mt-0.5 flex items-center justify-between gap-1">
          <span className="num price text-[11.5px] font-extrabold">{fmt(skin.price)}</span>
          {footer}
        </div>
      </div>
    </div>
  );
});

/* ---------------- Stars for knives/gloves ---------------- */

export function StarBadge() {
  return (
    <div className="absolute left-1.5 top-1.5 z-10 rounded-md bg-amber-400/90 px-1 py-0.5 shadow-[0_0_12px_rgba(251,191,36,.6)]">
      <Star size={11} className="text-amber-950" fill="currentColor" />
    </div>
  );
}

/* ---------------- Animated money ---------------- */

export function AnimatedMoney({ value, className }: { value: number; className?: string }) {
  const [shown, setShown] = useState(value);
  const raf = useRef(0);
  useEffect(() => {
    const from = shown;
    const to = value;
    if (from === to) return;
    const t0 = performance.now();
    const dur = Math.min(900, 260 + Math.abs(to - from) / 6);
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 3);
      setShown(Math.round(from + (to - from) * e));
      if (p < 1) raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return <span className={cn('num', className)}>{fmt(shown)}</span>;
}

/* ---------------- Toasts ---------------- */

export function Toasts({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="pointer-events-none fixed right-3 top-3 z-[90] flex w-[300px] max-w-[calc(100vw-24px)] flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            'toast-in panel flex items-start gap-2.5 px-3.5 py-3',
            t.type === 'win' && 'border-emerald-400/40',
            t.type === 'lose' && 'border-rose-400/40',
          )}
        >
          {t.type === 'win' && <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-emerald-400" />}
          {t.type === 'lose' && <XCircle size={18} className="mt-0.5 shrink-0 text-rose-400" />}
          {t.type === 'info' && <Info size={18} className="mt-0.5 shrink-0 text-sky-400" />}
          <div className="min-w-0">
            <div className="text-[13px] font-bold leading-tight">{t.text}</div>
            {t.sub && <div className="mt-0.5 truncate text-[11.5px] text-slate-400">{t.sub}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Confetti burst ---------------- */

const CONF_COLORS = ['#22c55e', '#4ade80', '#fbbf24', '#60a5fa', '#f472b6', '#a78bfa'];

export function ConfettiBurst() {
  const pieces = useMemo(
    () => Array.from({ length: 30 }, (_, i) => {
      const a = (i / 30) * Math.PI * 2 + Math.random() * 0.6;
      const d = 100 + Math.random() * 140;
      return {
        '--dx': `${Math.cos(a) * d}px`,
        '--dy': `${Math.sin(a) * d}px`,
        '--rot': `${Math.random() * 720 - 360}deg`,
        '--c': CONF_COLORS[i % CONF_COLORS.length],
        '--s': `${4 + Math.random() * 5}px`,
        '--t': `${0.75 + Math.random() * 0.55}s`,
      } as React.CSSProperties;
    }),
    [],
  );
  return (
    <>
      {pieces.map((st, i) => <span key={i} className="confetti" style={st} />)}
    </>
  );
}

/* ---------------- Section title ---------------- */

export function SectionTitle({ icon, title, right }: { icon?: React.ReactNode; title: string; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        {icon}
        <h2 className="font-display text-[13px] font-bold uppercase tracking-[0.14em] text-slate-200">{title}</h2>
      </div>
      {right}
    </div>
  );
}

/* ---------------- Empty state ---------------- */

export function EmptyState({ icon, text, sub, action }: { icon: React.ReactNode; text: string; sub?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
      <div className="rounded-2xl border border-dashed border-slate-600/60 p-4 text-slate-500">{icon}</div>
      <div className="text-sm font-bold text-slate-300">{text}</div>
      {sub && <div className="max-w-[240px] text-xs text-slate-500">{sub}</div>}
      {action}
    </div>
  );
}
