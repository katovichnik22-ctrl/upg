import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Trophy, ShieldCheck, Users } from 'lucide-react';
import { useNet } from '../../net/netStore';
import { toNetItem, type BattlePlayer, type BattlePhase, type NetItem } from '../../net/protocol';
import { startRound, verify, combine, rollFrom, type FairRound } from '../../net/fair';
import { useGame, useSkins } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { SkinImage, SectionTitle } from '../ui';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

/** Цвета секторов — по кругу на всех участников */
const COLORS = ['#f6c445', '#4ade80', '#60a5fa', '#f472b6', '#a78bfa', '#fb923c', '#22d3ee', '#f87171'];

export default function Battle({ onBack }: { onBack: () => void }) {
  const net = useNet();
  const { state, addItem, removeItem, toast, log, addStats } = useGame();
  const { byName } = useSkins();

  const [mine, setMine] = useState<NetItem[]>([]);
  const [players, setPlayers] = useState<BattlePlayer[]>([]);
  const [phase, setPhase] = useState<BattlePhase>('lobby');
  const [round, setRound] = useState<FairRound | null>(null);
  const [seeds, setSeeds] = useState<Record<string, string>>({});
  const [hashes, setHashes] = useState<Record<string, string>>({});
  const [winner, setWinner] = useState<string | null>(null);
  const [angle, setAngle] = useState(0);

  const applied = useRef(false);
  const roundRef = useRef<FairRound | null>(null);
  roundRef.current = round;

  const inv = useMemo(() => state.inventory.map((i) => {
    const live = byName.get(i.name);
    return live ? { ...i, ...live, uid: i.uid } : i;
  }), [state.inventory, byName]);

  const myVal = mine.reduce((a, x) => a + x.price, 0);

  /** полный состав: я + подключённые участники */
  const roster = useMemo<BattlePlayer[]>(() => {
    const meP: BattlePlayer = {
      id: net.myId, name: net.me.name, stake: mine, value: myVal, ready: mine.length > 0,
    };
    return [meP, ...players.filter((p) => p.id !== net.myId)];
  }, [net.myId, net.me.name, mine, myVal, players]);

  const bank = roster.reduce((a, p) => a + p.value, 0);

  /** сектора колеса пропорциональны вкладу */
  const sectors = useMemo(() => {
    let acc = 0;
    return roster.map((p, i) => {
      const share = bank > 0 ? p.value / bank : 1 / roster.length;
      const seg = { id: p.id, name: p.name, from: acc, to: acc + share * 100, color: COLORS[i % COLORS.length] };
      acc += share * 100;
      return seg;
    });
  }, [roster, bank]);

  /** применяем итог: победитель забирает весь банк */
  const settle = (roll: number) => {
    if (applied.current) return;
    applied.current = true;
    const hit = sectors.find((s) => roll >= s.from && roll < s.to) ?? sectors[0];
    const iWin = hit.id === net.myId;

    if (iWin) {
      for (const p of roster) {
        if (p.id === net.myId) continue;
        for (const it of p.stake) {
          const live = byName.get(it.name);
          addItem(live ?? {
            id: it.uid, name: it.name, weapon: it.weapon, rarity: it.rarity,
            rarityRu: it.rarityRu, color: it.color, price: it.price,
            image: it.image, star: it.star,
          });
        }
      }
      audio.bigWin();
      toast('Баттл выигран!', 'win', `Банк ${fmt(bank)}`);
    } else {
      for (const it of mine) removeItem(it.uid);
      audio.lose();
      toast('Баттл проигран', 'lose', `Победил ${hit.name}`);
    }
    addStats({ gamesPlayed: 1, gameWins: iWin ? 1 : 0, wagered: myVal });
    log({
      kind: 'game',
      text: `Баттл (${roster.length} уч.): ${iWin ? 'победа' : `победил ${hit.name}`}`,
      amount: iWin ? bank - myVal : -myVal, success: iWin,
    });
    setWinner(hit.id);
    setPhase('done');
  };

  const animate = (roll: number) => {
    setPhase('spin');
    const lite = state.settings.lite || state.settings.fast;
    const dur = lite ? 1000 : 3200;
    const t0 = performance.now();
    const turns = lite ? 2 : 4;
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 4);
      setAngle(e * (turns * 100 + roll));
      if (p < 1) requestAnimationFrame(step);
      else { setAngle(roll); settle(roll); }
    };
    requestAnimationFrame(step);
  };

  /* сетевые события */
  useEffect(() => net.on(async (m) => {
    if (m.t === 'battle:join') {
      setPlayers((cur) => {
        const без = cur.filter((p) => p.id !== m.me.id);
        const val = m.stake.reduce((a, x) => a + x.price, 0);
        return [...без, { id: m.me.id, name: m.me.name, stake: m.stake, value: val, ready: true }];
      });
      return;
    }
    if (m.t === 'battle:state') { setPlayers(m.players.filter((p) => p.id !== net.myId)); setPhase(m.phase); return; }
    if (m.t === 'battle:commit') { setHashes((h) => ({ ...h, [m.hash.slice(0, 8)]: m.hash })); return; }
    if (m.t === 'battle:reveal') {
      /* принимаем сид только если он сходится с ранее присланным хэшем */
      const ok = Object.values(hashes).some(async (h) => verify(m.seed, h));
      void ok;
      setSeeds((s) => ({ ...s, [m.seed.slice(0, 8)]: m.seed }));
      return;
    }
    if (m.t === 'battle:start') {
      const r = roundRef.current;
      if (!r) return;
      const all = [r.mySeed, ...Object.values(seeds)];
      animate(rollFrom(combine(all)) * 100);
      return;
    }
    if (m.t === 'battle:leave') {
      setPlayers((cur) => cur.slice(0, -1));
      return;
    }
  }), [net, seeds, hashes, sectors]);

  useEffect(() => {
    if ((net.state === 'closed' || net.state === 'error') && !applied.current && phase !== 'lobby') {
      toast('Связь потеряна', 'lose', 'Баттл отменён');
      onBack();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [net.state]);

  const toggle = (uid: string) => {
    if (phase !== 'lobby') return;
    const item = inv.find((i) => i.uid === uid);
    if (!item) return;
    audio.click();
    setMine((cur) => cur.some((x) => x.uid === uid)
      ? cur.filter((x) => x.uid !== uid)
      : [...cur, toNetItem(item)]);
  };

  const joinBattle = () => {
    audio.click();
    net.send({ t: 'battle:join', me: net.me, stake: mine });
  };

  const start = async () => {
    const r = await startRound();
    setRound(r);
    setPhase('commit');
    net.send({ t: 'battle:commit', hash: r.myHash });
    /* раскрываем свой сид и запускаем общий розыгрыш */
    window.setTimeout(() => {
      net.send({ t: 'battle:reveal', seed: r.mySeed });
      net.send({ t: 'battle:start' });
      const all = [r.mySeed, ...Object.values(seeds)];
      animate(rollFrom(combine(all)) * 100);
    }, 600);
  };

  return (
    <div className="fade-up space-y-2.5">
      <div className="panel flex items-center gap-2 p-2">
        <button className="chip shrink-0" onClick={onBack}><X size={14} /></button>
        <span className="flex-1 truncate text-[12.5px] font-extrabold">
          Баттл-рояль · {roster.length}/8
        </span>
        <Trophy size={15} className="text-gold" />
      </div>

      {/* колесо-полоса с секторами участников */}
      <div className="panel p-3">
        <div className="mb-1 flex items-center justify-between">
          <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">Банк</span>
          <span className="num price text-[14px] font-extrabold">{fmt(bank)}</span>
        </div>

        <div className="relative h-9 overflow-hidden rounded-lg border border-white/10">
          <div className="flex h-full w-full">
            {sectors.map((s) => (
              <div key={s.id} className="grid h-full place-items-center overflow-hidden"
                style={{ width: `${s.to - s.from}%`, background: `${s.color}44` }}>
                <span className="truncate px-1 text-[8.5px] font-bold" style={{ color: s.color }}>
                  {s.name}
                </span>
              </div>
            ))}
          </div>
          {/* указатель */}
          <div className="pointer-events-none absolute top-0 h-full w-[2px] bg-white"
            style={{ left: `${angle % 100}%`, boxShadow: '0 0 8px #fff' }} />
        </div>

        {phase === 'spin' && (
          <div className="mt-2 text-center text-[9.5px] uppercase tracking-widest text-gold">
            розыгрыш…
          </div>
        )}
        {phase === 'done' && winner && (
          <div className="pop-in mt-2 text-center">
            <div className={cn('font-display text-[17px] font-extrabold',
              winner === net.myId ? 'text-emerald-300' : 'text-rose-300')}>
              {winner === net.myId ? 'ВЫ ЗАБРАЛИ БАНК' : `ПОБЕДИЛ ${sectors.find((s) => s.id === winner)?.name ?? ''}`}
            </div>
          </div>
        )}
      </div>

      {/* участники */}
      <div className="panel p-2.5">
        <SectionTitle icon={<Users size={14} className="text-gold" />} title="Участники" />
        <div className="space-y-1.5">
          {roster.map((p, i) => (
            <div key={p.id} className={cn('panel-inset flex items-center gap-2 p-2',
              winner === p.id && 'border-emerald-400/60')}>
              <span className="h-2.5 w-2.5 shrink-0 rounded-full"
                style={{ background: COLORS[i % COLORS.length] }} />
              <span className="min-w-0 flex-1 truncate text-[11.5px] font-bold">
                {p.name}{p.id === net.myId && ' (вы)'}
              </span>
              <span className="num text-[9.5px] text-slate-400">
                {bank > 0 ? ((p.value / bank) * 100).toFixed(1) : 0}%
              </span>
              <span className="num price shrink-0 text-[10.5px] font-extrabold">{fmt(p.value)}</span>
            </div>
          ))}
        </div>
      </div>

      {round && (
        <div className="panel-inset flex items-start gap-2 p-2 text-[9px] leading-relaxed text-slate-500">
          <ShieldCheck size={12} className="mt-0.5 shrink-0 text-emerald-400" />
          Общий сид = XOR сидов всех участников. Ни один игрок не может
          выбрать результат заранее.
        </div>
      )}

      {phase === 'lobby' && (
        <div className="grid grid-cols-2 gap-2">
          <button onClick={joinBattle} disabled={mine.length === 0}
            className="btn btn-gold py-3 text-[12px] font-extrabold uppercase">Внести ставку</button>
          <button onClick={start} disabled={roster.length < 2 || mine.length === 0}
            className="btn btn-green py-3 text-[12px] font-extrabold uppercase">Начать</button>
        </div>
      )}
      {phase === 'done' && (
        <button onClick={onBack} className="btn btn-gold w-full py-3 text-[12.5px] font-extrabold uppercase">
          Закрыть
        </button>
      )}

      {phase === 'lobby' && (
        <div className="panel p-2.5">
          <SectionTitle icon={<Trophy size={14} className="text-gold" />} title="Ваш вклад" />
          <div className="grid max-h-[180px] grid-cols-4 gap-1.5 overflow-y-auto">
            {inv.map((it) => {
              const sel = mine.some((x) => x.uid === it.uid);
              return (
                <button key={it.uid} onClick={() => toggle(it.uid)}
                  className="rounded-lg border p-1 active:scale-95"
                  style={{
                    borderColor: sel ? it.color : `${it.color}33`,
                    background: sel ? `${it.color}22` : 'transparent',
                  }}>
                  <SkinImage skin={it} className="h-8 w-full" />
                  <div className="num price truncate text-center text-[7.5px] font-bold">{fmt(it.price)}</div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
