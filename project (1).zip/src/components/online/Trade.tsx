import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Lock, Check, ShieldAlert, ArrowLeftRight } from 'lucide-react';
import { useNet } from '../../net/netStore';
import { toNetItem, type NetItem } from '../../net/protocol';
import { useGame, useSkins } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { SkinImage, SectionTitle } from '../ui';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

/** Защита от подмены оффера в последний момент */
const ANTI_SCAM_MS = 2000;

export default function Trade({ onBack }: { onBack: () => void }) {
  const net = useNet();
  const { state, addItem, removeItem, toast, log } = useGame();
  const { byName } = useSkins();

  const [mine, setMine] = useState<NetItem[]>([]);
  const [theirs, setTheirs] = useState<NetItem[]>([]);
  const [myLock, setMyLock] = useState(false);
  const [theirLock, setTheirLock] = useState(false);
  const [myOk, setMyOk] = useState(false);
  const [theirOk, setTheirOk] = useState(false);
  const [armed, setArmed] = useState(false);     // истёк ли anti-scam таймер
  const [left, setLeft] = useState(0);
  const doneRef = useRef(false);

  const inv = useMemo(() => state.inventory.map((i) => {
    const live = byName.get(i.name);
    return live ? { ...i, ...live, uid: i.uid } : i;
  }), [state.inventory, byName]);

  const myVal = mine.reduce((a, x) => a + x.price, 0);
  const theirVal = theirs.reduce((a, x) => a + x.price, 0);

  /* таймер безопасности: подтверждение доступно не сразу после блокировки */
  useEffect(() => {
    if (!(myLock && theirLock)) { setArmed(false); setLeft(0); return; }
    setLeft(ANTI_SCAM_MS);
    const t0 = Date.now();
    const iv = window.setInterval(() => {
      const rest = ANTI_SCAM_MS - (Date.now() - t0);
      if (rest <= 0) { setArmed(true); setLeft(0); window.clearInterval(iv); }
      else setLeft(rest);
    }, 100);
    return () => window.clearInterval(iv);
  }, [myLock, theirLock]);

  /* любое изменение состава сбрасывает подтверждения — защита от подмены */
  useEffect(() => { setMyOk(false); setTheirOk(false); }, [mine, theirs]);

  /* входящие события обмена */
  useEffect(() => net.on((m) => {
    if (m.t === 'trade:offer') { setTheirs(m.items); setTheirLock(false); }
    if (m.t === 'trade:lock') setTheirLock(m.locked);
    if (m.t === 'trade:confirm') setTheirOk(true);
    if (m.t === 'trade:cancel') {
      setTheirs([]); setTheirLock(false); setTheirOk(false); setMyOk(false); setMyLock(false);
      toast('Обмен отменён', 'info', m.reason);
    }
    if (m.t === 'trade:done') finish();
  }), [net, mine, theirs]);

  /** атомарное применение: отдаём своё, получаем чужое */
  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    for (const it of mine) removeItem(it.uid);
    for (const it of theirs) {
      const live = byName.get(it.name);
      addItem(live ?? {
        id: it.uid, name: it.name, weapon: it.weapon, rarity: it.rarity,
        rarityRu: it.rarityRu, color: it.color, price: it.price,
        image: it.image, star: it.star,
      });
    }
    log({
      kind: 'shop',
      text: `Обмен с ${net.remote?.name ?? 'игроком'}: −${mine.length} / +${theirs.length}`,
      amount: theirVal - myVal,
      success: theirVal >= myVal,
    });
    audio.coin();
    toast('Обмен завершён', 'win', `Получено предметов: ${theirs.length}`);
    onBack();
  };

  const toggle = (uid: string) => {
    if (myLock) return;
    const item = inv.find((i) => i.uid === uid);
    if (!item) return;
    audio.click();
    setMine((cur) => {
      const next = cur.some((x) => x.uid === uid)
        ? cur.filter((x) => x.uid !== uid)
        : [...cur, toNetItem(item)];
      net.send({ t: 'trade:offer', items: next });
      return next;
    });
  };

  const lock = () => {
    const v = !myLock;
    setMyLock(v);
    audio.click();
    net.send({ t: 'trade:lock', locked: v });
  };

  const confirm = () => {
    if (!armed) return;
    setMyOk(true);
    audio.click();
    net.send({ t: 'trade:confirm' });
  };

  /* обе стороны подтвердили — применяем и сообщаем партнёру */
  useEffect(() => {
    if (myOk && theirOk && !doneRef.current) {
      net.send({ t: 'trade:done' });
      finish();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myOk, theirOk]);

  /* обрыв связи — откат (ничего не применяли, просто выходим) */
  useEffect(() => {
    if (net.state === 'closed' || net.state === 'error') {
      if (!doneRef.current) { toast('Связь потеряна', 'lose', 'Обмен отменён'); onBack(); }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [net.state]);

  const cancel = () => {
    net.send({ t: 'trade:cancel', reason: 'Отменено партнёром' });
    onBack();
  };

  const Side = ({ items, title, val, locked, ok }: {
    items: NetItem[]; title: string; val: number; locked: boolean; ok: boolean;
  }) => (
    <div className={cn('panel-inset p-2 transition-colors',
      ok ? 'border-emerald-400/50' : locked ? 'border-gold/40' : '')}>
      <div className="mb-1.5 flex items-center gap-1">
        <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">{title}</span>
        {locked && <Lock size={10} className="text-gold" />}
        {ok && <Check size={11} className="text-emerald-400" />}
        <span className="num price ml-auto text-[10.5px] font-extrabold">{fmt(val)}</span>
      </div>
      <div className="grid min-h-[76px] grid-cols-4 gap-1">
        {items.length === 0 && (
          <div className="col-span-4 grid place-items-center py-5 text-[10px] text-slate-600">
            пусто
          </div>
        )}
        {items.map((it) => (
          <div key={it.uid} className="rounded-lg border p-1"
            style={{ borderColor: `${it.color}55`, background: `${it.color}12` }}>
            <SkinImage skin={it as never} className="h-7 w-full" />
            <div className="num price truncate text-center text-[7.5px] font-bold">{fmt(it.price)}</div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="fade-up space-y-2.5">
      <div className="panel flex items-center gap-2 p-2">
        <button className="chip shrink-0" onClick={cancel}><X size={14} /></button>
        <span className="flex-1 truncate text-[12.5px] font-extrabold">
          Обмен с {net.remote?.name ?? '—'}
        </span>
        <ArrowLeftRight size={15} className="text-gold" />
      </div>

      <Side items={theirs} title="Предложение партнёра" val={theirVal} locked={theirLock} ok={theirOk} />
      <Side items={mine} title="Ваше предложение" val={myVal} locked={myLock} ok={myOk} />

      {myVal > 0 && theirVal > 0 && Math.abs(myVal - theirVal) / Math.max(myVal, theirVal) > 0.35 && (
        <div className="panel-inset flex items-start gap-2 border-amber-400/40 p-2 text-[10px] text-amber-300">
          <ShieldAlert size={13} className="mt-0.5 shrink-0" />
          Крупная разница в стоимости. Проверьте предметы ещё раз.
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        <button onClick={lock} disabled={myOk}
          className={cn('btn py-3 text-[12px] font-extrabold uppercase', myLock ? 'btn-ghost' : 'btn-gold')}>
          <Lock size={13} /> {myLock ? 'Разблокировать' : 'Заблокировать'}
        </button>
        <button onClick={confirm} disabled={!myLock || !theirLock || !armed || myOk}
          className="btn btn-green py-3 text-[12px] font-extrabold uppercase">
          {myOk ? 'Ждём партнёра' : !armed && myLock && theirLock
            ? `${Math.ceil(left / 1000)}…` : 'Подтвердить'}
        </button>
      </div>

      {/* инвентарь */}
      <div className="panel p-2.5">
        <SectionTitle icon={<ArrowLeftRight size={14} className="text-gold" />}
          title={`Мои предметы · ${inv.length}`} />
        <div className="grid max-h-[220px] grid-cols-4 gap-1.5 overflow-y-auto">
          {inv.map((it) => {
            const sel = mine.some((x) => x.uid === it.uid);
            return (
              <button key={it.uid} onClick={() => toggle(it.uid)} disabled={myLock}
                className="rounded-lg border p-1 transition-transform active:scale-95"
                style={{
                  borderColor: sel ? it.color : `${it.color}33`,
                  background: sel ? `${it.color}22` : 'transparent',
                  boxShadow: sel ? `inset 0 0 0 1px ${it.color}` : undefined,
                }}>
                <SkinImage skin={it} className="h-8 w-full" />
                <div className="num price truncate text-center text-[7.5px] font-bold">{fmt(it.price)}</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
