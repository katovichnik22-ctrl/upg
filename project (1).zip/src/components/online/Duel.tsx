import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Swords, ShieldCheck } from 'lucide-react';
import { useNet } from '../../net/netStore';
import { toNetItem, type NetItem } from '../../net/protocol';
import { startRound, verify, combine, rollFrom, type FairRound } from '../../net/fair';
import { useGame, useSkins } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { SkinImage, SectionTitle } from '../ui';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

type Phase = 'pick' | 'waiting' | 'commit' | 'spin' | 'done';

/** Ставки считаются равными при расхождении не более 15% */
const TOLERANCE = 0.15;

export default function Duel({ onBack }: { onBack: () => void }) {
  const net = useNet();
  const { state, addItem, removeItem, toast, log, addStats } = useGame();
  const { byName } = useSkins();

  const [mine, setMine] = useState<NetItem[]>([]);
  const [theirs, setTheirs] = useState<NetItem[]>([]);
  const [phase, setPhase] = useState<Phase>('pick');
  const [round, setRound] = useState<FairRound | null>(null);
  const [roll, setRoll] = useState<number | null>(null);
  const [winner, setWinner] = useState<string | null>(null);
  const [spinPos, setSpinPos] = useState(0);

  const applied = useRef(false);
  const roundRef = useRef<FairRound | null>(null);
  roundRef.current = round;

  const inv = useMemo(() => state.inventory.map((i) => {
    const live = byName.get(i.name);
    return live ? { ...i, ...live, uid: i.uid } : i;
  }), [state.inventory, byName]);

  const myVal = mine.reduce((a, x) => a + x.price, 0);
  const theirVal = theirs.reduce((a, x) => a + x.price, 0);
  const balanced = myVal > 0 && theirVal > 0
    && Math.abs(myVal - theirVal) / Math.max(myVal, theirVal) <= TOLERANCE;

  /* доля банка определяет шанс — вклад пропорционален выигрышу */
  const myChance = myVal + theirVal > 0 ? (myVal / (myVal + theirVal)) * 100 : 50;

  /** применяем исход: победитель забирает оба вклада */
  const settle = (r: number) => {
    if (applied.current) return;
    applied.current = true;
    const iWin = r < myChance;
    if (iWin) {
      for (const it of theirs) {
        const live = byName.get(it.name);
        addItem(live ?? {
          id: it.uid, name: it.name, weapon: it.weapon, rarity: it.rarity,
          rarityRu: it.rarityRu, color: it.color, price: it.price,
          image: it.image, star: it.star,
        });
      }
      audio.bigWin();
      toast('Дуэль выиграна!', 'win', `+${fmt(theirVal)}`);
    } else {
      for (const it of mine) removeItem(it.uid);
      audio.lose();
      toast('Дуэль проиграна', 'lose', `−${fmt(myVal)}`);
    }
    addStats({ gamesPlayed: 1, gameWins: iWin ? 1 : 0, wagered: myVal });
    log({
      kind: 'game',
      text: `Дуэль с ${net.remote?.name ?? '—'}: ${iWin ? 'победа' : 'поражение'}`,
      amount: iWin ? theirVal : -myVal, success: iWin,
    });
    setWinner(iWin ? 'me' : 'them');
    setPhase('done');
  };

  /** анимация колеса перед объявлением результата */
  const animate = (r: number) => {
    setPhase('spin');
    const lite = state.settings.lite || state.settings.fast;
    const dur = lite ? 900 : 2600;
    const t0 = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 4);
      setSpinPos(e * 100 + (1 - e) * (r + 360) % 100);
      if (p < 1) requestAnimationFrame(step);
      else { setSpinPos(r); setRoll(r); settle(r); }
    };
    requestAnimationFrame(step);
  };

  /* сетевые события */
  useEffect(() => net.on(async (m) => {
    if (m.t === 'duel:invite') { setTheirs(m.stake); return; }
    if (m.t === 'duel:accept') { setTheirs(m.stake); return; }
    if (m.t === 'duel:decline') { toast('Соперник отказался', 'info'); onBack(); return; }

    if (m.t === 'duel:commit') {
      setRound((cur) => cur ? { ...cur, theirHash: m.hash } : cur);
      return;
    }
    if (m.t === 'duel:reveal') {
      const r = roundRef.current;
      if (!r?.theirHash) return;
      /* проверяем, что соперник не подменил сид после обмена хэшами */
      if (!(await verify(m.seed, r.theirHash))) {
        toast('Нечестная игра', 'lose', 'Сид соперника не сошёлся с хэшем');
        onBack();
        return;
      }
      const res = rollFrom(combine([r.mySeed, m.seed])) * 100;
      animate(res);
      return;
    }
  }), [net, myChance, mine, theirs]);

  /* обе стороны прислали хэш — раскрываем сиды */
  useEffect(() => {
    if (phase === 'commit' && round?.myHash && round.theirHash) {
      net.send({ t: 'duel:reveal', seed: round.mySeed });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, round?.theirHash]);

  useEffect(() => {
    if ((net.state === 'closed' || net.state === 'error') && !applied.current && phase !== 'pick') {
      toast('Связь потеряна', 'lose', 'Дуэль отменена');
      onBack();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [net.state]);

  const toggle = (uid: string) => {
    if (phase !== 'pick') return;
    const item = inv.find((i) => i.uid === uid);
    if (!item) return;
    audio.click();
    setMine((cur) => cur.some((x) => x.uid === uid)
      ? cur.filter((x) => x.uid !== uid)
      : [...cur, toNetItem(item)]);
  };

  const propose = () => {
    audio.click();
    net.send({ t: 'duel:invite', stake: mine });
    setPhase('waiting');
  };

  const begin = async () => {
    const r = await startRound();
    setRound(r);
    setPhase('commit');
    net.send({ t: 'duel:commit', hash: r.myHash });
  };

  return (
    <div className="fade-up space-y-2.5">
      <div className="panel flex items-center gap-2 p-2">
        <button className="chip shrink-0" onClick={onBack}><X size={14} /></button>
        <span className="flex-1 truncate text-[12.5px] font-extrabold">
          Дуэль · {net.remote?.name ?? '—'}
        </span>
        <Swords size={15} className="text-gold" />
      </div>

      {/* банк */}
      <div className="panel p-3">
        <div className="grid grid-cols-2 gap-2">
          {[
            { title: 'Вы', items: mine, val: myVal, ch: myChance, win: winner === 'me' },
            { title: net.remote?.name ?? 'Соперник', items: theirs, val: theirVal, ch: 100 - myChance, win: winner === 'them' },
          ].map((side, i) => (
            <div key={i} className={cn('panel-inset p-2 transition-colors',
              side.win && 'border-emerald-400/60 bg-emerald-400/10')}>
              <div className="truncate text-[10px] font-bold text-slate-400">{side.title}</div>
              <div className="num price text-[13px] font-extrabold">{fmt(side.val)}</div>
              <div className="num text-[9px] text-gold">шанс {side.ch.toFixed(1)}%</div>
              <div className="mt-1 grid grid-cols-3 gap-1">
                {side.items.slice(0, 6).map((it) => (
                  <div key={it.uid} className="rounded border p-0.5"
                    style={{ borderColor: `${it.color}55` }}>
                    <SkinImage skin={it as never} className="h-5 w-full" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* полоса шанса */}
        <div className="mt-2.5 h-3 overflow-hidden rounded-full bg-rose-500/40">
          <div className="h-full bg-emerald-400/70 transition-all"
            style={{ width: `${myChance}%` }} />
        </div>

        {phase === 'spin' && (
          <div className="mt-2 text-center">
            <div className="num font-display text-[26px] font-extrabold text-gold">
              {spinPos.toFixed(1)}
            </div>
            <div className="text-[9px] uppercase tracking-widest text-slate-500">розыгрыш…</div>
          </div>
        )}

        {phase === 'done' && roll !== null && (
          <div className="pop-in mt-2 text-center">
            <div className={cn('font-display text-[18px] font-extrabold',
              winner === 'me' ? 'text-emerald-300' : 'text-rose-300')}>
              {winner === 'me' ? 'ПОБЕДА' : 'ПОРАЖЕНИЕ'}
            </div>
            <div className="num text-[10px] text-slate-500">выпало {roll.toFixed(2)}</div>
          </div>
        )}
      </div>

      {/* честность */}
      {round && (
        <div className="panel-inset flex items-start gap-2 p-2 text-[9px] leading-relaxed text-slate-500">
          <ShieldCheck size={12} className="mt-0.5 shrink-0 text-emerald-400" />
          <div className="min-w-0">
            <div className="truncate">мой хэш: {round.myHash.slice(0, 24)}…</div>
            {round.theirHash && <div className="truncate">хэш соперника: {round.theirHash.slice(0, 24)}…</div>}
            <div>Результат = XOR обоих сидов. Подкрутить его невозможно.</div>
          </div>
        </div>
      )}

      {/* действия */}
      {phase === 'pick' && (
        <button onClick={propose} disabled={mine.length === 0}
          className="btn btn-gold w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider">
          Предложить ставку
        </button>
      )}
      {phase === 'waiting' && (
        <button onClick={begin} disabled={!balanced}
          className="btn btn-green w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider">
          {balanced ? 'Начать дуэль' : 'Ждём равную ставку'}
        </button>
      )}
      {phase === 'commit' && (
        <div className="panel py-3 text-center text-[11px] font-bold uppercase tracking-wider text-slate-500">
          обмен сидами…
        </div>
      )}
      {phase === 'done' && (
        <button onClick={onBack} className="btn btn-gold w-full py-3 text-[12.5px] font-extrabold uppercase">
          Закрыть
        </button>
      )}

      {/* выбор предметов */}
      {phase === 'pick' && (
        <div className="panel p-2.5">
          <SectionTitle icon={<Swords size={14} className="text-gold" />} title="Ваша ставка" />
          <div className="grid max-h-[200px] grid-cols-4 gap-1.5 overflow-y-auto">
            {inv.map((it) => {
              const sel = mine.some((x) => x.uid === it.uid);
              return (
                <button key={it.uid} onClick={() => toggle(it.uid)}
                  className="rounded-lg border p-1 active:scale-95"
                  style={{
                    borderColor: sel ? it.color : `${it.color}33`,
                    background: sel ? `${it.color}22` : 'transparent',
                  }}>
                  <SkinImage skin={it} className="h-8 w-full" />
                  <div className="num price truncate text-center text-[7.5px] font-bold">{fmt(it.price)}</div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
