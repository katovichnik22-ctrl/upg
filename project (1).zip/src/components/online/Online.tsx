import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import {
  Users, Link2, Copy, Check, X, Send, MessageSquare,
  ArrowLeftRight, Swords, Trophy, Wifi, WifiOff, Trash2,
} from 'lucide-react';
import { useNet } from '../../net/netStore';
import { normalizeCode } from '../../net/room';
import { REACTIONS, type Friend } from '../../net/protocol';
import { SectionTitle } from '../ui';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

const Trade = lazy(() => import('./Trade'));
const Duel = lazy(() => import('./Duel'));
const Battle = lazy(() => import('./Battle'));

type View = 'main' | 'chat' | 'trade' | 'duel' | 'battle';

export default function Online() {
  const net = useNet();
  const [view, setView] = useState<View>('main');
  const [tab, setTab] = useState<'host' | 'join'>('host');
  const [theirCode, setTheirCode] = useState('');
  const [copied, setCopied] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const online = net.state === 'online';

  const copy = async (text: string, tag: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(tag);
      audio.click();
      window.setTimeout(() => setCopied(''), 1500);
    } catch {
      setErr('Скопируйте код вручную');
    }
  };

  const doHost = async () => {
    setBusy(true); setErr('');
    try { await net.host(); } catch { setErr('Не удалось создать лобби'); }
    setBusy(false);
  };

  const doJoin = async () => {
    if (theirCode.length !== 5) return;
    setBusy(true); setErr('');
    try { await net.join(theirCode); }
    catch (e) { setErr((e as Error).message || 'Комната не найдена'); }
    setBusy(false);
  };

  /* --- подэкраны --- */
  if (view !== 'main') {
    const back = () => setView('main');
    return (
      <Suspense fallback={<div className="panel p-8 text-center text-[12px] text-slate-500">Загрузка…</div>}>
        {view === 'chat' && <ChatView onBack={back} />}
        {view === 'trade' && <Trade onBack={back} />}
        {view === 'duel' && <Duel onBack={back} />}
        {view === 'battle' && <Battle onBack={back} />}
      </Suspense>
    );
  }

  return (
    <div className="fade-up space-y-3">
      {/* статус соединения */}
      <div className="panel p-3">
        <div className="flex items-center gap-2.5">
          <div className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl',
            online ? 'bg-emerald-400/12 text-emerald-300' : 'bg-white/5 text-slate-500')}>
            {online ? <Wifi size={18} /> : <WifiOff size={18} />}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-extrabold">
              {online ? net.remote?.name ?? 'Подключено' : 'Не подключено'}
            </div>
            <div className="num text-[9.5px] uppercase tracking-wider text-slate-500">
              {online ? `задержка ${net.ping} мс · P2P` : 'соединение точка-точка'}
            </div>
          </div>
          {online && (
            <button className="chip" onClick={() => { audio.click(); net.disconnect(); }}>
              <X size={13} />
            </button>
          )}
        </div>

        {online && (
          <div className="mt-2.5 grid grid-cols-4 gap-1.5">
            {([
              ['Чат', MessageSquare, 'chat'],
              ['Обмен', ArrowLeftRight, 'trade'],
              ['Дуэль', Swords, 'duel'],
              ['Баттл', Trophy, 'battle'],
            ] as const).map(([label, Icon, v]) => (
              <button key={v} className="chip chip-lg flex-col gap-1!"
                onClick={() => { audio.click(); net.openChat(net.remote?.id ?? null); setView(v); }}>
                <Icon size={15} />
                <span className="text-[9px]">{label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* подключение */}
      {!online && (
        <div className="panel p-3">
          <SectionTitle icon={<Link2 size={15} className="text-gold" />} title="Лобби" />
          <div className="chip-row mb-2.5">
            <button className={cn('chip chip-lg', tab === 'host' && 'on')}
              onClick={() => { audio.click(); setTab('host'); }}>Создать</button>
            <button className={cn('chip chip-lg', tab === 'join' && 'on')}
              onClick={() => { audio.click(); setTab('join'); }}>Войти по коду</button>
          </div>

          {tab === 'host' ? (
            <div className="space-y-2">
              {!net.code ? (
                <>
                  <p className="text-[10.5px] leading-relaxed text-slate-500">
                    Создайте лобби — получите код из 5 символов. Продиктуйте его
                    другу, и он сразу окажется у вас.
                  </p>
                  <button onClick={doHost} disabled={busy}
                    className="btn btn-gold btn-shine w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider">
                    {busy ? 'Создаём лобби…' : 'Создать лобби'}
                  </button>
                </>
              ) : (
                <>
                  <div className="panel-inset p-3 text-center">
                    <div className="text-[9.5px] font-bold uppercase tracking-[0.2em] text-slate-500">
                      Код лобби
                    </div>
                    <div className="num mt-1 font-display text-[38px] font-black tracking-[0.18em] text-gold"
                      style={{ textShadow: '0 0 22px rgba(246,196,69,.45)' }}>
                      {net.code}
                    </div>
                    <button onClick={() => copy(net.code, 'code')}
                      className="chip mt-1.5 !min-h-0 px-3 py-1.5 text-[11px]">
                      {copied === 'code' ? <Check size={12} /> : <Copy size={12} />}
                      {copied === 'code' ? 'Скопировано' : 'Копировать'}
                    </button>
                  </div>
                  <div className="flex items-center justify-center gap-2 py-1 text-[11px] font-bold text-slate-400">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-gold" />
                    Ожидаем второго игрока…
                  </div>
                  <button onClick={() => { audio.click(); net.disconnect(); }}
                    className="btn btn-ghost w-full py-2.5 text-[12px]">Отменить</button>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-[10.5px] leading-relaxed text-slate-500">
                Введите код лобби, который продиктовал друг.
              </p>
              <input
                value={theirCode}
                onChange={(e) => setTheirCode(normalizeCode(e.target.value))}
                onKeyDown={(e) => { if (e.key === 'Enter') doJoin(); }}
                placeholder="ABC12"
                maxLength={5}
                autoCapitalize="characters"
                className="input num w-full px-3 py-4 text-center font-display text-[30px] font-black uppercase tracking-[0.3em]"
              />
              <button onClick={doJoin} disabled={busy || theirCode.length !== 5}
                className="btn btn-gold btn-shine w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider">
                {busy ? 'Подключаемся…' : 'Войти'}
              </button>
            </div>
          )}

          {(err || net.error) && (
            <div className="mt-2 text-[11px] font-bold text-rose-400">{err || net.error}</div>
          )}

          {net.rooms.length > 0 && tab === 'join' && (
            <div className="chip-row mt-2">
              <span className="chip pointer-events-none text-slate-500">Недавние</span>
              {net.rooms.map((r) => (
                <button key={r} className="chip num" onClick={() => setTheirCode(r)}>{r}</button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* друзья */}
      <div className="panel p-3">
        <SectionTitle
          icon={<Users size={15} className="text-gold" />}
          title={`Друзья · ${net.friends.length}`}
          right={<span className="num rounded bg-white/5 px-1.5 text-[10px] text-slate-400">
            NG-{net.myId.slice(0, 4).toUpperCase()}
          </span>}
        />
        {net.friends.length === 0 ? (
          <div className="py-6 text-center text-[11px] text-slate-500">
            Пока никого. Подключитесь по коду — друг добавится сам.
          </div>
        ) : (
          <div className="space-y-1.5">
            {net.friends.map((f) => (
              <FriendRow key={f.id} f={f}
                isOnline={online && net.remote?.id === f.id}
                onChat={() => { net.openChat(f.id); setView('chat'); }}
                onRemove={() => { audio.click(); net.removeFriend(f.id); }} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function FriendRow({ f, isOnline, onChat, onRemove }: {
  f: Friend; isOnline: boolean; onChat: () => void; onRemove: () => void;
}) {
  const hue = Math.abs([...f.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360;
  return (
    <div className="panel-inset flex items-center gap-2.5 p-2">
      <div className="relative shrink-0">
        <div className="grid h-9 w-9 place-items-center rounded-xl text-[13px] font-extrabold text-white"
          style={{ background: `linear-gradient(135deg,hsl(${hue} 65% 52%),hsl(${(hue + 60) % 360} 65% 38%))` }}>
          {f.name[0]?.toUpperCase() ?? '?'}
        </div>
        <span className={cn('absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#0d1119]',
          isOnline ? 'bg-emerald-400' : 'bg-slate-600')} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[12px] font-bold">{f.name}</div>
        <div className="num text-[9px] text-slate-500">
          {isOnline ? 'в сети' : f.lastSeen ? new Date(f.lastSeen).toLocaleDateString('ru-RU') : 'не в сети'}
        </div>
      </div>
      <button className="chip !min-h-0 px-2 py-1.5" onClick={onChat}><MessageSquare size={12} /></button>
      <button className="rounded-lg bg-white/5 p-1.5 text-slate-500 active:text-rose-300" onClick={onRemove}>
        <Trash2 size={12} />
      </button>
    </div>
  );
}

/** Экран переписки */
function ChatView({ onBack }: { onBack: () => void }) {
  const net = useNet();
  const [text, setText] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const friend = net.friends.find((f) => f.id === net.chatWith);

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [net.chat.length]);

  const send = (t: string) => {
    if (!t.trim()) return;
    net.sendChat(t);
    setText('');
    audio.blip(1100, 0.03, 'square', 0.04);
  };

  return (
    <div className="fade-up flex h-[calc(100dvh-150px)] flex-col gap-2">
      <div className="panel flex items-center gap-2 p-2">
        <button className="chip shrink-0" onClick={onBack}><X size={14} /></button>
        <span className="min-w-0 flex-1 truncate text-[12.5px] font-extrabold">
          {friend?.name ?? 'Чат'}
        </span>
        <span className={cn('h-2 w-2 rounded-full',
          net.state === 'online' ? 'bg-emerald-400' : 'bg-slate-600')} />
      </div>

      <div className="panel flex-1 space-y-1.5 overflow-y-auto p-2.5">
        {net.chat.length === 0 && (
          <div className="py-8 text-center text-[11px] text-slate-500">Сообщений пока нет</div>
        )}
        {net.chat.map((m) => (
          <div key={m.id} className={cn('flex', m.from === 'me' ? 'justify-end' : 'justify-start')}>
            <div className={cn('max-w-[78%] rounded-xl px-2.5 py-1.5 text-[12px]',
              m.from === 'me' ? 'bg-gold/15 text-gold' : 'bg-white/6 text-slate-200')}>
              <div className="break-words">{m.text}</div>
              <div className="num mt-0.5 text-right text-[8px] opacity-50">
                {new Date(m.ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                {m.pending && ' · ожидает'}
              </div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <div className="panel p-2">
        <div className="chip-row mb-2">
          {REACTIONS.map((r) => (
            <button key={r} className="chip !min-h-0 px-2 py-1" onClick={() => send(r)}>{r}</button>
          ))}
        </div>
        <div className="flex gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') send(text); }}
            placeholder="Сообщение…" className="input flex-1 px-3 py-2.5 text-[13px]" />
          <button onClick={() => send(text)} disabled={!text.trim()}
            className="btn btn-gold h-11 w-11 shrink-0"><Send size={16} /></button>
        </div>
      </div>
    </div>
  );
}


