import { useEffect, useRef, useState } from 'react';
import { Disc3, History, Zap } from 'lucide-react';
import { useGame } from '../lib/store';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { SectionTitle } from './ui';
import { cn } from '../utils/cn';

const CELL = typeof window !== 'undefined' && window.innerWidth < 520 ? 62 : 84;
const GAP = 8;
const FULL = CELL + GAP;
const SEQ = 15;
const COPIES = 12;

type C = 'r' | 'b' | 'g';
const colorOf = (n: number): C => (n === 0 ? 'g' : n <= 7 ? 'r' : 'b');

const CELL_STYLE: Record<C, string> = {
  r: 'bg-gradient-to-b from-rose-500 to-rose-800 shadow-[inset_0_2px_0_rgba(255,255,255,.22),0_8px_20px_-8px_rgba(244,63,94,.7)]',
  b: 'bg-gradient-to-b from-slate-600 to-slate-900 shadow-[inset_0_2px_0_rgba(255,255,255,.14),0_8px_20px_-8px_rgba(15,23,42,.9)]',
  g: 'bg-gradient-to-b from-emerald-400 to-emerald-700 shadow-[inset_0_2px_0_rgba(255,255,255,.3),0_8px_20px_-8px_rgba(34,197,94,.8)]',
};
const DOT: Record<C, string> = {
  r: 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,.7)]',
  b: 'bg-slate-600',
  g: 'bg-emerald-400 shadow-[0_0_10px_rgba(34,197,94,.8)]',
};

export default function Roulette() {
  const { state, adjust, log, addStats, toast } = useGame();
  const [amount, setAmount] = useState(100);
  const [spinning, setSpinning] = useState(false);
  const [results, setResults] = useState<number[]>([3, 11, 7, 0, 9, 2, 14, 5]);
  const [hoverMsg, setHoverMsg] = useState<string | null>(null);

  const reelRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const xRef = useRef(0);
  const rafRef = useRef(0);
  const lastCellRef = useRef(-1);

  const clampBet = (v: number) => Math.max(1, Math.min(state.balance || 1, Math.round(v)));

  useEffect(() => {
    const inner = innerRef.current;
    const x = -(5 * SEQ * FULL);
    xRef.current = x;
    if (inner) inner.style.transform = `translate3d(${x}px,0,0)`;
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  const spin = (pick: C) => {
    if (spinning) return;
    const bet = clampBet(amount);
    if (state.balance < bet || bet < 1) {
      toast('Недостаточно средств', 'lose', 'Пополните баланс в магазине');
      return;
    }
    const inner = innerRef.current;
    const reel = reelRef.current;
    if (!inner || !reel) return;

    audio.click();
    adjust(-bet);
    setSpinning(true);
    setHoverMsg(null);

    const res = Math.floor(Math.random() * SEQ);
    const targetIndex = 7 * SEQ + res;
    const jitter = Math.floor((Math.random() - 0.5) * (CELL - 34));
    const targetX = -(targetIndex * FULL + jitter - (reel.clientWidth / 2 - FULL / 2 + GAP / 2));
    const fromX = xRef.current;
    const dur = state.settings.fast ? 2400 : 5000;
    const t0 = performance.now();

    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 5);
      const x = fromX + (targetX - fromX) * e;
      xRef.current = x;
      inner.style.transform = `translate3d(${x}px,0,0)`;
      const cellIdx = Math.floor(-x / FULL);
      if (cellIdx !== lastCellRef.current) {
        lastCellRef.current = cellIdx;
        audio.reelTick();
      }
      if (p < 1) {
        rafRef.current = requestAnimationFrame(step);
      } else {
        finish(res, bet, pick);
      }
    };
    rafRef.current = requestAnimationFrame(step);
  };

  const finish = (res: number, bet: number, pick: C) => {
    const inner = innerRef.current;
    /* normalise position back to an equivalent earlier sequence */
    if (inner) {
      const seqLen = SEQ * FULL;
      const base = (xRef.current % seqLen) - 5 * seqLen;
      xRef.current = base;
      inner.style.transform = `translate3d(${base}px,0,0)`;
    }

    const c = colorOf(res);
    const win = c === pick;
    const pay = win ? bet * (c === 'g' ? 14 : 2) : 0;
    setResults((r) => [res, ...r].slice(0, 14));
    setSpinning(false);

    if (win) {
      if (c === 'g') audio.bigWin(); else audio.win();
      adjust(pay);
      addStats({ rouletteSpins: 1, rouletteWins: 1, wagered: bet, bestWin: Math.max(0, pay - state.stats.bestWin) });
      log({ kind: 'roulette', text: `Рулетка: выпало ${res} · выигрыш`, amount: pay, success: true });
      toast('Победа в рулетке!', 'win', `Выпало ${res} · +${fmt(pay)}`);
    } else {
      audio.lose();
      addStats({ rouletteSpins: 1, wagered: bet });
      log({ kind: 'roulette', text: `Рулетка: выпало ${res} · проигрыш`, amount: -bet, success: false });
      toast('Ставка не сыграла', 'lose', `Выпало ${res}`);
    }
  };

  const chip = (label: string, fn: () => void) => (
    <button key={label} className="chip" onClick={() => { audio.click(); fn(); }} disabled={spinning}>
      {label}
    </button>
  );

  return (
    <div className="fade-up mx-auto max-w-[980px] space-y-4">
      {/* reel */}
      <div className="panel relative overflow-hidden p-4 sm:p-5">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-rose-500/6 to-transparent" />
        <SectionTitle icon={<Disc3 size={15} className="text-rose-300" />} title="Рулетка"
          right={<span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">красное ×2 · зеро ×14 · чёрное ×2</span>} />

        <div ref={reelRef} className={cn('reel-mask relative overflow-hidden rounded-2xl border border-line bg-[#080b16] py-4')}>
          {/* pointer */}
          <div className="pointer-events-none absolute left-1/2 top-0 z-10 h-full w-[3px] -translate-x-1/2 bg-gradient-to-b from-transparent via-white/70 to-transparent" />
          <div className="pointer-events-none absolute left-1/2 top-0 z-10 -translate-x-1/2 border-x-[8px] border-t-[10px] border-x-transparent border-t-white drop-shadow-[0_0_8px_rgba(255,255,255,.8)]" />
          <div className="pointer-events-none absolute bottom-0 left-1/2 z-10 -translate-x-1/2 border-x-[8px] border-b-[10px] border-x-transparent border-b-white drop-shadow-[0_0_8px_rgba(255,255,255,.8)]" />

          <div ref={innerRef} className="flex w-max will-change-transform" style={{ gap: GAP, transform: 'translate3d(0,0,0)' }}>
            {Array.from({ length: COPIES * SEQ }, (_, i) => {
              const n = i % SEQ;
              return (
                <div
                  key={i}
                  style={{ width: CELL, height: CELL }}
                  className={cn('grid shrink-0 place-items-center rounded-xl font-display text-[17px] font-extrabold text-white sm:text-[22px]', CELL_STYLE[colorOf(n)])}
                >
                  {n}
                </div>
              );
            })}
          </div>
        </div>

        {/* history */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto py-1">
          <History size={14} className="mr-1 shrink-0 text-slate-500" />
          {results.map((r, i) => (
            <span
              key={i}
              className={cn('num grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-extrabold text-white', DOT[colorOf(r)], i === 0 && 'ring-2 ring-white/50 pop-in')}
            >
              {r}
            </span>
          ))}
        </div>
      </div>

      {/* betting */}
      <div className="panel p-4 sm:p-5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Ставка</span>
            <input
              type="number"
              min={1}
              value={amount}
              disabled={spinning}
              onChange={(e) => setAmount(Math.max(1, Number(e.target.value) || 1))}
              className="input num w-28 px-3 py-2 text-center text-sm font-bold"
            />
            <span className="text-xs font-bold text-slate-500">₽</span>
          </div>
          <div className="chip-row w-full sm:w-auto sm:flex-wrap">
            {chip('10', () => setAmount(10))}
            {chip('50', () => setAmount(50))}
            {chip('100', () => setAmount(100))}
            {chip('500', () => setAmount(500))}
            {chip('½', () => setAmount((a) => Math.max(1, Math.floor(a / 2))))}
            {chip('×2', () => setAmount((a) => Math.min(state.balance, a * 2)))}
            {chip('МАКС', () => setAmount(Math.max(1, state.balance)))}
          </div>
          <div className="ml-auto hidden items-center gap-1.5 text-[11px] font-bold text-slate-500 sm:flex">
            <Zap size={12} className="text-amber-300" />
            Баланс: <span className="num text-emerald-300">{fmt(state.balance)}</span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2.5">
          <button
            onClick={() => spin('r')}
            disabled={spinning}
            onMouseEnter={() => setHoverMsg('Красное: 1–7, выплата ×2')}
            onMouseLeave={() => setHoverMsg(null)}
            className="btn btn-red btn-shine px-1 py-4 font-display text-[11px] font-extrabold uppercase tracking-wider sm:text-[13px]"
          >
            Красное ×2
          </button>
          <button
            onClick={() => spin('g')}
            disabled={spinning}
            onMouseEnter={() => setHoverMsg('Зеро: 0, выплата ×14')}
            onMouseLeave={() => setHoverMsg(null)}
            className="btn btn-green btn-shine px-1 py-4 font-display text-[11px] font-extrabold uppercase tracking-wider sm:text-[13px]"
          >
            Зеро ×14
          </button>
          <button
            onClick={() => spin('b')}
            disabled={spinning}
            onMouseEnter={() => setHoverMsg('Чёрное: 8–14, выплата ×2')}
            onMouseLeave={() => setHoverMsg(null)}
            className="btn btn-shine px-1 py-4 font-display text-[11px] font-extrabold uppercase tracking-wider text-white sm:text-[13px]"
            style={{ background: 'linear-gradient(180deg,#3d4767,#131722)', boxShadow: '0 8px 24px -8px rgba(0,0,0,.8), inset 0 1px 0 rgba(255,255,255,.12)' }}
          >
            Чёрное ×2
          </button>
        </div>

        <div className={cn('mt-3 text-center text-[12px] font-bold text-slate-400 transition-opacity', hoverMsg || spinning ? 'opacity-100' : 'opacity-0')}>
          {spinning ? 'Рулетка крутится…' : hoverMsg ?? '—'}
        </div>
      </div>
    </div>
  );
}
