import { useEffect, useMemo, useState } from 'react';
import { Search, X, SlidersHorizontal, Sparkles } from 'lucide-react';
import MarketFilters, { type Filters, loadFilters, saveFilters, countActive, EMPTY_FILTERS } from './MarketFilters';
import type { Skin } from '../lib/types';
import { useGame, useSkins } from '../lib/store';
import { audio } from '../lib/audio';
import { SkinCard, SectionTitle, StarBadge } from './ui';
import { VirtualGrid } from './VirtualGrid';
import { cn } from '../utils/cn';

type Sort = 'desc' | 'asc';

/** Полный маркет с поиском, фильтрами и виртуализацией */
export default function Market({ onBuy }: { onBuy: (s: Skin) => void }) {
  const { state } = useGame();
  const { catalog } = useSkins();

  const [f, setF] = useState<Filters>(loadFilters);
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState<Sort>('desc');

  const active = countActive(f);
  const setQuick = (patch: Partial<Filters>) => {
    const next = { ...f, ...patch };
    setF(next);
    saveFilters(next);
  };

  const list = useMemo(() => {
    let arr = catalog;
    if (f.types.length) arr = arr.filter((x) => f.types.includes(x.type ?? 'skin'));
    if (f.cats.length) arr = arr.filter((x) => x.cat && f.cats.includes(x.cat));
    if (f.rarities.length) arr = arr.filter((x) => f.rarities.includes(x.rarity));
    if (f.wears.length) arr = arr.filter((x) => f.wears.some((w) => x.name.includes(`(${w})`)) || !x.name.includes('('));
    if (f.stattrak === 'yes') arr = arr.filter((x) => x.name.includes('StatTrak'));
    if (f.stattrak === 'no') arr = arr.filter((x) => !x.name.includes('StatTrak'));
    if (f.souvenir === 'yes') arr = arr.filter((x) => x.name.includes('Souvenir'));
    if (f.souvenir === 'no') arr = arr.filter((x) => !x.name.includes('Souvenir'));
    if (f.min > 0) arr = arr.filter((x) => x.price >= f.min);
    if (f.max > 0) arr = arr.filter((x) => x.price <= f.max);
    if (f.q.trim()) {
      const t = f.q.trim().toLowerCase();
      arr = arr.filter((x) => x.name.toLowerCase().includes(t) || x.weapon.toLowerCase().includes(t));
    }
    return [...arr].sort((a, b) => (sort === 'desc' ? b.price - a.price : a.price - b.price));
  }, [catalog, f, sort]);

  /* сброс прокрутки при смене фильтра решается ключом ниже */
  const [gridKey, setGridKey] = useState(0);
  useEffect(() => setGridKey((k) => k + 1), [f, sort]);


  return (
    <div className="panel p-3">
      <SectionTitle
        icon={<Sparkles size={15} className="text-gold" />}
        title="Маркет"
        right={<span className="num rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] font-bold text-slate-400">{list.length}</span>}
      />

      <div className="relative mb-2">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          value={f.q}
          onChange={(e) => setQuick({ q: e.target.value })}
          placeholder="Поиск по названию…"
          className="input w-full py-2.5 pl-9 pr-8 text-[13px]"
        />
        {f.q && (
          <button onClick={() => setQuick({ q: '' })} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-500">
            <X size={14} />
          </button>
        )}
      </div>

      <div className="chip-row mb-2">
        <button className={cn('chip relative', active > 0 && 'on')} onClick={() => { audio.click(); setOpen(true); }}>
          <SlidersHorizontal size={12} className="mr-1" /> Фильтры
          {active > 0 && (
            <span className="num ml-1 grid h-4 min-w-4 place-items-center rounded-full bg-gold px-1 text-[9px] font-black text-black">
              {active}
            </span>
          )}
        </button>
        <button className="chip" onClick={() => { audio.click(); setSort((v) => (v === 'desc' ? 'asc' : 'desc')); }}>
          {sort === 'desc' ? 'Дорогие' : 'Дешёвые'}
        </button>
        {active > 0 && (
          <button className="chip" onClick={() => { audio.click(); setQuick(EMPTY_FILTERS); }}>Сбросить</button>
        )}
      </div>

      {open && (
        <MarketFilters value={f} onApply={setF} onClose={() => setOpen(false)} />
      )}

      {list.length === 0 ? (
        <div className="py-10 text-center text-[12px] text-slate-500">Ничего не найдено</div>
      ) : (
        <VirtualGrid
          key={gridKey}
          items={list}
          cols={2}
          rowHeight={160}
          gap={8}
          height={520}
          keyOf={(s, i) => `${s.id}-${i}`}
          render={(s) => (
            <SkinCard
              skin={s}
              compact
              badge={s.star ? <StarBadge /> : undefined}
              footer={
                <button
                  onClick={(e) => { e.stopPropagation(); onBuy(s); }}
                  className={cn(
                    'btn rounded-md px-2 py-1 text-[10px]',
                    state.balance >= s.price ? 'btn-gold-outline' : 'btn-ghost',
                  )}
                >
                  Купить
                </button>
              }
            />
          )}
        />
      )}
    </div>
  );
}
