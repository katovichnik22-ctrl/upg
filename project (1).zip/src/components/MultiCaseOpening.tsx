import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, RotateCcw, Banknote, Sparkles } from 'lucide-react';
import type { OwnedSkin, Skin } from '../lib/types';
import type { CaseDef } from '../lib/cases';
import { fmt } from '../lib/skins';
import { audio } from '../lib/audio';
import { SkinImage } from './ui';
import { cn } from '../utils/cn';

const GAP = 6;
const STRIP = 54;
const WIN_INDEX = 46;

/** ширина карточки зависит от числа одновременных лент */
function calcItemW(viewW: number, rows: number): number {
  const base = rows >= 5 ? 56 : rows >= 3 ? 68 : rows === 2 ? 80 : 96;
  return viewW < 360 ? Math.round(base * 0.86) : base;
}

export interface OpenedLine {
  /** предмет, который выпал */
  winner: OwnedSkin;
  /** лента прокрутки */
  pool: Skin[];
}

interface Props {
  caseDef: CaseDef;
  lines: OpenedLine[];
  fast: boolean;
  onSellAll: () => void;
  onKeep: () => void;
  onAgain: () => void;
  canAgain: boolean;
  totalCost: number;
}

export default function MultiCaseOpening({
  caseDef, lines, fast, onSellAll, onKeep, onAgain, canAgain, totalCost,
}: Props) {
  const rows = lines.length;
  const [done, setDone] = useState(false);
  const [itemW, setItemW] = useState(() =>
    calcItemW(typeof window !== 'undefined' ? window.innerWidth - 28 : 360, rows));

  const viewRef = useRef<HTMLDivElement>(null);
  const trackRefs = useRef<Array<HTMLDivElement | null>>([]);
  const rafs = useRef<number[]>([]);
  const started = useRef(false);
  const jitters = useRef<number[]>([]);
  const doneRef = useRef(false);

  /* каждая лента: случайные предметы + выигрыш на фиксированной позиции */
  const strips = useRef(
    lines.map((l) => {
      const arr: Skin[] = [];
      for (let i = 0; i < STRIP; i++) {
        arr.push(i === WIN_INDEX ? l.winner : l.pool[Math.floor(Math.random() * l.pool.length)] ?? l.winner);
      }
      return arr;
    }),
  );

  /* блокируем прокрутку фона */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  useLayoutEffect(() => {
    const view = viewRef.current;
    if (!view) return;
    const apply = () => {
      const w = view.clientWidth;
      if (w > 0) setItemW(calcItemW(w, rows));
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(view);
    return () => ro.disconnect();
  }, [rows]);

  /* прокрутка всех лент одновременно, с небольшой рассинхронизацией */
  useEffect(() => {
    if (!itemW || started.current) return;
    const view = viewRef.current;
    if (!view) return;
    started.current = true;

    const full = itemW + GAP;
    const centerOffset = view.clientWidth / 2 - itemW / 2;
    const baseDur = fast ? 2600 : 4200;

    lines.forEach((_, idx) => {
      const track = trackRefs.current[idx];
      if (!track) return;
      jitters.current[idx] = Math.round((Math.random() - 0.5) * (itemW * 0.45));
      const target = -(WIN_INDEX * full + jitters.current[idx] - centerOffset);
      const from = -(5 * full);
      const dur = baseDur + idx * 260;   // ленты останавливаются по очереди
      const t0 = performance.now();
      let lastTick = -1;

      const step = (t: number) => {
        const p = Math.min(1, (t - t0) / dur);
        const e = 1 - Math.pow(1 - p, 5);
        const x = from + (target - from) * e;
        track.style.transform = `translate3d(${x}px,0,0)`;
        const i = Math.floor(-x / full);
        if (i !== lastTick && idx === 0) { lastTick = i; audio.reelTick(); }
        if (p < 1) {
          rafs.current[idx] = requestAnimationFrame(step);
        } else if (idx === lines.length - 1) {
          doneRef.current = true;
          setDone(true);
          const best = lines.reduce((m, l) => Math.max(m, l.winner.price), 0);
          if (best >= totalCost * 3) audio.bigWin(); else audio.win();
        }
      };
      track.style.transform = `translate3d(${from}px,0,0)`;
      rafs.current[idx] = requestAnimationFrame(step);
    });

    return () => rafs.current.forEach(cancelAnimationFrame);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemW]);

  const cardH = itemW < 70 ? 86 : itemW < 86 ? 98 : 112;
  const imgH = Math.round(cardH * 0.46);
  const totalWon = lines.reduce((a, l) => a + l.winner.price, 0);
  const profit = totalWon - totalCost;

  const body = (
    <div
      className="fixed inset-0 z-[92] flex items-start justify-center overflow-y-auto overscroll-contain bg-black/88 p-2.5 pt-[max(10px,env(safe-area-inset-top))] pb-[max(10px,env(safe-area-inset-bottom))] backdrop-blur-sm sm:items-center"
    >
      <div ref={viewRef} className="my-auto w-full min-w-0 max-w-[840px]">
        {/* шапка */}
        <div className="mb-2 flex items-center justify-between gap-2 px-1">
          <div className="min-w-0">
            <div className="truncate font-display text-[12px] font-extrabold uppercase tracking-[0.12em] text-slate-200">
              {caseDef.name}
            </div>
            <div className="num text-[9px] font-bold uppercase tracking-wider text-slate-500">
              {done ? `${rows} предм. получено` : `открываем ${rows}…`}
            </div>
          </div>
          {done && (
            <button onClick={onKeep} className="shrink-0 rounded-lg bg-white/6 p-2 text-slate-400">
              <X size={17} />
            </button>
          )}
        </div>

        {/* ленты */}
        <div className="space-y-1.5">
          {lines.map((l, idx) => (
            <div
              key={idx}
              className="reel-mask relative w-full overflow-hidden rounded-xl border border-white/8 bg-[#0b0f18] py-1.5"
              style={done ? { boxShadow: `inset 0 0 36px -14px ${l.winner.color}` } : undefined}
            >
              {/* указатель */}
              <div className="pointer-events-none absolute left-1/2 top-0 z-20 h-full w-[2px] -translate-x-1/2 bg-gold/70" />
              <div className="pointer-events-none absolute left-1/2 top-0 z-20 -translate-x-1/2 border-x-[5px] border-t-[7px] border-x-transparent border-t-gold" />

              <div
                ref={(el) => { trackRefs.current[idx] = el; }}
                className="flex w-max will-change-transform"
                style={{ gap: GAP }}
              >
                {strips.current[idx].map((s, i) => (
                  <div
                    key={i}
                    style={{
                      width: itemW,
                      height: cardH,
                      background: `linear-gradient(180deg, ${s.color}18, transparent 65%), #141926`,
                      borderColor: `${s.color}55`,
                    }}
                    className="relative flex shrink-0 flex-col items-center justify-center overflow-hidden rounded-lg border p-1"
                  >
                    <span className="absolute inset-x-0 top-0 h-[2.5px]" style={{ background: s.color }} />
                    <div className="flex w-full items-center justify-center" style={{ height: imgH }}>
                      <SkinImage skin={s} className="h-full w-full" />
                    </div>
                    <div className="w-full truncate text-center text-[8px] font-bold leading-tight"
                      style={{ color: s.color }}>
                      {s.name.replace('★ ', '').split(' | ').slice(1).join(' | ')
                        || s.name.replace('★ ', '')}
                    </div>
                    <div className="num price truncate text-[8px] font-extrabold">{fmt(s.price)}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* итоги */}
        {done && (
          <div className="pop-in panel mt-2 p-3">
            <div className="mb-2 grid grid-cols-3 gap-1.5">
              {[
                ['Потрачено', fmt(totalCost)],
                ['Получено', fmt(totalWon)],
                ['Итог', `${profit >= 0 ? '+' : '−'}${fmt(Math.abs(profit))}`],
              ].map(([k, v], i) => (
                <div key={k} className="panel-inset px-1 py-1.5 text-center">
                  <div className={cn('num truncate text-[12px] font-extrabold',
                    i === 2 && (profit >= 0 ? 'text-emerald-300' : 'text-rose-300'))}>
                    {v}
                  </div>
                  <div className="text-[8px] uppercase tracking-wider text-slate-500">{k}</div>
                </div>
              ))}
            </div>

            {/* список выпавшего */}
            <div className="max-h-[132px] space-y-1 overflow-y-auto">
              {lines.map((l, i) => (
                <div key={i} className="panel-inset flex items-center gap-2 px-2 py-1.5">
                  <SkinImage skin={l.winner} className="h-7 w-10 shrink-0" />
                  <span className="min-w-0 flex-1 truncate text-[10px] font-bold"
                    style={{ color: l.winner.color }}>
                    {l.winner.name.replace('★ ', '')}
                  </span>
                  <span className="num price shrink-0 text-[10px] font-extrabold">{fmt(l.winner.price)}</span>
                </div>
              ))}
            </div>

            <div className="mt-2 grid grid-cols-2 gap-2">
              <button onClick={onKeep} className="btn btn-gold py-2.5 text-[12px]">
                <Sparkles size={14} /> Забрать всё
              </button>
              <button onClick={onSellAll} className="btn btn-ghost py-2.5 text-[12px]">
                <Banknote size={14} />
                <span className="num truncate">{fmt(Math.round(totalWon * 0.94))}</span>
              </button>
            </div>
            <button onClick={onAgain} disabled={!canAgain}
              className="btn btn-ghost mt-2 w-full py-2.5 text-[11.5px] active:bg-gold/12!">
              <RotateCcw size={13} /> Открыть ещё {rows} · {fmt(totalCost)}
            </button>
          </div>
        )}
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(body, document.body);
}
