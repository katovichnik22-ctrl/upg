import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { audio } from '../lib/audio';
import { forcedOutcome } from '../admin/adminCore';

export interface WheelHandle {
  /** The wheel draws the zone, lands the pointer, then reports the result by
     MEASURING where the pointer stopped against that zone. Pointer on the green
     arc = win. Nothing else decides. */
  spin: (chanceAtSpin: number) => void;
  readonly spinning: boolean;
}

interface Props {
  chance: number; // 0..100
  duration: number; // ms
  onEnd: (win: boolean) => void;
}

const TAU = Math.PI * 2;
const BOTTOM = Math.PI / 2;
const SEGS = 84;

const GRAD: Array<[number, [number, number, number]]> = [
  [0, [163, 245, 158]],
  [0.5, [51, 214, 110]],
  [1, [18, 138, 66]],
];

function zoneColor(t: number): string {
  const x = Math.min(1, Math.max(0, t));
  for (let i = 1; i < GRAD.length; i++) {
    if (x <= GRAD[i][0]) {
      const [t0, c0] = GRAD[i - 1];
      const [t1, c1] = GRAD[i];
      const p = (x - t0) / (t1 - t0);
      return `rgb(${Math.round(c0[0] + (c1[0] - c0[0]) * p)},${Math.round(c0[1] + (c1[1] - c0[1]) * p)},${Math.round(c0[2] + (c1[2] - c0[2]) * p)})`;
    }
  }
  return 'rgb(18,138,66)';
}

const wrap = (a: number): number => {
  let x = a % TAU;
  if (x > Math.PI) x -= TAU;
  if (x < -Math.PI) x += TAU;
  return x;
};

const Wheel = forwardRef<WheelHandle, Props>(({ chance, duration, onEnd }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  /** тонкая SVG-стрелка поверх канваса */
  const pointerRef = useRef<SVGSVGElement>(null);
  /** the dial (ring, zone, ticks) is rendered once into this offscreen canvas
      and simply blitted each frame — the expensive shadow work happens only
      when the size or the chance actually changes */
  const dialRef = useRef<HTMLCanvasElement | null>(null);
  const dialKeyRef = useRef('');

  const sizeRef = useRef(0);
  const dprRef = useRef(1);
  const ptrRef = useRef(BOTTOM + Math.PI);
  const trailRef = useRef<number[]>([]);
  const lastChanceRef = useRef(chance);
  const fadeRef = useRef({ alpha: 0, outT: 0, fading: false });
  const chancePropRef = useRef(chance);
  const zoneRef = useRef(chance);
  const durRef = useRef(duration);
  const lastTickRef = useRef(0);
  const stRef = useRef({ spinning: false, start: 0, from: 0, to: 0, dur: 4000, settled: false });
  const onEndRef = useRef(onEnd);

  /** rAF is only alive while something actually moves */
  const runningRef = useRef(false);
  const rafRef = useRef(0);
  const kickRef = useRef<() => void>(() => {});

  chancePropRef.current = chance;
  if (!stRef.current.spinning) zoneRef.current = chance;
  durRef.current = duration;
  onEndRef.current = onEnd;

  useImperativeHandle(ref, () => ({
    get spinning() { return stRef.current.spinning; },
    spin(chanceAtSpin: number) {
      const st = stRef.current;
      if (st.spinning) return;
      /* админ-переопределение: режим бога и форс исхода */
      const forced = forcedOutcome();
      const win = forced !== null ? forced : Math.random() * 100 < chanceAtSpin;
      const sweep = Math.max(0.002, Math.min(0.998, chanceAtSpin / 100)) * TAU;
      const loseArc = TAU - sweep;

      const arc = win ? sweep : loseArc;
      const margin = Math.min(arc * 0.2, 0.12);
      const t = margin + Math.random() * Math.max(0.001, arc - margin * 2);
      const targetOffset = wrap(win ? -sweep / 2 + t : sweep / 2 + t);

      const cur = ptrRef.current;
      const d0 = wrap(cur - BOTTOM);
      const delta = ((((targetOffset - d0) % TAU) + TAU) % TAU);
      const turns = 5.5 + Math.random() * 2;
      st.from = cur;
      st.to = cur + turns * TAU + delta;
      st.start = performance.now();
      st.dur = durRef.current;
      st.spinning = true;
      st.settled = false;

      trailRef.current = [];
      fadeRef.current.alpha = 1;
      fadeRef.current.fading = false;
      lastChanceRef.current = chanceAtSpin;
      zoneRef.current = chanceAtSpin;
      kickRef.current();
    },
  }), []);

  /* ---------------- offscreen dial ---------------- */

  const buildDial = (w: number, dpr: number, sweep: number) => {
    let cv = dialRef.current;
    if (!cv) {
      cv = document.createElement('canvas');
      dialRef.current = cv;
    }
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(w * dpr);
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, w);

    const cx = w / 2;
    const cy = w / 2;
    const lw = Math.max(20, w * 0.075);
    const R = w / 2 - lw / 2 - Math.max(16, w * 0.045);

    ctx.beginPath();
    ctx.arc(cx, cy, R + lw / 2 + 9, 0, TAU);
    ctx.fillStyle = '#10141d';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx, cy, R + lw / 2 + 6, 0, TAU);
    ctx.strokeStyle = 'rgba(255,255,255,.06)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    /* losing segments */
    const seg = TAU / SEGS;
    ctx.lineCap = 'butt';
    ctx.lineWidth = lw;
    for (let i = 0; i < SEGS; i++) {
      const a = i * seg + seg / 2;
      const rel = wrap(a - BOTTOM);
      const edgeDist = Math.abs(rel) - sweep / 2;
      if (edgeDist <= 0) continue;
      ctx.strokeStyle = edgeDist < seg * 3 ? '#3d2130' : '#1b212d';
      ctx.beginPath();
      ctx.arc(cx, cy, R, a - seg * 0.31, a + seg * 0.31);
      ctx.stroke();
    }

    /* win zone — one exact continuous arc */
    const half = sweep / 2;
    const parts = Math.max(8, Math.ceil(sweep / (seg * 0.5)));
    ctx.save();
    ctx.shadowColor = 'rgba(74,222,128,.55)';
    ctx.shadowBlur = 14;
    for (let i = 0; i < parts; i++) {
      const a0 = BOTTOM - half + (sweep * i) / parts;
      const a1 = BOTTOM - half + (sweep * (i + 1)) / parts;
      const mid = (a0 + a1) / 2;
      ctx.strokeStyle = zoneColor(Math.min(1, Math.abs(mid - BOTTOM) / (half || 1)));
      ctx.beginPath();
      ctx.arc(cx, cy, R, a0 - 0.0006, a1 + 0.0006);
      ctx.stroke();
    }
    ctx.restore();

    /* separator rings */
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#0d111a';
    ctx.beginPath();
    ctx.arc(cx, cy, R - lw / 2 - 2, 0, TAU);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, R + lw / 2 + 2, 0, TAU);
    ctx.stroke();

    /* tick ruler */
    const rIn = R + lw / 2 + 13;
    for (let i = 0; i < 72; i++) {
      const a = (i / 72) * TAU;
      const major = i % 18 === 0;
      const sub = i % 6 === 0;
      const len = major ? 9 : sub ? 6 : 3.5;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * rIn, cy + Math.sin(a) * rIn);
      ctx.lineTo(cx + Math.cos(a) * (rIn + len), cy + Math.sin(a) * (rIn + len));
      ctx.lineWidth = major ? 1.7 : 1;
      ctx.strokeStyle = major ? 'rgba(203,213,245,.4)' : 'rgba(148,163,216,.18)';
      ctx.stroke();
    }
  };

  /* ---------------- resize ---------------- */

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv || !cv.parentElement) return;
    const parent = cv.parentElement;
    const apply = () => {
      const w = parent.clientWidth;
      if (!w) return;
      const cap = w < 420 ? 1.6 : 2;
      const dpr = Math.min(cap, window.devicePixelRatio || 1);
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(w * dpr);
      cv.style.height = `${w}px`;
      sizeRef.current = w;
      dprRef.current = dpr;
      dialKeyRef.current = ''; // force dial rebuild
      kickRef.current();
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(parent);
    return () => ro.disconnect();
  }, []);

  /* ---------------- render loop (on demand) ---------------- */

  useEffect(() => {
    const draw = (ptr: number) => {
      const cv = canvasRef.current;
      const w = sizeRef.current;
      if (!cv || !w) return;
      const ctx = cv.getContext('2d');
      if (!ctx) return;
      const dpr = dprRef.current;
      const sweep = Math.max(0.002, Math.min(0.998, zoneRef.current / 100)) * TAU;

      /* rebuild the dial only when geometry or zone actually changed */
      const key = `${w}|${dpr}|${sweep.toFixed(5)}`;
      if (key !== dialKeyRef.current) {
        buildDial(w, dpr, sweep);
        dialKeyRef.current = key;
      }

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, w);
      if (dialRef.current) ctx.drawImage(dialRef.current, 0, 0, w, w);

      const cx = w / 2;
      const cy = w / 2;
      const lw = Math.max(20, w * 0.075);
      const R = w / 2 - lw / 2 - Math.max(16, w * 0.045);
      const pa = fadeRef.current.alpha;
      if (pa <= 0.002) return;

      /* comet trail — cheap: no shadows, sampled */
      const tr = trailRef.current;
      if (tr.length > 2) {
        ctx.save();
        ctx.globalAlpha = pa;
        ctx.lineCap = 'round';
        for (let i = 2; i < tr.length; i += 2) {
          if (tr[i] <= tr[i - 2]) continue;
          const p = i / (tr.length - 1);
          ctx.beginPath();
          ctx.arc(cx, cy, R, tr[i - 2], tr[i]);
          ctx.lineWidth = lw * (0.22 + 0.68 * p);
          ctx.strokeStyle = `rgba(246,196,69,${(0.05 + 0.3 * p).toFixed(3)})`;
          ctx.stroke();
        }
        ctx.restore();
      }

      /* Указатель рисуется отдельным SVG-слоем (см. ниже), здесь только
         мягкое гало, чтобы место остановки читалось на кольце */
      const ux = Math.cos(ptr);
      const uy = Math.sin(ptr);
      const settled = stRef.current.settled && !stRef.current.spinning;
      let glow = 'rgba(246,196,69,';
      if (settled) {
        glow = Math.abs(wrap(ptr - BOTTOM)) <= sweep / 2 ? 'rgba(74,222,128,' : 'rgba(255,64,96,';
      }

      ctx.save();
      ctx.globalAlpha = pa;
      const hx = cx + ux * R;
      const hy = cy + uy * R;
      const halo = ctx.createRadialGradient(hx, hy, 0, hx, hy, 34);
      halo.addColorStop(0, `${glow}0.42)`);
      halo.addColorStop(1, `${glow}0)`);
      ctx.beginPath();
      ctx.arc(hx, hy, 34, 0, TAU);
      ctx.fillStyle = halo;
      ctx.fill();
      ctx.restore();

      /* обновляем SVG-стрелку без ре-рендера React */
      const svg = pointerRef.current;
      if (svg) {
        const deg = (ptr * 180) / Math.PI + 90; // 0° = вверх
        svg.style.opacity = String(pa);
        svg.style.transform = `rotate(${deg}deg)`;
        svg.style.setProperty('--pc', settled
          ? (Math.abs(wrap(ptr - BOTTOM)) <= sweep / 2 ? '#4ade80' : '#ff4060')
          : '#f6c445');
      }
    };

    const frame = (t: number) => {
      const st = stRef.current;
      let busy = false;

      if (st.spinning) {
        busy = true;
        const p = Math.min(1, (t - st.start) / st.dur);
        const e = 1 - Math.pow(1 - p, 5);
        ptrRef.current = st.from + (st.to - st.from) * e;
        const seg = Math.floor(ptrRef.current / (TAU / SEGS));
        if (seg !== lastTickRef.current) {
          lastTickRef.current = seg;
          audio.tick();
        }
        if (p >= 1) {
          ptrRef.current = st.to;
          st.spinning = false;
          st.settled = true;
          const settleSweep = Math.max(0.002, Math.min(0.998, zoneRef.current / 100)) * TAU;
          const landedInGreen = Math.abs(wrap(st.to - BOTTOM)) <= settleSweep / 2;
          setTimeout(() => onEndRef.current(landedInGreen), 130);
        }
      } else if (chancePropRef.current !== lastChanceRef.current) {
        lastChanceRef.current = chancePropRef.current;
        fadeRef.current.fading = true;
        fadeRef.current.outT = t;
      }

      if (fadeRef.current.fading) {
        busy = true;
        fadeRef.current.alpha = Math.max(0, 1 - (t - fadeRef.current.outT) / 260);
        if (fadeRef.current.alpha === 0) fadeRef.current.fading = false;
      }

      if (st.spinning) {
        trailRef.current.push(ptrRef.current);
        while (trailRef.current.length > 2 && ptrRef.current - trailRef.current[0] > 1.35) {
          trailRef.current.shift();
        }
        if (trailRef.current.length > 48) trailRef.current.shift();
      } else if (trailRef.current.length > 0) {
        busy = true;
        trailRef.current.splice(0, 3);
      }

      draw(ptrRef.current);

      if (busy) {
        rafRef.current = requestAnimationFrame(frame);
      } else {
        runningRef.current = false; // idle: stop burning frames
      }
    };

    kickRef.current = () => {
      if (runningRef.current) return;
      runningRef.current = true;
      rafRef.current = requestAnimationFrame(frame);
    };

    kickRef.current();
    return () => {
      cancelAnimationFrame(rafRef.current);
      runningRef.current = false;
    };
  }, []);

  /* repaint when the chance prop changes while idle */
  useEffect(() => { kickRef.current(); }, [chance]);

  return (
    <div className="relative w-full">
      <canvas ref={canvasRef} className="block h-auto w-full" />
      {/* тонкий указатель: линия 2px + маленькое остриё, центр строго по оси */}
      <svg
        ref={pointerRef}
        viewBox="0 0 100 100"
        className="pointer-events-none absolute inset-0 h-full w-full"
        style={{ transformOrigin: '50% 50%', opacity: 0, color: 'var(--pc, #f6c445)' }}
      >
        <g stroke="currentColor" fill="currentColor">
          <line
            x1="50" y1="8.5" x2="50" y2="26"
            strokeWidth="0.7"
            strokeLinecap="round"
            style={{ filter: 'drop-shadow(0 0 1.2px currentColor)' }}
          />
          <path d="M50 6.6l2 4.2h-4z" />
          <circle cx="50" cy="27.4" r="1.15" />
        </g>
      </svg>
    </div>
  );
});

Wheel.displayName = 'Wheel';
export default Wheel;
