import { useState } from 'react';
import {
  User, Trophy, TrendingUp, Disc3, Package, History as HistoryIcon, Pencil, Check,
  ArrowUpCircle, ShoppingBag, Gift, Banknote, PackageOpen, Boxes, Crosshair, Dices,
  Users, UserPlus, LogIn, Trash2, TriangleAlert, MousePointerClick,
} from 'lucide-react';
import { useGame, useEnrich, type Economy } from '../lib/store';
import EconomyPicker from './EconomyPicker';
import { levelInfo } from '../lib/level';
import { fmt, fmtSign } from '../lib/skins';
import { audio } from '../lib/audio';
import { SectionTitle, SkinCard, EmptyState, StarBadge } from './ui';
import { cn } from '../utils/cn';
import type { HistoryItem } from '../lib/types';

const KIND_ICON: Record<HistoryItem['kind'], typeof ArrowUpCircle> = {
  upgrade: ArrowUpCircle,
  roulette: Disc3,
  shop: ShoppingBag,
  bonus: Gift,
  sell: Banknote,
  case: PackageOpen,
  game: Dices,
};

function InvCard({ uid }: { uid: string }) {
  const { state, sellItem, toast } = useGame();
  const raw = state.inventory.find((i) => i.uid === uid);
  const item = useEnrich(raw);
  if (!item) return null;
  return (
    <SkinCard
      skin={item}
      compact
      badge={item.star ? <StarBadge /> : undefined}
      footer={
        <button
          onClick={(e) => {
            e.stopPropagation();
            sellItem(item.uid);
            toast('Предмет продан', 'info', `+${fmt(Math.max(1, Math.round(item.price * 0.94)))}`);
          }}
          className="btn btn-ghost rounded-md px-1.5 py-0.5 text-[9.5px] hover:bg-rose-500/20! hover:text-rose-300!"
          title="Продать за 94%"
        >
          Продать
        </button>
      }
    />
  );
}

/* ---------------- profiles manager ---------------- */

function ProfilesPanel() {
  const { profiles, activeProfile, switchProfile, createProfile, deleteProfile, toast } = useGame();
  const [adding, setAdding] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const add = (name: string, economy: Economy) => {
    createProfile(name, economy);
    setAdding(false);
    toast('Профиль создан', 'win', name);
  };

  return (
    <div className="panel p-5">
      <SectionTitle
        icon={<Users size={15} className="text-gold" />}
        title={`Профили · ${profiles.length}`}
        right={
          !adding ? (
            <button
              className="btn btn-ghost px-3 py-1.5 text-[11px] hover:bg-gold/12!"
              onClick={() => { audio.click(); setAdding(true); }}
            >
              <UserPlus size={13} /> Создать
            </button>
          ) : undefined
        }
      />

      {adding && (
        <EconomyPicker
          title="Новый профиль"
          onDone={add}
          onCancel={() => setAdding(false)}
        />
      )}

      <div className="grid gap-2 sm:grid-cols-2">
        {profiles.map((p) => {
          const active = p.id === activeProfile;
          const hue = Math.abs([...p.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360;
          const armed = confirmId === p.id;
          return (
            <div
              key={p.id}
              className={cn(
                'panel-inset flex items-center gap-3 px-3 py-2.5 transition-colors',
                active && 'border-gold/45 bg-gold/6',
              )}
            >
              <div
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[14px] font-extrabold text-white ring-1 ring-white/15"
                style={{ background: `linear-gradient(135deg, hsl(${hue} 65% 52%), hsl(${(hue + 60) % 360} 65% 38%))` }}
              >
                {p.name[0]?.toUpperCase() ?? '?'}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[12.5px] font-bold">{p.name}</div>
                <div className="text-[9.5px] uppercase tracking-wider text-slate-500">
                  {active ? 'активный' : new Date(p.created).toLocaleDateString('ru-RU')}
                </div>
              </div>
              {!active && (
                <button
                  className="btn btn-ghost px-2.5 py-1.5 text-[10.5px] hover:bg-gold/12!"
                  onClick={() => { audio.click(); switchProfile(p.id); toast('Профиль переключён', 'info', p.name); }}
                >
                  <LogIn size={12} /> Войти
                </button>
              )}
              {profiles.length > 1 && (
                <button
                  className={cn(
                    'rounded-lg p-1.5 transition-colors',
                    armed ? 'bg-rose-500/25 text-rose-300' : 'bg-white/5 text-slate-500 hover:text-rose-300',
                  )}
                  title={armed ? 'Нажмите ещё раз для удаления' : 'Удалить профиль'}
                  onClick={() => {
                    audio.click();
                    if (armed) {
                      deleteProfile(p.id);
                      setConfirmId(null);
                      toast('Профиль удалён', 'info', p.name);
                    } else {
                      setConfirmId(p.id);
                      setTimeout(() => setConfirmId((c) => (c === p.id ? null : c)), 3200);
                    }
                  }}
                >
                  {armed ? <TriangleAlert size={13} /> : <Trash2 size={13} />}
                </button>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-2 text-[10.5px] text-slate-600">
        У каждого профиля свой баланс, инвентарь и статистика
      </div>
    </div>
  );
}

export default function Profile() {
  const { state, sellAll, setName, toast } = useGame();
  const [editing, setEditing] = useState(false);
  const [nameDraft, setNameDraft] = useState(state.name);

  const s = state.stats;
  const winrate = s.upgrades > 0 ? Math.round((s.upgradeWins / s.upgrades) * 100) : 0;
  const lvl = levelInfo(s.wagered);
  const level = lvl.level;
  const lvlProg = lvl.progress;
  const invTotal = state.inventory.reduce((a, i) => a + i.price, 0);
  const hue = Math.abs([...state.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360;

  const stats = [
    { icon: ArrowUpCircle, label: 'Апгрейдов', value: String(s.upgrades), sub: `побед: ${s.upgradeWins}`, color: 'text-blue-300' },
    { icon: TrendingUp, label: 'Винрейт', value: `${winrate}%`, sub: 'апгрейдер', color: 'text-emerald-300' },
    { icon: Disc3, label: 'Рулетка', value: String(s.rouletteSpins), sub: `побед: ${s.rouletteWins}`, color: 'text-rose-300' },
    { icon: Trophy, label: 'Рекорд выигрыша', value: fmt(s.bestWin), sub: 'за одну игру', color: 'text-amber-300' },
    { icon: Crosshair, label: 'Всего поставлено', value: fmt(s.wagered), sub: 'за всё время', color: 'text-violet-300' },
    { icon: Dices, label: 'Игр в казино', value: String(s.gamesPlayed), sub: `побед: ${s.gameWins}`, color: 'text-pink-300' },
    { icon: PackageOpen, label: 'Кейсов открыто', value: String(s.casesOpened), sub: 'в магазине', color: 'text-sky-300' },
    { icon: Banknote, label: 'Пополнено', value: fmt(s.deposited), sub: 'демо-платежи', color: 'text-gold' },
  ];

  return (
    <div className="fade-up mx-auto max-w-[1100px] space-y-4">
      {/* header */}
      <div className="panel relative overflow-hidden p-5">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-indigo-500/10 to-transparent" />
        <div className="flex flex-wrap items-center gap-4">
          <div
            className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-extrabold text-white ring-2 ring-white/20"
            style={{ background: `linear-gradient(135deg, hsl(${hue} 70% 55%), hsl(${(hue + 60) % 360} 70% 40%))` }}
          >
            {state.name[0]?.toUpperCase() ?? <User />}
          </div>
          <div className="min-w-0">
            {editing ? (
              <div className="flex items-center gap-2">
                <input
                  autoFocus
                  value={nameDraft}
                  maxLength={18}
                  onChange={(e) => setNameDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') { setName(nameDraft); setEditing(false); audio.click(); }
                  }}
                  className="input px-3 py-1.5 text-lg font-bold"
                />
                <button className="btn btn-green h-9 w-9" onClick={() => { setName(nameDraft); setEditing(false); audio.click(); }}>
                  <Check size={16} />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <h1 className="truncate font-display text-xl font-extrabold">{state.name}</h1>
                <button
                  onClick={() => { setNameDraft(state.name); setEditing(true); audio.click(); }}
                  className="rounded-lg bg-white/5 p-1.5 text-slate-400 transition-colors hover:text-white"
                >
                  <Pencil size={13} />
                </button>
              </div>
            )}
            <div className="mt-1 flex items-center gap-2 text-[11px] font-bold text-slate-400">
              <span className="rounded-md bg-gold/12 px-2 py-0.5 text-gold ring-1 ring-gold/25">Уровень {level}</span>
              <span className={cn(
                'flex items-center gap-1 rounded-md px-2 py-0.5 ring-1',
                'bg-emerald-400/12 text-emerald-300 ring-emerald-400/25',
              )}>
                <MousePointerClick size={10} />
                Честный
              </span>
              <span className="num">Инвентарь: {fmt(invTotal)}</span>
            </div>
          </div>
          <div className="ml-auto w-full min-w-[200px] sm:w-60">
            <div className="mb-1 flex justify-between text-[10px] font-bold uppercase tracking-wider text-slate-500">
              <span>До {level + 1} уровня</span>
              <span className="num">{Math.round(lvlProg * 100)}%</span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-white/8">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#ffd964] to-[#e8a013] shadow-[0_0_12px_rgba(246,196,69,.6)] transition-all duration-500"
                style={{ width: `${Math.max(3, lvlProg * 100)}%` }}
              />
            </div>
            <div className="num mt-1 text-right text-[9.5px] text-slate-600">
              ещё {fmt(lvl.remaining)} оборота
            </div>
          </div>
        </div>
      </div>

      <ProfilesPanel />

      {/* stats grid */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
        {stats.map((st) => (
          <div key={st.label} className="panel p-4">
            <st.icon size={17} className={st.color} />
            <div className="num mt-2.5 truncate font-display text-[17px] font-extrabold">{st.value}</div>
            <div className="mt-0.5 text-[10.5px] font-bold uppercase tracking-wider text-slate-500">{st.label}</div>
            <div className="text-[10px] text-slate-600">{st.sub}</div>
          </div>
        ))}
      </div>

      {/* inventory */}
      <div className="panel p-5">
        <SectionTitle
          icon={<Package size={15} className="text-blue-300" />}
          title={`Инвентарь · ${state.inventory.length} предм.`}
          right={
            state.inventory.length > 0 ? (
              <button
                className="btn btn-ghost px-3 py-1.5 text-[11px] hover:bg-rose-500/15! hover:text-rose-300!"
                onClick={() => {
                  sellAll();
                  toast('Все предметы проданы', 'info', 'Возврат 94% стоимости');
                }}
              >
                Продать всё · {fmt(state.inventory.reduce((a, i) => a + Math.max(1, Math.round(i.price * 0.94)), 0))}
              </button>
            ) : undefined
          }
        />
        {state.inventory.length === 0 ? (
          <EmptyState
            icon={<Boxes size={26} />}
            text="Инвентарь пуст"
            sub="Выигрывайте скины в апгрейдере или покупайте в магазине"
          />
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6">
            {state.inventory.map((i) => <InvCard key={i.uid} uid={i.uid} />)}
          </div>
        )}
      </div>

      {/* history */}
      <div className="panel p-5">
        <SectionTitle icon={<HistoryIcon size={15} className="text-slate-300" />} title="История операций" />
        {state.history.length === 0 ? (
          <EmptyState icon={<HistoryIcon size={26} />} text="История пуста" sub="Здесь будут ваши апгрейды, ставки и покупки" />
        ) : (
          <div className="space-y-1.5">
            {state.history.slice(0, 25).map((h) => {
              const Icon = KIND_ICON[h.kind];
              return (
                <div key={h.id} className="panel-inset flex items-center gap-3 px-3.5 py-2.5">
                  <span className={cn(
                    'grid h-8 w-8 shrink-0 place-items-center rounded-lg',
                    h.success === true && 'bg-emerald-400/12 text-emerald-300',
                    h.success === false && 'bg-rose-400/12 text-rose-300',
                    h.success === undefined && 'bg-blue-400/12 text-blue-300',
                  )}>
                    <Icon size={15} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12.5px] font-semibold">{h.text}</div>
                    <div className="num text-[10px] text-slate-500">
                      {new Date(h.time).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                  <span className={cn('num text-[13px] font-extrabold', h.amount >= 0 ? 'text-emerald-300' : 'text-rose-300')}>
                    {fmtSign(h.amount)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
