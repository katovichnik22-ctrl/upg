import { useEffect, useRef, useState } from 'react';
import { Users, User, History, Pencil, Coins } from 'lucide-react';
import {
  freshShoe, score, isSoft, isBlackjack, type Card,
} from '../../lib/deck';
import { PlayingCard } from './PlayingCard';
import { GameShell } from './common';
import { useGame } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

type Mode = 'single' | 'hotseat';
type Phase = 'bets' | 'play' | 'dealer' | 'done';

interface Seat {
  name: string;
  /** сессионный кошелёк (у первого игрока — общий баланс) */
  wallet: number;
  bet: number;
  hand: Card[];
  done: boolean;
  doubled: boolean;
  surrendered: boolean;
  result: string;
  payout: number;
}

const newSeat = (name: string, wallet: number): Seat => ({
  name, wallet, bet: 0, hand: [], done: false,
  doubled: false, surrendered: false, result: '', payout: 0,
});

const CHIPS = [10, 50, 100, 500];
/** Дилер добирает до 17 и стоит на мягкой 17 (S17) */
const DEALER_STANDS = 17;

export default function BlackjackTable() {
  const { state, adjust, log, addStats, toast } = useGame();

  const [mode, setMode] = useState<Mode>('single');
  const [phase, setPhase] = useState<Phase>('bets');
  const [seats, setSeats] = useState<Seat[]>([newSeat('Игрок 1', 0)]);
  const [active, setActive] = useState(0);
  const [dealer, setDealer] = useState<Card[]>([]);
  const [holeShown, setHoleShown] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [editing, setEditing] = useState<number | null>(null);
  const [p2Buyin, setP2Buyin] = useState(1000);

  const shoe = useRef<Card[]>([]);
  const busy = useRef(false);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(window.clearTimeout), []);

  /** Игрок 1 ставит с основного баланса, Игрок 2 — со своего кошелька */
  const walletOf = (i: number) => (i === 0 ? state.balance : seats[i]?.wallet ?? 0);

  const setSeat = (i: number, patch: Partial<Seat>) =>
    setSeats((s) => s.map((x, idx) => (idx === i ? { ...x, ...patch } : x)));

  const switchMode = (m: Mode) => {
    if (phase !== 'bets') return;
    audio.click();
    setMode(m);
    setSeats(m === 'single'
      ? [newSeat('Игрок 1', 0)]
      : [newSeat('Игрок 1', 0), newSeat('Игрок 2', seats[1]?.wallet ?? 0)]);
    setActive(0);
  };

  /* ---------- ставки ---------- */
  const addChip = (i: number, v: number) => {
    if (phase !== 'bets') return;
    if (walletOf(i) < seats[i].bet + v) {
      toast('Недостаточно фишек', 'lose', i === 0 ? 'Пополните баланс' : 'Докупите фишки игроку 2');
      return;
    }
    audio.blip(1180, 0.03, 'square', 0.05);
    setSeat(i, { bet: seats[i].bet + v });
  };

  const clearBet = (i: number) => { audio.click(); setSeat(i, { bet: 0 }); };

  const buyinP2 = () => {
    const v = Math.round(p2Buyin);
    if (state.balance < v) { toast('Недостаточно средств', 'lose', 'На основном балансе'); return; }
    adjust(-v);
    setSeat(1, { wallet: (seats[1]?.wallet ?? 0) + v });
    audio.coin();
    toast('Фишки переданы', 'win', `Игрок 2 получил ${fmt(v)}`);
  };

  const cashoutP2 = () => {
    const v = seats[1]?.wallet ?? 0;
    if (v <= 0) return;
    adjust(v);
    setSeat(1, { wallet: 0 });
    audio.coin();
    toast('Фишки возвращены', 'win', `+${fmt(v)} на баланс`);
  };

  /** списание ставки с нужного кошелька */
  const takeBet = (i: number, amount: number) => {
    if (i === 0) adjust(-amount);
    else setSeats((s) => s.map((x, idx) => (idx === i ? { ...x, wallet: x.wallet - amount } : x)));
  };
  /** зачисление выплаты */
  const payTo = (i: number, amount: number) => {
    if (amount <= 0) return;
    if (i === 0) adjust(amount);
    else setSeats((s) => s.map((x, idx) => (idx === i ? { ...x, wallet: x.wallet + amount } : x)));
  };

  /* ---------- раздача ---------- */
  const deal = () => {
    if (busy.current) return;
    const playing = seats.filter((s) => s.bet > 0);
    if (playing.length === 0) { toast('Нет ставок', 'info', 'Поставьте фишки'); return; }

    busy.current = true;
    audio.click();
    if (shoe.current.length < 60) shoe.current = freshShoe();

    const next = seats.map((s) => ({
      ...s, hand: [] as Card[], done: s.bet === 0,
      doubled: false, surrendered: false, result: '', payout: 0,
    }));
    for (const s of next) if (s.bet > 0) takeBet(seats.indexOf(seats[next.indexOf(s)]), s.bet);

    /* по две карты каждому играющему, дилеру — открытая и закрытая */
    for (let round = 0; round < 2; round++) {
      for (const s of next) if (s.bet > 0) s.hand.push(shoe.current.pop()!);
    }
    const d = [shoe.current.pop()!, shoe.current.pop()!];

    setSeats(next);
    setDealer(d);
    setHoleShown(false);
    audio.blip(520, 0.04, 'triangle', 0.06);

    /* блэкджеки закрывают руку сразу */
    const first = next.findIndex((s) => s.bet > 0 && !isBlackjack(s.hand));
    if (first === -1) {
      setPhase('dealer');
      timers.current.push(window.setTimeout(() => dealerPlay(next, d), 600));
    } else {
      setActive(first);
      setPhase('play');
      busy.current = false;
    }
  };

  /* ---------- ход игрока ---------- */
  const nextSeat = (list: Seat[], from: number) => {
    for (let i = from + 1; i < list.length; i++) {
      if (list[i].bet > 0 && !list[i].done && !isBlackjack(list[i].hand)) return i;
    }
    return -1;
  };

  const advance = (list: Seat[], cur: number) => {
    const nxt = nextSeat(list, cur);
    if (nxt >= 0) { setActive(nxt); return; }
    setPhase('dealer');
    timers.current.push(window.setTimeout(() => dealerPlay(list, dealer), 500));
  };

  const hit = () => {
    if (phase !== 'play') return;
    audio.blip(560, 0.035, 'triangle', 0.06);
    const card = shoe.current.pop()!;
    const list = seats.map((s, i) => (i === active ? { ...s, hand: [...s.hand, card] } : s));
    setSeats(list);
    if (score(list[active].hand) >= 21) {
      list[active].done = true;
      timers.current.push(window.setTimeout(() => advance(list, active), 350));
    }
  };

  const stand = () => {
    if (phase !== 'play') return;
    audio.click();
    const list = seats.map((s, i) => (i === active ? { ...s, done: true } : s));
    setSeats(list);
    advance(list, active);
  };

  const double = () => {
    if (phase !== 'play') return;
    const s = seats[active];
    if (s.hand.length !== 2) return;
    if (walletOf(active) < s.bet) { toast('Не хватает на удвоение', 'lose'); return; }
    audio.coin();
    takeBet(active, s.bet);
    const card = shoe.current.pop()!;
    const list = seats.map((x, i) => (i === active
      ? { ...x, bet: x.bet * 2, doubled: true, hand: [...x.hand, card], done: true }
      : x));
    setSeats(list);
    timers.current.push(window.setTimeout(() => advance(list, active), 450));
  };

  const surrender = () => {
    if (phase !== 'play') return;
    const s = seats[active];
    if (s.hand.length !== 2) return;
    audio.click();
    payTo(active, Math.floor(s.bet / 2));   // возвращаем половину
    const list = seats.map((x, i) => (i === active
      ? { ...x, surrendered: true, done: true, result: 'Сдался', payout: Math.floor(x.bet / 2) }
      : x));
    setSeats(list);
    advance(list, active);
  };

  /* ---------- ход дилера ---------- */
  const dealerPlay = (list: Seat[], start: Card[]) => {
    setHoleShown(true);
    audio.blip(440, 0.05, 'triangle', 0.07);
    const d = [...start];

    const step = () => {
      const anyLive = list.some((s) => s.bet > 0 && !s.surrendered && score(s.hand) <= 21);
      /* дилер добирает строго до 17, стоит на мягкой 17 */
      if (anyLive && (score(d) < DEALER_STANDS || (score(d) === 17 && false))) {
        d.push(shoe.current.pop()!);
        setDealer([...d]);
        audio.blip(560, 0.03, 'triangle', 0.05);
        timers.current.push(window.setTimeout(step, 520));
      } else {
        settleRound(list, d);
      }
    };
    timers.current.push(window.setTimeout(step, 520));
  };

  /* ---------- расчёт ---------- */
  const settleRound = (list: Seat[], d: Card[]) => {
    const ds = score(d);
    const dbj = isBlackjack(d);
    const results: Seat[] = list.map((s, i) => {
      if (s.bet === 0 || s.surrendered) return s;
      const ps = score(s.hand);
      const pbj = isBlackjack(s.hand);
      let payout = 0;
      let result: string;

      if (pbj && dbj) { payout = s.bet; result = 'Ничья (оба ББ)'; }
      else if (pbj) { payout = Math.round(s.bet * 2.5); result = 'Блэкджек 3:2'; }
      else if (dbj) { payout = 0; result = 'Блэкджек у дилера'; }
      else if (ps > 21) { payout = 0; result = `Перебор ${ps}`; }
      else if (ds > 21) { payout = s.bet * 2; result = `Дилер перебрал (${ds})`; }
      else if (ps > ds) { payout = s.bet * 2; result = `${ps} : ${ds} — победа`; }
      else if (ps < ds) { payout = 0; result = `${ps} : ${ds} — проигрыш`; }
      else { payout = s.bet; result = `Ничья ${ps}`; }

      payTo(i, payout);
      const win = payout > s.bet;
      addStats({
        gamesPlayed: 1, gameWins: win ? 1 : 0, wagered: s.bet,
        bestWin: Math.max(0, payout - state.stats.bestWin),
      });
      log({
        kind: 'game', text: `Блэкджек · ${s.name}: ${result}`,
        amount: payout - s.bet, success: win,
      });
      return { ...s, result, payout };
    });

    setSeats(results);
    setPhase('done');
    busy.current = false;

    const wins = results.filter((s) => s.bet > 0 && s.payout > s.bet);
    if (wins.length) audio.win(); else audio.lose();
    setHistory((h) => [
      results.filter((s) => s.bet > 0).map((s) => `${s.name}: ${s.result}`).join(' · '),
      ...h,
    ].slice(0, 8));
  };

  const newRound = () => {
    audio.click();
    setSeats((s) => s.map((x) => ({
      ...x, hand: [], bet: 0, done: false, doubled: false,
      surrendered: false, result: '', payout: 0,
    })));
    setDealer([]);
    setHoleShown(false);
    setActive(0);
    setPhase('bets');
  };

  const ds = score(dealer);
  const shownDealer = holeShown ? ds : dealer.length ? score([dealer[0]]) : 0;
  const cur = seats[active];
  const canAct = phase === 'play' && cur && cur.bet > 0 && !cur.done;

  return (
    <div className="mx-auto max-w-[420px] space-y-3">
      <GameShell
        title="Блэкджек"
        subtitle={mode === 'single' ? 'Классика: вы против дилера' : 'Хот-сит: двое с одного телефона'}
        right={
          <div className="chip-row">
            <button className={cn('chip', mode === 'single' && 'on')} onClick={() => switchMode('single')}>
              <User size={12} />
            </button>
            <button className={cn('chip', mode === 'hotseat' && 'on')} onClick={() => switchMode('hotseat')}>
              <Users size={12} />
            </button>
          </div>
        }
      >
        {/* стол */}
        <div
          className="relative overflow-hidden rounded-2xl p-3"
          style={{
            background: 'radial-gradient(120% 90% at 50% 0%, #15764a, #0a3f28 60%, #062418)',
            border: '2px solid rgba(216,184,113,.45)',
          }}
        >
          {/* дилер */}
          <div className="mb-3">
            <div className="mb-1.5 flex items-center gap-2">
              <span className="text-[9.5px] font-bold uppercase tracking-[0.18em] text-emerald-100/60">Дилер</span>
              {dealer.length > 0 && (
                <span className="num rounded-md bg-black/40 px-1.5 py-0.5 text-[10.5px] font-extrabold text-white">
                  {shownDealer}{!holeShown && '+'}
                </span>
              )}
              {phase === 'dealer' && (
                <span className="text-[9px] font-bold uppercase tracking-wider text-gold">ход дилера</span>
              )}
            </div>
            <div className="flex gap-1.5">
              {dealer.length === 0
                ? <div className="h-[74px] w-[52px] rounded-md border border-dashed border-white/20" />
                : dealer.map((c, i) => (
                  <PlayingCard key={c.id} card={c} hidden={!holeShown && i === 1} delay={i * 90} />
                ))}
            </div>
          </div>

          {/* игроки */}
          <div className={cn('grid gap-2', mode === 'hotseat' ? 'grid-cols-2' : 'grid-cols-1')}>
            {seats.map((s, i) => {
              const isTurn = phase === 'play' && active === i && !s.done && s.bet > 0;
              const sc = score(s.hand);
              return (
                <div
                  key={i}
                  className="rounded-xl p-2 transition-all"
                  style={{
                    background: isTurn ? 'rgba(246,196,69,.14)' : 'rgba(0,0,0,.22)',
                    boxShadow: isTurn ? 'inset 0 0 0 2px #f6c445' : 'inset 0 0 0 1px rgba(255,255,255,.08)',
                  }}
                >
                  <div className="mb-1 flex items-center gap-1">
                    {editing === i ? (
                      <input
                        autoFocus
                        defaultValue={s.name}
                        maxLength={12}
                        onBlur={(e) => { setSeat(i, { name: e.target.value || s.name }); setEditing(null); }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            setSeat(i, { name: (e.target as HTMLInputElement).value || s.name });
                            setEditing(null);
                          }
                        }}
                        className="input w-full px-1.5 py-0.5 text-[10px] font-bold"
                      />
                    ) : (
                      <>
                        <span className="min-w-0 truncate text-[10.5px] font-extrabold text-white">{s.name}</span>
                        {phase === 'bets' && (
                          <button onClick={() => setEditing(i)} className="shrink-0 text-white/40">
                            <Pencil size={10} />
                          </button>
                        )}
                      </>
                    )}
                    {s.hand.length > 0 && (
                      <span className={cn('num ml-auto shrink-0 rounded px-1 text-[10px] font-extrabold',
                        sc > 21 ? 'bg-rose-600 text-white'
                          : sc === 21 ? 'bg-gold text-black' : 'bg-black/40 text-white')}>
                        {sc}{isSoft(s.hand) && sc <= 21 ? '♦' : ''}
                      </span>
                    )}
                  </div>

                  <div className="flex min-h-[62px] flex-wrap gap-1">
                    {s.hand.length === 0
                      ? <div className="h-[60px] w-[42px] rounded-md border border-dashed border-white/15" />
                      : s.hand.map((c, ci) => <PlayingCard key={c.id} card={c} small delay={ci * 80} />)}
                  </div>

                  <div className="mt-1 flex items-center justify-between gap-1">
                    <span className="num text-[9.5px] font-bold text-gold">
                      {s.bet > 0 ? fmt(s.bet) : '—'}{s.doubled && ' ×2'}
                    </span>
                    <span className="num text-[9px] text-white/55">
                      {i === 0 ? fmt(state.balance) : fmt(s.wallet)}
                    </span>
                  </div>

                  {s.result && phase === 'done' && (
                    <div className={cn('mt-1 truncate rounded px-1 py-0.5 text-center text-[9px] font-extrabold',
                      s.payout > s.bet ? 'bg-emerald-500/25 text-emerald-200'
                        : s.payout === s.bet ? 'bg-white/10 text-white/70'
                          : 'bg-rose-500/25 text-rose-200')}>
                      {s.result}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* баннер активного хода */}
          {phase === 'play' && cur && (
            <div className="mt-2 rounded-lg bg-black/45 py-1.5 text-center text-[11px] font-extrabold text-gold">
              Ход: {cur.name}
            </div>
          )}
        </div>

        {/* кошелёк второго игрока */}
        {mode === 'hotseat' && phase === 'bets' && (
          <div className="panel-inset mt-2 flex items-center gap-2 p-2">
            <Coins size={14} className="shrink-0 text-gold" />
            <span className="shrink-0 text-[10px] font-bold text-slate-400">Игрок 2</span>
            <input
              type="number" min={0} value={p2Buyin}
              onChange={(e) => setP2Buyin(Math.max(0, Number(e.target.value) || 0))}
              className="input num w-20 px-2 py-1.5 text-center text-[11px] font-bold"
            />
            <button className="chip shrink-0" onClick={buyinP2}>Дать</button>
            <button className="chip shrink-0" onClick={cashoutP2}>Забрать</button>
          </div>
        )}

        {/* ставки */}
        {phase === 'bets' && (
          <div className="mt-2 space-y-2">
            {seats.map((s, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <span className="w-16 shrink-0 truncate text-[10px] font-bold text-slate-400">{s.name}</span>
                <div className="chip-row flex-1">
                  {CHIPS.map((c) => (
                    <button key={c} className="chip num" onClick={() => addChip(i, c)}>+{c}</button>
                  ))}
                </div>
                <button className="chip shrink-0" onClick={() => clearBet(i)}>×</button>
              </div>
            ))}
            <button onClick={deal}
              className="btn btn-gold btn-shine w-full py-3.5 font-display text-[13px] font-extrabold uppercase tracking-wider">
              Раздать
            </button>
          </div>
        )}

        {/* действия активного игрока */}
        {phase === 'play' && (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button onClick={hit} disabled={!canAct}
              className="btn btn-green py-3.5 text-[12.5px] font-extrabold uppercase">Ещё</button>
            <button onClick={stand} disabled={!canAct}
              className="btn btn-red py-3.5 text-[12.5px] font-extrabold uppercase">Хватит</button>
            <button onClick={double} disabled={!canAct || cur?.hand.length !== 2}
              className="btn btn-gold py-3 text-[11.5px] font-extrabold uppercase">Удвоить</button>
            <button onClick={surrender} disabled={!canAct || cur?.hand.length !== 2}
              className="btn btn-ghost py-3 text-[11.5px] font-extrabold uppercase">Сдаться</button>
          </div>
        )}

        {phase === 'done' && (
          <button onClick={newRound}
            className="btn btn-gold btn-shine mt-2 w-full py-3.5 font-display text-[13px] font-extrabold uppercase tracking-wider">
            Новая раздача
          </button>
        )}

        {phase === 'dealer' && (
          <div className="mt-2 py-3 text-center text-[11px] font-bold uppercase tracking-wider text-slate-500">
            дилер играет…
          </div>
        )}
      </GameShell>

      {/* правила */}
      <div className="panel p-3 text-[9.5px] leading-relaxed text-slate-500">
        <div className="mb-1 font-display text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Правила стола
        </div>
        Блэкджек платит 3:2 · обычная победа 1:1 · ничья возвращает ставку ·
        дилер добирает до {DEALER_STANDS} и стоит на 17 · удвоение на первых двух картах ·
        сдача возвращает половину ставки · шуз из 6 колод, перемешивание криптостойкое.
      </div>

      {/* история */}
      {history.length > 0 && (
        <div className="panel p-2.5">
          <div className="mb-1.5 flex items-center gap-1.5">
            <History size={12} className="text-slate-600" />
            <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500">Раунды</span>
          </div>
          <div className="space-y-1">
            {history.map((h, i) => (
              <div key={i} className="panel-inset truncate px-2 py-1 text-[9.5px] text-slate-400">{h}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
