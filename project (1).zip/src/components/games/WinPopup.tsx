import { useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { fmt } from '../../lib/skins';

export interface WinPopupData {
  amount: number;
  mult: number;
  /** подпись под суммой */
  note?: string;
  /** крупный заголовок при большом выигрыше */
  big?: boolean;
  accent: string;
}

/** Большой попап выигрыша: лучи, конфетти, закрытие тапом */
export default function WinPopup({ data, onClose }: { data: WinPopupData; onClose: () => void }) {
  /* автозакрытие, чтобы не блокировать автоспин */
  useEffect(() => {
    const t = window.setTimeout(onClose, data.big ? 4200 : 2600);
    return () => window.clearTimeout(t);
  }, [data, onClose]);

  const rays = useMemo(() => Array.from({ length: 12 }, (_, i) => i * 30), []);
  const conf = useMemo(
    () => Array.from({ length: 22 }, (_, i) => ({
      x: Math.round((Math.random() - 0.5) * 300),
      y: Math.round(-120 - Math.random() * 180),
      r: Math.round(Math.random() * 720 - 360),
      d: (0.7 + Math.random() * 0.6).toFixed(2),
      c: ['#ffd964', '#ff6b9d', '#7dd3fc', '#86efac', '#c77dff'][i % 5],
      s: 5 + Math.round(Math.random() * 5),
    })),
    [],
  );

  const body = (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[96] grid place-items-center overflow-hidden px-5"
      style={{ minHeight: '100dvh', background: 'rgba(4,6,12,.82)' }}
    >
      {/* лучи из центра */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-0 w-0">
        {rays.map((deg) => (
          <span
            key={deg}
            className="absolute origin-bottom"
            style={{
              left: -22, bottom: 0, width: 44, height: 320,
              transform: `rotate(${deg}deg)`,
              background: `linear-gradient(to top, ${data.accent}00, ${data.accent}2e 40%, ${data.accent}00)`,
              animation: 'rayspin 9s linear infinite',
            }}
          />
        ))}
      </div>

      <div className="pop-in relative w-full max-w-[360px] text-center">
        {/* конфетти */}
        <div className="pointer-events-none absolute left-1/2 top-1/2">
          {conf.map((c, i) => (
            <span
              key={i}
              className="absolute block"
              style={{
                width: c.s, height: c.s * 2, background: c.c, borderRadius: 2,
                ['--cx' as string]: `${c.x}px`, ['--cy' as string]: `${c.y}px`,
                ['--cr' as string]: `${c.r}deg`,
                animation: `confFly ${c.d}s cubic-bezier(.16,.84,.44,1) forwards`,
              }}
            />
          ))}
        </div>

        <div
          className="relative rounded-3xl px-5 py-6"
          style={{
            background: 'linear-gradient(165deg,#6d28d9,#b1360f 78%,#2a1005)',
            border: `3px solid ${data.accent}`,
            boxShadow: `0 0 40px -8px ${data.accent}`,
          }}
        >
          <div
            className="font-display text-[17px] font-extrabold leading-tight"
            style={{ color: '#ffe066', textShadow: '0 2px 0 #7a3a00, 0 0 14px rgba(255,214,64,.6)' }}
          >
            {data.big ? 'КРУПНЫЙ ВЫИГРЫШ!' : 'ПОЗДРАВЛЯЕМ!'}
          </div>
          <div className="mt-0.5 text-[10.5px] font-bold uppercase tracking-[0.18em] text-white/70">
            вы выиграли
          </div>

          <div
            className="num mt-3 rounded-2xl px-3 py-2.5 font-display text-[28px] font-extrabold"
            style={{
              background: 'linear-gradient(180deg,#2a1608,#120902)',
              border: '2px solid #f7c948',
              color: '#ffd964',
              textShadow: '0 2px 6px rgba(0,0,0,.8)',
            }}
          >
            {fmt(data.amount)}
          </div>

          <div className="mt-2.5 inline-block rounded-full px-3 py-1 text-[12px] font-extrabold"
            style={{ background: `${data.accent}26`, color: '#fff', border: `1px solid ${data.accent}` }}>
            множитель ×{data.mult.toFixed(2)}
          </div>

          {data.note && (
            <div className="mt-2 text-[11.5px] font-bold text-white/80">{data.note}</div>
          )}
        </div>

        <div className="mt-3 text-[10.5px] font-bold uppercase tracking-wider text-white/45">
          нажмите в любом месте, чтобы продолжить
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(body, document.body);
}
