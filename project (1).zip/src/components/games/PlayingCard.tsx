import { memo } from 'react';
import { SUIT_CHAR, isRed, type Card } from '../../lib/deck';
import { cn } from '../../utils/cn';

/** Игральная карта: лицо или рубашка с логотипом заведения */
export const PlayingCard = memo(function PlayingCard({
  card, hidden, delay = 0, small,
}: {
  card?: Card;
  hidden?: boolean;
  delay?: number;
  small?: boolean;
}) {
  const w = small ? 42 : 52;
  const h = small ? 60 : 74;
  const red = card ? isRed(card.s) : false;

  return (
    <div
      className="card-in relative shrink-0 rounded-md"
      style={{ width: w, height: h, animationDelay: `${delay}ms` }}
    >
      {hidden || !card ? (
        <div
          className="grid h-full w-full place-items-center rounded-md"
          style={{
            background: 'linear-gradient(145deg,#1e2740,#121a2e)',
            border: '1.5px solid rgba(246,196,69,.45)',
            boxShadow: '0 2px 6px rgba(0,0,0,.6)',
          }}
        >
          <div
            className="grid place-items-center rounded-sm"
            style={{
              width: w * 0.6, height: h * 0.6,
              background: 'repeating-linear-gradient(45deg,rgba(246,196,69,.16) 0 4px,transparent 4px 8px)',
              border: '1px solid rgba(246,196,69,.3)',
            }}
          >
            <span className="font-display text-[8px] font-black tracking-tight text-gold/70">NG</span>
          </div>
        </div>
      ) : (
        <div
          className="relative h-full w-full rounded-md bg-white"
          style={{ boxShadow: '0 2px 6px rgba(0,0,0,.55)', border: '1px solid rgba(0,0,0,.25)' }}
        >
          <span
            className={cn('absolute left-1 top-0.5 font-display font-black leading-tight',
              small ? 'text-[11px]' : 'text-[13px]')}
            style={{ color: red ? '#d32030' : '#14171f' }}
          >
            {card.r}
          </span>
          <span
            className={cn('absolute left-1 leading-none', small ? 'top-[18px] text-[10px]' : 'top-[22px] text-[12px]')}
            style={{ color: red ? '#d32030' : '#14171f' }}
          >
            {SUIT_CHAR[card.s]}
          </span>
          <span
            className={cn('absolute bottom-0.5 right-1 rotate-180 font-display font-black leading-tight',
              small ? 'text-[11px]' : 'text-[13px]')}
            style={{ color: red ? '#d32030' : '#14171f' }}
          >
            {card.r}
          </span>
          <span
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{ color: red ? '#d32030' : '#14171f', fontSize: small ? 19 : 24 }}
          >
            {SUIT_CHAR[card.s]}
          </span>
        </div>
      )}
    </div>
  );
});
