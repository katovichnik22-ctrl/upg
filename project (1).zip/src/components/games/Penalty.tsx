import { useCallback, useEffect, useRef, useState } from 'react';
import { History, Target } from 'lucide-react';
import { BetBar, GameShell, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

/** 9 зон ворот: множитель тем выше, чем труднее попасть */
const ZONE_MULT = [
  [10, 3.2, 10],   // верх: углы самые дорогие
  [3.6, 1.4, 3.6], // середина
  [3.0, 1.2, 3.0], // низ
];
const ZONE_NAME = ['Левый верх', 'Центр верх', 'Правый верх',
  'Левый', 'Центр', 'Правый',
  'Левый низ', 'Центр низ', 'Правый низ'];

/** Вероятность сейва растёт для лёгких зон — так держим RTP около 95% */
const SAVE_CHANCE = [
  [0.905, 0.703, 0.905],
  [0.736, 0.321, 0.736],
  [0.683, 0.208, 0.683],
];

interface Shot { id: number; goal: boolean; mult: number }

export default function Penalty() {
  const { canBet, place, settle } = useGameRound('Пенальти');

  const [bet, setBet] = useState(50);
  const [zone, setZone] = useState(4);
  const [shooting, setShooting] = useState(false);
  const [history, setHistory] = useState<Shot[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [streak, setStreak] = useState(0);

  const ballRef = useRef<HTMLDivElement>(null);
  const keeperRef = useRef<HTMLDivElement>(null);
  const timers = useRef<number[]>([]);
  const shotId = useRef(0);
  const busy = useRef(false);

  useEffect(() => () => timers.current.forEach(window.clearTimeout), []);

  const row = Math.floor(zone / 3);
  const col = zone % 3;
  const mult = ZONE_MULT[row][col];

  const shoot = useCallback(() => {
    if (busy.current) return;
    const staked = Math.round(bet);
    if (!canBet(staked)) return;

    busy.current = true;
    setShooting(true);
    setMsg(null);
    place(staked);
    audio.blip(180, 0.09, 'square', 0.1);   // удар по мячу

    const r = Math.floor(zone / 3);
    const c = zone % 3;
    const saved = Math.random() < SAVE_CHANCE[r][c];

    /* вратарь прыгает: в зону удара при сейве, иначе мимо */
    let keeperCol = c;
    if (!saved) {
      const others = [0, 1, 2].filter((x) => x !== c);
      keeperCol = others[Math.floor(Math.random() * others.length)];
    }

    const ball = ballRef.current;
    const keeper = keeperRef.current;
    /* анимации — только transform, GPU */
    if (keeper) {
      const dx = (keeperCol - 1) * 74;
      const dy = r === 0 ? -26 : r === 1 ? -6 : 6;
      keeper.style.transition = 'transform .42s cubic-bezier(.2,.9,.3,1)';
      keeper.style.transform = `translate3d(${dx}px,${dy}px,0) rotate(${(keeperCol - 1) * 16}deg)`;
    }
    if (ball) {
      const dx = (c - 1) * 78;
      const dy = -150 + r * 40;
      ball.style.transition = 'transform .46s cubic-bezier(.25,.7,.4,1)';
      ball.style.transform = `translate3d(${dx}px,${dy}px,0) scale(.62) rotate(520deg)`;
    }

    timers.current.push(window.setTimeout(() => {
      const goal = !saved;
      const payout = goal ? Math.round(staked * ZONE_MULT[r][c]) : 0;
      setHistory((h) => [{ id: ++shotId.current, goal, mult: ZONE_MULT[r][c] }, ...h].slice(0, 14));
      setStreak((s) => (goal ? s + 1 : 0));
      setMsg(goal ? `ГОЛ! x${ZONE_MULT[r][c]}` : 'СЕЙВ — вратарь взял');
      settle(staked, payout, goal ? `Гол · ${ZONE_NAME[zone]}` : `Сейв · ${ZONE_NAME[zone]}`);
      if (goal) audio.win(); else audio.lose();

      /* возврат в исходное */
      timers.current.push(window.setTimeout(() => {
        if (ball) { ball.style.transition = 'transform .3s ease'; ball.style.transform = 'translate3d(0,0,0)'; }
        if (keeper) { keeper.style.transition = 'transform .3s ease'; keeper.style.transform = 'translate3d(0,0,0)'; }
        setShooting(false);
        busy.current = false;
      }, 900));
    }, 470));
  }, [bet, zone, canBet, place, settle]);

  return (
    <div className="mx-auto max-w-[420px] space-y-3">
      <GameShell
        title="Пенальти"
        subtitle="Выбери угол — обыграй вратаря"
        right={<Target size={16} className="text-emerald-400" />}
      >
        {/* поле */}
        <div
          className="relative overflow-hidden rounded-2xl"
          style={{
            height: 250,
            background: 'linear-gradient(180deg,#0b2d16 0%,#124a25 55%,#0d3a1d 100%)',
            contain: 'paint',
          }}
        >
          {/* разметка */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-white/25" />
          <div className="pointer-events-none absolute left-1/2 bottom-3 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-white/60" />

          {/* ворота */}
          <div className="absolute left-1/2 top-5 -translate-x-1/2" style={{ width: 260, height: 130 }}>
            <div className="absolute inset-0 rounded-sm border-[4px] border-white/90"
              style={{ background: 'repeating-linear-gradient(90deg,rgba(255,255,255,.10) 0 1px,transparent 1px 13px),repeating-linear-gradient(0deg,rgba(255,255,255,.10) 0 1px,transparent 1px 13px)' }} />

            {/* сетка зон 3×3 */}
            <div className="absolute inset-0 grid grid-cols-3 grid-rows-3">
              {Array.from({ length: 9 }, (_, i) => {
                const active = zone === i;
                const m = ZONE_MULT[Math.floor(i / 3)][i % 3];
                return (
                  <button
                    key={i}
                    disabled={shooting}
                    onClick={() => { audio.click(); setZone(i); }}
                    className="relative grid place-items-center transition-colors"
                    style={{
                      border: '1px solid rgba(255,255,255,.14)',
                      background: active ? 'rgba(246,196,69,.28)' : 'transparent',
                      boxShadow: active ? 'inset 0 0 0 2px #f6c445' : undefined,
                    }}
                  >
                    <span className={cn('num text-[11px] font-extrabold',
                      active ? 'text-gold' : 'text-white/45')}>
                      x{m}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* вратарь */}
            <div ref={keeperRef} className="gpu absolute left-1/2 top-[46%] -translate-x-1/2">
              <svg width="46" height="58" viewBox="0 0 46 58">
                <circle cx="23" cy="10" r="8" fill="#ffd9b0" stroke="#7a4a1c" strokeWidth="1.5" />
                <path d="M10 22h26l-4 22H14z" fill="#f6c445" stroke="#8a6205" strokeWidth="1.5" />
                <path d="M10 22L2 34M36 22l8 12" stroke="#f6c445" strokeWidth="6" strokeLinecap="round" />
                <path d="M16 44l-3 12M30 44l3 12" stroke="#1f3d6e" strokeWidth="6" strokeLinecap="round" />
              </svg>
            </div>
          </div>

          {/* мяч */}
          <div ref={ballRef} className="gpu absolute left-1/2 bottom-6 -ml-[13px]">
            <svg width="26" height="26" viewBox="0 0 26 26">
              <circle cx="13" cy="13" r="12" fill="#fff" stroke="#2a3450" strokeWidth="1.5" />
              <path d="M13 5l4 3-1.5 5h-5L9 8z" fill="#1b2238" />
              <path d="M5 12l3.5 2.5L7 20M21 12l-3.5 2.5L19 20M10 21h6" stroke="#1b2238" strokeWidth="1.6" fill="none" />
            </svg>
          </div>

          {/* результат */}
          {msg && (
            <div className={cn(
              'pop-in absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-xl px-4 py-2 text-[14px] font-extrabold',
              msg.startsWith('ГОЛ')
                ? 'bg-emerald-500/25 text-emerald-200 ring-2 ring-emerald-400/60'
                : 'bg-rose-500/25 text-rose-200 ring-2 ring-rose-400/60',
            )}>
              {msg}
            </div>
          )}

          {streak >= 2 && !shooting && (
            <div className="absolute right-2 top-2 rounded-lg bg-gold/15 px-2 py-1 text-[10px] font-extrabold text-gold ring-1 ring-gold/35">
              серия {streak}
            </div>
          )}
        </div>

        {/* управление */}
        <div className="mt-3 space-y-2">
          <div className="panel-inset flex items-center justify-between px-3 py-2">
            <span className="text-[11px] font-bold text-slate-400">{ZONE_NAME[zone]}</span>
            <span className="num text-[13px] font-extrabold text-gold">x{mult}</span>
          </div>
          <BetBar amount={bet} setAmount={setBet} disabled={shooting} />
          <button
            onClick={shoot}
            disabled={shooting}
            className="btn btn-gold btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]"
          >
            {shooting ? 'Удар…' : `Бить · ${fmt(bet)}`}
          </button>
        </div>
      </GameShell>

      {history.length > 0 && (
        <div className="panel flex items-center gap-1.5 overflow-x-auto p-2.5">
          <History size={13} className="mr-0.5 shrink-0 text-slate-600" />
          {history.map((h) => (
            <span key={h.id}
              className={cn('num grid h-7 shrink-0 place-items-center rounded-md px-1.5 text-[10px] font-extrabold',
                h.goal ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300')}>
              {h.goal ? `x${h.mult}` : 'сейв'}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
