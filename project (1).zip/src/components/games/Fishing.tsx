import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Crosshair, History, Minus, Plus, Waves } from 'lucide-react';
import {
  FISH, SHOT_COSTS, TIER_COLOR, killChance, pickFish, rollCrit,
  type FishDef,
} from '../../data/fishing';
import { secureRandom } from '../../lib/rng';
import { useGameRound, GameShell } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

interface Swimmer {
  id: number;
  def: FishDef;
  x: number; y: number;
  vx: number;
  hp: number;
  phase: number;
  dying: number;   // таймер анимации гибели
  hitFlash: number;
}

interface Shot { id: number; x: number; y: number; vx: number; vy: number; bet: number; }

interface Catch { id: number; label: string; amount: number; mult: number; color: string; }

const MAX_FISH = 9;

export default function Fishing() {
  const { canBet, place, settle } = useGameRound('Рыбалка');

  const [bet, setBet] = useState(5);
  const [catches, setCatches] = useState<Catch[]>([]);
  const [stats, setStats] = useState({ shots: 0, staked: 0, won: 0 });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const fishRef = useRef<Swimmer[]>([]);
  const shotsRef = useRef<Shot[]>([]);
  const popsRef = useRef<Array<{ x: number; y: number; t: number; text: string; color: string }>>([]);
  const sizeRef = useRef({ w: 340, h: 380 });
  const rafRef = useRef(0);
  const idRef = useRef(0);
  const betRef = useRef(bet);
  const canBetRef = useRef(canBet);
  betRef.current = bet;
  canBetRef.current = canBet;

  /* колбэки берём через ref, чтобы не перезапускать цикл анимации */
  const placeRef = useRef(place);
  const settleRef = useRef(settle);
  placeRef.current = place;
  settleRef.current = settle;

  /* ---------- размеры ---------- */
  useEffect(() => {
    const el = wrapRef.current;
    const cv = canvasRef.current;
    if (!el || !cv) return;
    const apply = () => {
      const w = el.clientWidth;
      const h = Math.round(Math.min(420, Math.max(300, w * 1.08)));
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(h * dpr);
      cv.style.height = `${h}px`;
      sizeRef.current = { w, h };
      const ctx = cv.getContext('2d');
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  /* ---------- спавн ---------- */
  const spawn = useCallback(() => {
    const { w, h } = sizeRef.current;
    const def = pickFish(secureRandom);
    const dir = secureRandom() < 0.5 ? 1 : -1;
    fishRef.current.push({
      id: ++idRef.current,
      def,
      x: dir > 0 ? -def.size : w + def.size,
      y: 60 + secureRandom() * (h - 150),
      vx: dir * def.speed * (0.8 + secureRandom() * 0.4),
      hp: def.hp,
      phase: secureRandom() * Math.PI * 2,
      dying: 0,
      hitFlash: 0,
    });
  }, []);

  /* ---------- отрисовка рыбы ---------- */
  const drawFish = (ctx: CanvasRenderingContext2D, f: Swimmer, t: number) => {
    const { def } = f;
    const s = def.size;
    const dir = f.vx >= 0 ? 1 : -1;
    const wig = Math.sin(t * 3.2 + f.phase) * 0.12;

    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.scale(dir, 1);
    ctx.rotate(wig);

    if (f.dying > 0) {
      ctx.globalAlpha = Math.max(0, f.dying);
      ctx.scale(1 + (1 - f.dying) * 0.5, 1 + (1 - f.dying) * 0.5);
    }

    /* хвост */
    ctx.beginPath();
    ctx.moveTo(-s * 0.42, 0);
    ctx.lineTo(-s * 0.72, -s * 0.26);
    ctx.lineTo(-s * 0.62, 0);
    ctx.lineTo(-s * 0.72, s * 0.26);
    ctx.closePath();
    ctx.fillStyle = def.fin;
    ctx.fill();

    /* тело */
    ctx.beginPath();
    ctx.ellipse(0, 0, s * 0.46, s * 0.28, 0, 0, Math.PI * 2);
    const g = ctx.createLinearGradient(0, -s * 0.3, 0, s * 0.3);
    g.addColorStop(0, '#ffffff');
    g.addColorStop(0.35, def.body);
    g.addColorStop(1, def.fin);
    ctx.fillStyle = f.hitFlash > 0 ? '#ffffff' : g;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(0,0,0,.35)';
    ctx.stroke();

    /* верхний плавник */
    ctx.beginPath();
    ctx.moveTo(-s * 0.1, -s * 0.26);
    ctx.quadraticCurveTo(0, -s * 0.5, s * 0.16, -s * 0.24);
    ctx.closePath();
    ctx.fillStyle = def.fin;
    ctx.fill();

    /* глаз */
    ctx.beginPath();
    ctx.arc(s * 0.26, -s * 0.06, s * 0.07, 0, Math.PI * 2);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(s * 0.28, -s * 0.06, s * 0.035, 0, Math.PI * 2);
    ctx.fillStyle = '#10151f';
    ctx.fill();
    ctx.restore();

    /* полоска HP у раненых крупных рыб */
    if (f.hp < def.hp && f.dying === 0) {
      const bw = s * 0.8;
      ctx.fillStyle = 'rgba(0,0,0,.5)';
      ctx.fillRect(f.x - bw / 2, f.y - s * 0.42, bw, 3);
      ctx.fillStyle = TIER_COLOR[def.tier];
      ctx.fillRect(f.x - bw / 2, f.y - s * 0.42, (bw * f.hp) / def.hp, 3);
    }
  };

  /* ---------- игровой цикл ---------- */
  useEffect(() => {
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const { w, h } = sizeRef.current;
      const cv = canvasRef.current;
      const ctx = cv?.getContext('2d');
      if (!ctx) { rafRef.current = requestAnimationFrame(loop); return; }

      /* фон: вода */
      const bg = ctx.createLinearGradient(0, 0, 0, h);
      bg.addColorStop(0, '#0d4a6b');
      bg.addColorStop(0.55, '#07263d');
      bg.addColorStop(1, '#03121f');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      /* лучи света */
      ctx.save();
      ctx.globalAlpha = 0.07;
      ctx.fillStyle = '#bfe9ff';
      for (let i = 0; i < 3; i++) {
        const x = w * (0.2 + i * 0.3) + Math.sin(now / 2600 + i) * 14;
        ctx.beginPath();
        ctx.moveTo(x - 16, 0);
        ctx.lineTo(x + 16, 0);
        ctx.lineTo(x + 52, h);
        ctx.lineTo(x - 52, h);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      /* дно */
      ctx.fillStyle = '#04202e';
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(0, h - 26);
      for (let x = 0; x <= w; x += 28) {
        ctx.quadraticCurveTo(x + 14, h - 38, x + 28, h - 26);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();

      /* пузыри */
      ctx.save();
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = '#bfe9ff';
      for (let i = 0; i < 9; i++) {
        const bx = ((i * 137) % w);
        const by = h - ((now / 22 + i * 90) % (h + 40));
        ctx.beginPath();
        ctx.arc(bx, by, 2 + (i % 3), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      /* рыбы */
      const alive: Swimmer[] = [];
      for (const f of fishRef.current) {
        if (f.dying > 0) {
          f.dying -= dt * 2.2;
          if (f.dying > 0) alive.push(f);
        } else {
          f.x += f.vx * dt;
          f.y += Math.sin(now / 700 + f.phase) * 12 * dt;
          if (f.hitFlash > 0) f.hitFlash -= dt * 6;
          const off = f.x < -f.def.size * 1.5 || f.x > w + f.def.size * 1.5;
          if (!off) alive.push(f);
        }
        drawFish(ctx, f, now / 1000);
      }
      fishRef.current = alive;
      while (fishRef.current.length < MAX_FISH) spawn();

      /* снаряды */
      const liveShots: Shot[] = [];
      for (const s of shotsRef.current) {
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        if (s.x < -20 || s.x > w + 20 || s.y < -20) continue;

        /* проверка попадания */
        let hitIdx = -1;
        for (let i = 0; i < fishRef.current.length; i++) {
          const f = fishRef.current[i];
          if (f.dying > 0) continue;
          const dx = s.x - f.x, dy = s.y - f.y;
          if (dx * dx + dy * dy < Math.pow(f.def.size * 0.42, 2)) { hitIdx = i; break; }
        }

        if (hitIdx >= 0) {
          const f = fishRef.current[hitIdx];
          f.hitFlash = 1;
          audio.blip(760, 0.03, 'square', 0.05);
          /* исход решает честный генератор: p = RTP / (mult * crit) */
          if (secureRandom() < killChance(f.def)) {
            const crit = rollCrit(secureRandom);
            const payout = Math.round(s.bet * f.def.mult * crit);
            f.dying = 1;
            f.hp = 0;
            popsRef.current.push({
              x: f.x, y: f.y, t: 1,
              text: `+${payout}${crit > 1 ? ` x${crit}` : ''}`,
              color: crit > 1 ? '#ffd964' : TIER_COLOR[f.def.tier],
            });
            if (f.def.tier === 'boss' || crit > 1) audio.bigWin(); else audio.win();
            settleRef.current(s.bet, payout, `${f.def.label} x${f.def.mult}${crit > 1 ? ` крит x${crit}` : ''}`);
            setCatches((c) => [{
              id: ++idRef.current, label: f.def.label, amount: payout,
              mult: f.def.mult * crit, color: TIER_COLOR[f.def.tier],
            }, ...c].slice(0, 12));
            setStats((st) => ({ ...st, won: st.won + payout }));
          } else {
            /* рыба ранена — выстрел не окупился */
            f.hp = Math.max(0, f.hp - 1);
            settleRef.current(s.bet, 0, `${f.def.label} — ушла`);
          }
          continue;
        }
        liveShots.push(s);
      }
      shotsRef.current = liveShots;

      /* снаряды: отрисовка */
      for (const s of shotsRef.current) {
        ctx.save();
        ctx.shadowColor = '#ffd964';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(s.x, s.y, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = '#ffe89a';
        ctx.fill();
        ctx.restore();
      }

      /* всплывающие выплаты */
      const pops: typeof popsRef.current = [];
      for (const p of popsRef.current) {
        p.t -= dt * 1.1;
        p.y -= dt * 34;
        if (p.t <= 0) continue;
        ctx.save();
        ctx.globalAlpha = Math.min(1, p.t * 1.4);
        ctx.font = 'bold 15px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.lineWidth = 3;
        ctx.strokeStyle = 'rgba(0,0,0,.8)';
        ctx.strokeText(p.text, p.x, p.y);
        ctx.fillStyle = p.color;
        ctx.fillText(p.text, p.x, p.y);
        ctx.restore();
        pops.push(p);
      }
      popsRef.current = pops;

      /* пушка */
      const gx = w / 2, gy = h - 8;
      ctx.save();
      ctx.translate(gx, gy);
      ctx.fillStyle = '#2a3450';
      ctx.beginPath();
      ctx.ellipse(0, 4, 26, 13, 0, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = '#f6c445';
      ctx.fillRect(-5, -20, 10, 22);
      ctx.beginPath();
      ctx.arc(0, 0, 11, 0, Math.PI * 2);
      ctx.fillStyle = '#c9901a';
      ctx.fill();
      ctx.restore();

      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [spawn]);

  /* ---------- выстрел ---------- */
  const shoot = useCallback((clientX: number, clientY: number) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const b = Math.round(betRef.current);
    if (!canBetRef.current(b)) return;

    const rect = cv.getBoundingClientRect();
    const tx = clientX - rect.left;
    const ty = clientY - rect.top;
    const { w, h } = sizeRef.current;
    const gx = w / 2, gy = h - 24;
    const dx = tx - gx, dy = ty - gy;
    const len = Math.max(1, Math.hypot(dx, dy));
    const sp = 460;

    placeRef.current(b);
    setStats((s) => ({ ...s, shots: s.shots + 1, staked: s.staked + b }));
    shotsRef.current.push({
      id: ++idRef.current, x: gx, y: gy,
      vx: (dx / len) * sp, vy: (dy / len) * sp, bet: b,
    });
    audio.blip(300, 0.05, 'square', 0.07);
  }, []);

  const rtp = stats.staked > 0 ? (stats.won / stats.staked) * 100 : 0;

  const table = useMemo(() => FISH.map((f) => ({
    ...f, chance: killChance(f) * 100,
  })), []);

  return (
    <div className="mx-auto max-w-[420px] space-y-3">
      <GameShell
        title="Рыбалка"
        subtitle="Целься и стреляй — крупная добыча платит больше"
        right={<Waves size={16} className="text-cyan-300" />}
      >
        {/* сцена */}
        <div ref={wrapRef} className="relative overflow-hidden rounded-2xl border border-cyan-400/20">
          <canvas
            ref={canvasRef}
            className="block w-full touch-none select-none"
            onPointerDown={(e) => { e.preventDefault(); shoot(e.clientX, e.clientY); }}
          />
          <div className="pointer-events-none absolute left-2 top-2 rounded-lg bg-black/45 px-2 py-1 text-[9.5px] font-bold text-cyan-200">
            выстрел · {fmt(bet)}
          </div>
        </div>

        {/* ставка */}
        <div className="mt-3 flex items-center gap-2">
          <button
            className="chip h-11 w-11 justify-center"
            onClick={() => {
              audio.click();
              const i = SHOT_COSTS.indexOf(bet);
              setBet(SHOT_COSTS[Math.max(0, i - 1)]);
            }}
          >
            <Minus size={16} />
          </button>
          <div className="chip-row flex-1 justify-center">
            {SHOT_COSTS.map((c) => (
              <button key={c} className={cn('chip num', bet === c && 'on')}
                onClick={() => { audio.click(); setBet(c); }}>
                {c}
              </button>
            ))}
          </div>
          <button
            className="chip h-11 w-11 justify-center"
            onClick={() => {
              audio.click();
              const i = SHOT_COSTS.indexOf(bet);
              setBet(SHOT_COSTS[Math.min(SHOT_COSTS.length - 1, i + 1)]);
            }}
          >
            <Plus size={16} />
          </button>
        </div>

        <div className="mt-2 flex items-center justify-center gap-1.5 text-[10.5px] font-bold text-slate-500">
          <Crosshair size={12} className="text-gold" />
          тапните по воде, чтобы выстрелить
        </div>
      </GameShell>

      {/* улов */}
      {catches.length > 0 && (
        <div className="panel flex items-center gap-1.5 overflow-x-auto p-2.5">
          <History size={13} className="mr-0.5 shrink-0 text-slate-600" />
          {catches.map((c) => (
            <span key={c.id}
              className="num shrink-0 rounded-md px-1.5 py-1 text-[10px] font-extrabold"
              style={{ background: `${c.color}22`, color: c.color }}>
              {c.label} +{c.amount}
            </span>
          ))}
        </div>
      )}

      {/* таблица добычи */}
      <div className="panel p-3">
        <div className="mb-2 font-display text-[10.5px] font-bold uppercase tracking-[0.16em] text-slate-400">
          Добыча и множители
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {table.map((f) => (
            <div key={f.id} className="panel-inset flex items-center gap-2 px-2 py-1.5">
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: TIER_COLOR[f.tier] }} />
              <span className="min-w-0 flex-1 truncate text-[10.5px] font-bold text-slate-300">{f.label}</span>
              <span className="num text-[10.5px] font-extrabold" style={{ color: TIER_COLOR[f.tier] }}>
                x{f.mult}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-2 text-[9.5px] leading-relaxed text-slate-600">
          Чем крупнее добыча, тем реже она попадается на крючок. Криты ×2 / ×5 / ×10 умножают выплату.
        </div>
      </div>

      {/* статистика сессии */}
      <div className="panel grid grid-cols-4 gap-1.5 p-2.5">
        {[
          ['Выстрелов', String(stats.shots)],
          ['Ставки', fmt(stats.staked)],
          ['Улов', fmt(stats.won)],
          ['RTP', `${rtp.toFixed(0)}%`],
        ].map(([k, v]) => (
          <div key={k} className="panel-inset px-1 py-1.5 text-center">
            <div className="num truncate text-[11px] font-extrabold">{v}</div>
            <div className="text-[8px] uppercase tracking-wider text-slate-500">{k}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
