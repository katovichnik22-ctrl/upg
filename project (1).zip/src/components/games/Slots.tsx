import { useEffect, useMemo, useState } from 'react';
import { Search, Lock, X, Filter } from 'lucide-react';
import { SLOTS, SLOT_THEMES, type SlotConfig } from '../../data/slots';
import { SlotSymbol } from '../SlotSymbol';
import SlotMachine from './SlotMachine';
import { useGame } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { preloadSlotSymbols } from '../../lib/preload';
import { cn } from '../../utils/cn';

type Sort = 'default' | 'bet' | 'rtp';

export default function Slots() {
  const { state, adjust, unlockSlot, toast } = useGame();
  const [active, setActive] = useState<SlotConfig | null>(null);

  /* картинки барабанов должны быть в кэше до первого спина */
  useEffect(() => { preloadSlotSymbols(); }, []);
  const [q, setQ] = useState('');
  const [theme, setTheme] = useState<string>('all');
  const [sort, setSort] = useState<Sort>('default');

  const isOpen = (s: SlotConfig) =>
    s.unlockedByDefault || state.unlockedSlots.includes(s.id);

  const list = useMemo(() => {
    let arr = SLOTS;
    if (q.trim()) {
      const t = q.trim().toLowerCase();
      arr = arr.filter((s) => s.name.toLowerCase().includes(t) || s.look.label.toLowerCase().includes(t));
    }
    if (theme !== 'all') arr = arr.filter((s) => s.look.label === theme);
    if (sort === 'bet') arr = [...arr].sort((a, b) => a.minBet - b.minBet);
    if (sort === 'rtp') arr = [...arr].sort((a, b) => b.rtp - a.rtp);
    return arr;
  }, [q, theme, sort]);

  const open = (s: SlotConfig) => {
    if (isOpen(s)) {
      audio.click();
      setActive(s);
      return;
    }
    if (state.balance < s.unlockPrice) {
      toast('Недостаточно средств', 'lose', `Нужно ${fmt(s.unlockPrice)}`);
      return;
    }
    adjust(-s.unlockPrice);
    unlockSlot(s.id);
    audio.coin();
    toast('Слот разблокирован', 'win', s.name);
    setActive(s);
  };

  if (active) return <SlotMachine slot={active} onBack={() => setActive(null)} />;

  return (
    <div className="space-y-3">
      {/* поиск */}
      <div className="panel p-3">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск слота…"
            className="input w-full py-2.5 pl-9 pr-8 text-[13px]"
          />
          {q && (
            <button onClick={() => setQ('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-500">
              <X size={14} />
            </button>
          )}
        </div>

        <div className="chip-row mt-2.5">
          <button className={cn('chip', theme === 'all' && 'on')} onClick={() => { audio.click(); setTheme('all'); }}>
            Все
          </button>
          {SLOT_THEMES.map((t) => (
            <button key={t} className={cn('chip', theme === t && 'on')} onClick={() => { audio.click(); setTheme(t); }}>
              {t}
            </button>
          ))}
        </div>

        <div className="chip-row mt-2">
          <span className="chip pointer-events-none text-slate-500"><Filter size={11} className="mr-1" />Сорт.</span>
          <button className={cn('chip', sort === 'default' && 'on')} onClick={() => { audio.click(); setSort('default'); }}>Обычно</button>
          <button className={cn('chip', sort === 'bet' && 'on')} onClick={() => { audio.click(); setSort('bet'); }}>Ставка</button>
          <button className={cn('chip', sort === 'rtp' && 'on')} onClick={() => { audio.click(); setSort('rtp'); }}>RTP</button>
          <span className="num chip pointer-events-none text-slate-500">{list.length}</span>
        </div>
      </div>

      {/* сетка слотов */}
      <div className="grid grid-cols-2 gap-2.5">
        {list.map((s) => {
          const unlocked = isOpen(s);
          const premium = s.unlockPrice >= 50000;
          return (
            <button
              key={s.id}
              onClick={() => open(s)}
              className="relative overflow-hidden rounded-2xl border p-2.5 text-left active:scale-[.98]"
              style={{
                borderColor: premium ? '#f6c44577' : `${s.look.accent}44`,
                background: `linear-gradient(170deg, ${s.look.frame1}, ${s.look.frame2})`,
                boxShadow: premium ? `0 0 20px -8px ${s.look.accent}` : undefined,
              }}
            >
              {/* атмосферное превью автомата */}
              <div
                className="relative mb-1.5 grid h-[74px] place-items-center overflow-hidden rounded-xl"
                style={{
                  background: `radial-gradient(120% 90% at 50% 10%, ${s.look.bg1}, ${s.look.bg2} 80%)`,
                  boxShadow: 'inset 0 0 20px rgba(0,0,0,.7)',
                }}
              >
                <div
                  className="pointer-events-none absolute inset-x-0 top-0 h-6"
                  style={{ background: `linear-gradient(180deg, ${s.look.accent}2e, transparent)` }}
                />
                <SlotSymbol name={s.cover} size={46} />
              </div>

              <div className="truncate text-[11.5px] font-extrabold" style={{ color: s.look.accent }}>
                {s.name}
              </div>
              <div className="truncate text-[8.5px] uppercase tracking-wider text-white/45">{s.look.label}</div>

              <div className="mt-1 flex items-center justify-between gap-1">
                <span className="num text-[9px] font-bold text-white/55">от {fmt(s.minBet)}</span>
                <span
                  className="num rounded bg-black/40 px-1 py-0.5 text-[8.5px] font-extrabold"
                  style={{ color: s.look.accent }}
                >
                  {(s.rtp * 100).toFixed(0)}%
                </span>
              </div>

              {!unlocked && (
                <div className="relative mt-1 flex items-center justify-center gap-1 rounded-lg bg-black/55 py-1.5 text-[9.5px] font-extrabold text-gold ring-1 ring-gold/25">
                  <Lock size={11} /> {fmt(s.unlockPrice)}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {list.length === 0 && (
        <div className="panel py-10 text-center text-[12px] text-slate-500">Ничего не найдено</div>
      )}
    </div>
  );
}
