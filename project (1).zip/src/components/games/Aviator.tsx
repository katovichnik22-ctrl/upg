import { useCallback, useEffect, useRef, useState } from 'react';
import { Plane, History } from 'lucide-react';
import { GameShell, useGameRound } from './common';
import { useGame } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

/** P(crash >= x) = 0.95/x  →  a flat 95% RTP at every cash-out target */
function crashPoint(): number {
  const r = Math.random();
  if (r < 0.05) return 1;
  return Math.max(1, Math.floor((0.95 / (1 - r)) * 100) / 100);
}

type Phase = 'idle' | 'flying' | 'crashed';

interface Slot {
  bet: number;
  auto: number;
  placed: boolean;      // staked for this round
  cashedAt: number;     // >0 once collected
}

const initSlot = (bet: number, auto: number): Slot => ({ bet, auto, placed: false, cashedAt: 0 });

export default function Aviator() {
  const { canBet, place, settle } = useGameRound('Авиатор');
  const { state } = useGame();

  const [phase, setPhase] = useState<Phase>('idle');
  const [mult, setMult] = useState(1);
  const [history, setHistory] = useState<number[]>([2.14, 1.08, 5.62, 1.41, 12.7, 1.02, 3.38, 1.87]);
  const [slots, setSlots] = useState<[Slot, Slot]>([initSlot(100, 2), initSlot(100, 0)]);

  const raf = useRef(0);
  const multRef = useRef<HTMLDivElement>(null);   // текст множителя
  const liveRef = useRef(1);                      // живой множитель для логики
  const planeRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<SVGPathElement>(null);
  const lineRef = useRef<SVGPathElement>(null);
  const startRef = useRef(0);
  const targetRef = useRef(1);
  const phaseRef = useRef<Phase>('idle');
  const slotsRef = useRef(slots);
  const tickRef = useRef(0);
  slotsRef.current = slots;

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  const setPhaseBoth = (p: Phase) => { phaseRef.current = p; setPhase(p); };

  /** Путь траектории для текущего прогресса */
  const pathFor = (pct: number, closed: boolean) => {
    let d = 'M 0 100';
    for (let i = 0; i <= 40; i++) {
      const x = (i / 40) * pct;
      d += ` L ${x} ${100 - Math.pow(x / 100, 1.7) * 100}`;
    }
    return closed ? `${d} L ${pct} 100 Z` : d;
  };

  /** Кадр анимации: пишем прямо в DOM, без setState */
  const paint = (m: number) => {
    const pct = Math.min(100, ((m - 1) / 9) * 100);
    if (multRef.current) multRef.current.textContent = `x${m.toFixed(2)}`;
    if (fillRef.current) fillRef.current.setAttribute('d', pathFor(pct, true));
    if (lineRef.current) lineRef.current.setAttribute('d', pathFor(pct, false));
    if (planeRef.current) {
      planeRef.current.style.left = `${Math.min(90, pct)}%`;
      planeRef.current.style.bottom = `${Math.min(86, Math.pow(pct / 100, 1.7) * 100)}%`;
    }
  };

  const patch = (i: 0 | 1, p: Partial<Slot>) => {
    setSlots((s) => {
      const n: [Slot, Slot] = [{ ...s[0] }, { ...s[1] }];
      n[i] = { ...n[i], ...p };
      return n;
    });
  };

  /** collect one slot at the given multiplier */
  const cash = useCallback((i: 0 | 1, at: number) => {
    const s = slotsRef.current[i];
    if (!s.placed || s.cashedAt > 0) return;
    const payout = Math.round(s.bet * at);
    patch(i, { cashedAt: at });
    settle(s.bet, payout, `Забрал на x${at.toFixed(2)}`);
  }, [settle]);

  const launch = () => {
    if (phase === 'flying') return;

    /* stake every slot that has a bet configured */
    const next: [Slot, Slot] = [{ ...slots[0] }, { ...slots[1] }];
    let staked = 0;
    ([0, 1] as const).forEach((i) => {
      const b = Math.round(next[i].bet);
      if (b < 1) return;
      if (state.balance < staked + b) return; // not enough for this one
      place(b);
      staked += b;
      next[i] = { ...next[i], bet: b, placed: true, cashedAt: 0 };
    });
    if (staked === 0) {
      canBet(Math.round(slots[0].bet) || 1); // surfaces the "not enough" toast
      return;
    }

    audio.click();
    setSlots(next);
    slotsRef.current = next;
    targetRef.current = crashPoint();
    startRef.current = performance.now();
    setMult(1);
    liveRef.current = 1;
    setPhaseBoth('flying');
    paint(1);

    const loop = (t: number) => {
      const secs = (t - startRef.current) / 1000;
      const shown = Math.floor(Math.max(1, Math.pow(Math.E, 0.19 * secs)) * 100) / 100;

      if (shown >= targetRef.current) {
        liveRef.current = targetRef.current;
        paint(targetRef.current);
        setMult(targetRef.current);
        crash();
        return;
      }
      liveRef.current = shown;
      paint(shown);

      const ti = Math.floor(shown * 10);
      if (ti !== tickRef.current) { tickRef.current = ti; audio.tick(); }

      /* auto cash-out per slot */
      ([0, 1] as const).forEach((i) => {
        const s = slotsRef.current[i];
        if (s.placed && s.cashedAt === 0 && s.auto > 1 && shown >= s.auto) cash(i, s.auto);
      });

      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
  };

  const crash = () => {
    cancelAnimationFrame(raf.current);
    const t = targetRef.current;
    setPhaseBoth('crashed');
    setHistory((h) => [t, ...h].slice(0, 14));
    audio.lose();

    /* anyone still flying loses the stake */
    ([0, 1] as const).forEach((i) => {
      const s = slotsRef.current[i];
      if (s.placed && s.cashedAt === 0) {
        settle(s.bet, 0, `Улетел на x${t.toFixed(2)}`);
      }
    });
    setSlots((s) => [
      { ...s[0], placed: false },
      { ...s[1], placed: false },
    ]);
  };

  const flying = phase === 'flying';
  const crashed = phase === 'crashed';
  const anyActive = slots.some((s) => s.placed && s.cashedAt === 0);

  return (
    <div className="mx-auto max-w-[880px] space-y-4">
      <GameShell
        title="Авиатор"
        subtitle="Забирай, пока самолёт не улетел · две ставки за раунд"
        right={<Plane size={16} className="text-gold" />}
      >
        {/* sky */}
        <div className="relative h-[250px] overflow-hidden rounded-2xl border border-white/8 bg-[radial-gradient(130%_100%_at_20%_100%,#16203a,#0a0e17)] sm:h-[310px]">
          {/* stars */}
          <div
            className="absolute inset-0 opacity-50"
            style={{
              backgroundImage:
                'radial-gradient(1.4px 1.4px at 12% 24%, #fff, transparent), radial-gradient(1.2px 1.2px at 68% 16%, #fff, transparent), radial-gradient(1.6px 1.6px at 42% 62%, #fff, transparent), radial-gradient(1.2px 1.2px at 86% 48%, #fff, transparent), radial-gradient(1.3px 1.3px at 26% 78%, #fff, transparent)',
            }}
          />
          {/* trajectory */}
          <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none" viewBox="0 0 100 100">
            <defs>
              <linearGradient id="avFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={crashed ? '#f43f5e' : '#f6c445'} stopOpacity="0.34" />
                <stop offset="100%" stopColor={crashed ? '#f43f5e' : '#f6c445'} stopOpacity="0" />
              </linearGradient>
            </defs>
            <path ref={fillRef} d="M 0 100 L 0 100 Z" fill="url(#avFill)" />
            <path
              ref={lineRef}
              d="M 0 100"
              fill="none"
              stroke={crashed ? '#f43f5e' : '#f6c445'}
              strokeWidth="1.4"
              vectorEffect="non-scaling-stroke"
            />
          </svg>

          {/* plane */}
          <div
            ref={planeRef}
            className="absolute"
            style={{ left: '0%', bottom: '0%', transform: 'translate(-50%, 50%)' }}
          >
            <Plane
              size={34}
              className={cn(crashed ? 'text-rose-500' : 'text-gold', flying && 'drop-shadow-[0_0_14px_rgba(246,196,69,.95)]')}
              style={{ transform: crashed ? 'rotate(45deg)' : 'rotate(-20deg)' }}
              fill="currentColor"
            />
          </div>

          {/* multiplier */}
          <div className="absolute inset-0 grid place-items-center">
            <div className="text-center">
              <div
                ref={multRef}
                className={cn(
                  'font-display num text-[48px] font-extrabold leading-none sm:text-[66px]',
                  crashed ? 'text-rose-500 text-glow-red' : 'text-white text-glow-gold',
                )}
              >
                x{mult.toFixed(2)}
              </div>
              {crashed && <div className="mt-1 text-[12px] font-extrabold uppercase tracking-[0.24em] text-rose-400">Улетел!</div>}
              {phase === 'idle' && <div className="mt-1 text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500">сделайте ставку</div>}
            </div>
          </div>
        </div>

        {/* round history */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto py-1">
          <History size={13} className="mr-1 shrink-0 text-slate-600" />
          {history.map((h, i) => (
            <span
              key={i}
              className={cn(
                'num shrink-0 rounded-md px-2 py-1 text-[10.5px] font-extrabold',
                h >= 10 ? 'bg-violet-500/15 text-violet-300'
                  : h >= 2 ? 'bg-emerald-500/15 text-emerald-300'
                    : 'bg-rose-500/12 text-rose-300',
                i === 0 && 'pop-in ring-1 ring-white/20',
              )}
            >
              x{h.toFixed(2)}
            </span>
          ))}
        </div>

        {/* two bet panels */}
        <div className="mt-3 grid gap-2.5 md:grid-cols-2">
          {([0, 1] as const).map((i) => {
            const s = slots[i];
            const collected = s.cashedAt > 0;
            return (
              <div
                key={i}
                className={cn(
                  'panel-inset p-3 transition-colors',
                  s.placed && !collected && flying && 'border-gold/40',
                  collected && 'border-emerald-400/45',
                )}
              >
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Ставка {i + 1}</span>
                  {collected && (
                    <span className="num rounded-md bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-extrabold text-emerald-300">
                      x{s.cashedAt.toFixed(2)}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    value={s.bet}
                    disabled={flying}
                    onChange={(e) => patch(i, { bet: Math.max(0, Number(e.target.value) || 0) })}
                    className="input num w-full px-3 py-2 text-center text-sm font-bold"
                  />
                  <div className="chip-row">
                    {[100, 500].map((v) => (
                      <button key={v} className="chip num" disabled={flying} onClick={() => { audio.click(); patch(i, { bet: v }); }}>
                        {v}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-2 flex items-center gap-2">
                  <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider text-slate-500">Авто</span>
                  <input
                    type="number"
                    min={0}
                    step={0.1}
                    placeholder="выкл"
                    value={s.auto || ''}
                    disabled={flying}
                    onChange={(e) => patch(i, { auto: Math.max(0, Number(e.target.value) || 0) })}
                    className="input num w-20 px-2 py-1.5 text-center text-[12px] font-bold"
                  />
                  <div className="chip-row">
                    {[1.5, 2, 5].map((m) => (
                      <button key={m} className={cn('chip', s.auto === m && 'on')} disabled={flying} onClick={() => { audio.click(); patch(i, { auto: m }); }}>
                        x{m}
                      </button>
                    ))}
                  </div>
                </div>

                {flying && s.placed && !collected ? (
                  <button
                    onClick={() => cash(i, liveRef.current)}
                    className="btn btn-green btn-shine mt-2.5 w-full py-3 text-[12.5px] font-extrabold uppercase tracking-wider"
                  >
                    Забрать {fmt(Math.round(s.bet * liveRef.current))}
                  </button>
                ) : (
                  <div className="mt-2.5 rounded-lg bg-white/4 py-2.5 text-center text-[11px] font-bold text-slate-500">
                    {collected ? `Забрано ${fmt(Math.round(s.bet * s.cashedAt))}` : s.bet >= 1 ? 'В игре со следующего раунда' : 'Ставка выключена'}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {!flying && (
          <button
            onClick={launch}
            className="btn btn-gold btn-shine mt-3 w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]"
          >
            <Plane size={16} fill="currentColor" /> Взлёт
          </button>
        )}
        {flying && !anyActive && (
          <div className="mt-3 rounded-xl bg-white/4 py-3.5 text-center text-[12px] font-bold text-slate-500">
            Раунд идёт — дождитесь следующего
          </div>
        )}
      </GameShell>
    </div>
  );
}
