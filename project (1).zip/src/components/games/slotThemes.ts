export interface SlotSymbol {
  s: string;
  w: number;   // weight
  pay: number; // payout for three of a kind
}

export interface SlotTheme {
  id: string;
  name: string;
  sub: string;
  icon: string;
  grad: string;   // tailwind gradient for the cabinet
  accent: string; // glow color
  symbols: SlotSymbol[];
}

export const THEMES: SlotTheme[] = [
  {
    id: 'fruits',
    name: 'Fruit Blast',
    sub: 'Классика 777',
    icon: '🍒',
    grad: 'from-rose-500/25 to-red-900/25',
    accent: '#f43f5e',
    symbols: [
      { s: '🍒', w: 30, pay: 3 },
      { s: '🍋', w: 26, pay: 4 },
      { s: '🍇', w: 22, pay: 6 },
      { s: '🔔', w: 16, pay: 10 },
      { s: '💎', w: 10, pay: 20 },
      { s: '⭐', w: 6, pay: 50 },
      { s: '7️⃣', w: 3, pay: 150 },
    ],
  },
  {
    id: 'egypt',
    name: 'Book of Sands',
    sub: 'Тайны Египта',
    icon: '🔺',
    grad: 'from-amber-400/25 to-yellow-900/25',
    accent: '#f6c445',
    symbols: [
      { s: '🪲', w: 30, pay: 3 },
      { s: '🐍', w: 25, pay: 4 },
      { s: '🏺', w: 21, pay: 6 },
      { s: '🔺', w: 16, pay: 11 },
      { s: '👁️', w: 10, pay: 22 },
      { s: '🐫', w: 6, pay: 55 },
      { s: '📕', w: 3, pay: 180 },
    ],
  },
  {
    id: 'pirate',
    name: 'Pirate Gold',
    sub: 'Сокровища морей',
    icon: '🏴‍☠️',
    grad: 'from-sky-500/25 to-blue-950/25',
    accent: '#38bdf8',
    symbols: [
      { s: '🦜', w: 30, pay: 3 },
      { s: '🧭', w: 25, pay: 4 },
      { s: '⚓', w: 21, pay: 6 },
      { s: '🗺️', w: 16, pay: 10 },
      { s: '💰', w: 10, pay: 24 },
      { s: '🏴‍☠️', w: 6, pay: 60 },
      { s: '💀', w: 3, pay: 200 },
    ],
  },
  {
    id: 'space',
    name: 'Cosmic Spin',
    sub: 'Космос зовёт',
    icon: '🚀',
    grad: 'from-violet-500/25 to-indigo-950/25',
    accent: '#a78bfa',
    symbols: [
      { s: '☄️', w: 30, pay: 3 },
      { s: '🛰️', w: 25, pay: 4 },
      { s: '🌍', w: 21, pay: 6 },
      { s: '👽', w: 16, pay: 11 },
      { s: '🚀', w: 10, pay: 23 },
      { s: '🌌', w: 6, pay: 58 },
      { s: '🛸', w: 3, pay: 190 },
    ],
  },
  {
    id: 'dragon',
    name: 'Dragon Fury',
    sub: 'Логово дракона',
    icon: '🐉',
    grad: 'from-red-500/25 to-rose-950/25',
    accent: '#ef4444',
    symbols: [
      { s: '🔥', w: 30, pay: 3 },
      { s: '🗡️', w: 25, pay: 4 },
      { s: '🛡️', w: 21, pay: 6 },
      { s: '🏯', w: 16, pay: 10 },
      { s: '🥚', w: 10, pay: 25 },
      { s: '🐲', w: 6, pay: 62 },
      { s: '🐉', w: 3, pay: 210 },
    ],
  },
  {
    id: 'sweet',
    name: 'Sweet Rush',
    sub: 'Сахарный бум',
    icon: '🍬',
    grad: 'from-pink-500/25 to-fuchsia-950/25',
    accent: '#f472b6',
    symbols: [
      { s: '🍬', w: 30, pay: 3 },
      { s: '🍭', w: 25, pay: 4 },
      { s: '🧁', w: 21, pay: 6 },
      { s: '🍩', w: 16, pay: 10 },
      { s: '🍰', w: 10, pay: 21 },
      { s: '🍫', w: 6, pay: 52 },
      { s: '🍓', w: 3, pay: 170 },
    ],
  },
  {
    id: 'wild',
    name: 'Wild West',
    sub: 'Дикий Запад',
    icon: '🤠',
    grad: 'from-orange-500/25 to-amber-950/25',
    accent: '#fb923c',
    symbols: [
      { s: '🌵', w: 30, pay: 3 },
      { s: '🐎', w: 25, pay: 4 },
      { s: '🥃', w: 21, pay: 6 },
      { s: '🔫', w: 16, pay: 10 },
      { s: '⭐', w: 10, pay: 22 },
      { s: '🤠', w: 6, pay: 56 },
      { s: '💰', w: 3, pay: 175 },
    ],
  },
  {
    id: 'ocean',
    name: 'Deep Ocean',
    sub: 'Глубины океана',
    icon: '🐬',
    grad: 'from-cyan-500/25 to-teal-950/25',
    accent: '#22d3ee',
    symbols: [
      { s: '🐠', w: 30, pay: 3 },
      { s: '🐚', w: 25, pay: 4 },
      { s: '🦀', w: 21, pay: 6 },
      { s: '🐙', w: 16, pay: 10 },
      { s: '🐬', w: 10, pay: 23 },
      { s: '🦈', w: 6, pay: 57 },
      { s: '🧜', w: 3, pay: 185 },
    ],
  },
  {
    id: 'lucky',
    name: 'Lucky Clover',
    sub: 'Ирландская удача',
    icon: '🍀',
    grad: 'from-emerald-500/25 to-green-950/25',
    accent: '#34d399',
    symbols: [
      { s: '🍀', w: 30, pay: 3 },
      { s: '🎩', w: 25, pay: 4 },
      { s: '🌈', w: 21, pay: 6 },
      { s: '🪙', w: 16, pay: 10 },
      { s: '🔮', w: 10, pay: 24 },
      { s: '🧙', w: 6, pay: 59 },
      { s: '🏆', w: 3, pay: 195 },
    ],
  },
  {
    id: 'vegas',
    name: 'Vegas Nights',
    sub: 'Ночной Вегас',
    icon: '🎰',
    grad: 'from-yellow-400/25 to-orange-900/25',
    accent: '#facc15',
    symbols: [
      { s: '🎲', w: 30, pay: 3 },
      { s: '♠️', w: 25, pay: 4 },
      { s: '♥️', w: 21, pay: 6 },
      { s: '🃏', w: 16, pay: 11 },
      { s: '💵', w: 10, pay: 25 },
      { s: '💎', w: 6, pay: 60 },
      { s: '🎰', w: 3, pay: 220 },
    ],
  },
];
