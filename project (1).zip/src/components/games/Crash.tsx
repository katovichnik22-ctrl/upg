import { useEffect, useRef, useState } from 'react';
import { Rocket, TrendingUp } from 'lucide-react';
import { BetBar, GameShell, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

/** P(crash >= x) = 0.95/x  →  a flat 95% RTP at every cash-out target */
function crashPoint(): number {
  const r = Math.random();
  if (r < 0.05) return 1;
  return Math.max(1, Math.floor((0.95 / (1 - r)) * 100) / 100);
}

type Phase = 'idle' | 'flying' | 'crashed' | 'cashed';

export default function Crash() {
  const { canBet, place, settle } = useGameRound('Краш');
  const [bet, setBet] = useState(100);
  const [auto, setAuto] = useState(2);
  const [mult, setMult] = useState(1);
  const [phase, setPhase] = useState<Phase>('idle');
  const [history, setHistory] = useState<number[]>([1.32, 4.71, 1.05, 2.18, 8.42, 1.67, 3.05]);
  const [cashedAt, setCashedAt] = useState(0);

  const raf = useRef(0);
  const multRef = useRef<HTMLDivElement>(null);   // текст множителя
  const liveRef = useRef(1);                      // живой множитель для логики
  const rocketRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<SVGPathElement>(null);
  const lineRef = useRef<SVGPathElement>(null);
  const startRef = useRef(0);
  const targetRef = useRef(1);
  const betRef = useRef(0);
  const autoRef = useRef(2);
  const phaseRef = useRef<Phase>('idle');
  const tickRef = useRef(0);

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  const setPhaseBoth = (p: Phase) => { phaseRef.current = p; setPhase(p); };

  /** Путь кривой для текущего прогресса */
  const pathFor = (pct: number, closed: boolean) => {
    let d = 'M 0 100';
    for (let i = 0; i <= 40; i++) {
      const x = (i / 40) * pct;
      d += ` L ${x} ${100 - Math.pow(x / 100, 1.7) * 100}`;
    }
    return closed ? `${d} L ${pct} 100 Z` : d;
  };

  /** Кадр анимации: пишем прямо в DOM, без setState */
  const paint = (m: number) => {
    const pct = Math.min(100, ((m - 1) / 9) * 100);
    if (multRef.current) multRef.current.textContent = `x${m.toFixed(2)}`;
    if (fillRef.current) fillRef.current.setAttribute('d', pathFor(pct, true));
    if (lineRef.current) lineRef.current.setAttribute('d', pathFor(pct, false));
    if (rocketRef.current) {
      rocketRef.current.style.left = `${Math.min(92, pct)}%`;
      rocketRef.current.style.bottom = `${Math.min(88, Math.pow(pct / 100, 1.7) * 100)}%`;
    }
  };

  const launch = () => {
    if (phase === 'flying') return;
    const b = Math.round(bet);
    if (!canBet(b)) return;
    audio.click();
    place(b);
    betRef.current = b;
    autoRef.current = auto;
    targetRef.current = crashPoint();
    startRef.current = performance.now();
    setMult(1);
    liveRef.current = 1;
    setCashedAt(0);
    setPhaseBoth('flying');
    paint(1);

    const loop = (t: number) => {
      const secs = (t - startRef.current) / 1000;
      const m = Math.max(1, Math.pow(Math.E, 0.19 * secs));
      const shown = Math.floor(m * 100) / 100;

      if (shown >= targetRef.current) {
        liveRef.current = targetRef.current;
        paint(targetRef.current);
        setMult(targetRef.current);
        crash();
        return;
      }
      liveRef.current = shown;
      paint(shown);

      const ti = Math.floor(shown * 10);
      if (ti !== tickRef.current) { tickRef.current = ti; audio.tick(); }

      /* auto cash-out */
      if (autoRef.current > 1 && shown >= autoRef.current && phaseRef.current === 'flying') {
        cashout(shown);
        return;
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
  };

  const crash = () => {
    cancelAnimationFrame(raf.current);
    setPhaseBoth('crashed');
    const t = targetRef.current;
    setHistory((h) => [t, ...h].slice(0, 12));
    settle(betRef.current, 0, `Краш на x${t.toFixed(2)}`);
  };

  const cashout = (atRaw?: number) => {
    if (phaseRef.current !== 'flying') return;
    cancelAnimationFrame(raf.current);
    const at = atRaw ?? liveRef.current;
    setCashedAt(at);
    setMult(at);
    setPhaseBoth('cashed');
    const payout = Math.round(betRef.current * at);
    setHistory((h) => [targetRef.current, ...h].slice(0, 12));
    settle(betRef.current, payout, `Забрал на x${at.toFixed(2)}`);
  };

  const flying = phase === 'flying';
  const crashed = phase === 'crashed';

  return (
    <div className="mx-auto max-w-[820px] space-y-4">
      <GameShell
        title="Краш"
        subtitle="Забирай до того, как ракета взорвётся"
        right={<Rocket size={16} className="text-gold" />}
      >
        {/* graph */}
        <div className="relative h-[240px] overflow-hidden rounded-2xl border border-white/8 bg-[radial-gradient(120%_100%_at_50%_110%,#131a2b,#0a0e17)] sm:h-[290px]">
          {/* grid */}
          <div
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage: 'linear-gradient(rgba(148,163,216,.07) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,216,.07) 1px, transparent 1px)',
              backgroundSize: '48px 40px',
            }}
          />
          {/* curve */}
          <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none" viewBox="0 0 100 100">
            <defs>
              <linearGradient id="crashFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={crashed ? '#f43f5e' : '#f6c445'} stopOpacity="0.35" />
                <stop offset="100%" stopColor={crashed ? '#f43f5e' : '#f6c445'} stopOpacity="0" />
              </linearGradient>
            </defs>
            <path ref={fillRef} d="M 0 100 L 0 100 Z" fill="url(#crashFill)" />
            <path
              ref={lineRef}
              d="M 0 100"
              fill="none"
              stroke={crashed ? '#f43f5e' : '#f6c445'}
              strokeWidth="1.2"
              vectorEffect="non-scaling-stroke"
            />
          </svg>

          {/* rocket */}
          <div
            ref={rocketRef}
            className="absolute transition-none"
            style={{ left: '0%', bottom: '0%', transform: 'translate(-50%, 50%)' }}
          >
            <Rocket
              size={30}
              className={cn(crashed ? 'text-rose-500' : 'text-gold', flying && 'drop-shadow-[0_0_12px_rgba(246,196,69,.9)]')}
              style={{ transform: crashed ? 'rotate(135deg)' : 'rotate(-45deg)' }}
            />
          </div>

          {/* multiplier */}
          <div className="absolute inset-0 grid place-items-center">
            <div className="text-center">
              <div ref={multRef} className={cn(
                'font-display num text-[46px] font-extrabold leading-none sm:text-[62px]',
                crashed ? 'text-rose-500 text-glow-red' : phase === 'cashed' ? 'text-emerald-400 text-glow-green' : 'text-white',
                flying && 'text-glow-gold',
              )}>
                x{mult.toFixed(2)}
              </div>
              {crashed && <div className="mt-1 text-[12px] font-extrabold uppercase tracking-[0.24em] text-rose-400">Взрыв!</div>}
              {phase === 'cashed' && (
                <div className="num mt-1 text-[12px] font-extrabold text-emerald-300">
                  Забрано {fmt(Math.round(betRef.current * cashedAt))}
                </div>
              )}
              {phase === 'idle' && <div className="mt-1 text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500">готов к запуску</div>}
            </div>
          </div>
        </div>

        {/* history */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto py-1">
          <TrendingUp size={13} className="mr-1 shrink-0 text-slate-600" />
          {history.map((h, i) => (
            <span
              key={i}
              className={cn(
                'num shrink-0 rounded-md px-2 py-1 text-[10.5px] font-extrabold',
                h >= 5 ? 'bg-emerald-500/15 text-emerald-300' : h >= 2 ? 'bg-gold/12 text-gold' : 'bg-rose-500/12 text-rose-300',
                i === 0 && 'pop-in ring-1 ring-white/20',
              )}
            >
              x{h.toFixed(2)}
            </span>
          ))}
        </div>

        <div className="mt-3 space-y-3">
          <BetBar amount={bet} setAmount={setBet} disabled={flying} />
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Автовывод</span>
            <input
              type="number"
              min={1.1}
              step={0.1}
              value={auto}
              disabled={flying}
              onChange={(e) => setAuto(Math.max(1.1, Number(e.target.value) || 1.1))}
              className="input num w-24 px-3 py-1.5 text-center text-[13px] font-bold"
            />
            <div className="flex gap-1.5">
              {[1.5, 2, 3, 5, 10].map((m) => (
                <button key={m} className={cn('chip', auto === m && 'on')} disabled={flying} onClick={() => { audio.click(); setAuto(m); }}>
                  x{m}
                </button>
              ))}
            </div>
          </div>
          {flying ? (
            <button onClick={() => cashout()} className="btn btn-green btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]">
              Забрать · {fmt(Math.round(bet * liveRef.current))}
            </button>
          ) : (
            <button onClick={launch} className="btn btn-gold btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]">
              <Rocket size={16} /> Запустить · {fmt(bet)}
            </button>
          )}
        </div>
      </GameShell>
    </div>
  );
}
