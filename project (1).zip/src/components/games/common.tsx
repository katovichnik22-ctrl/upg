import { Wallet } from 'lucide-react';
import { useGame } from '../../lib/store';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { applyWin, forcedOutcome } from '../../admin/adminCore';

/** Shared bet controls used by every casino game. */
export function BetBar({
  amount, setAmount, disabled, max,
}: {
  amount: number;
  setAmount: (n: number) => void;
  disabled?: boolean;
  max?: number;
}) {
  const { state } = useGame();
  const cap = max ?? Math.max(1, state.balance);
  const set = (v: number) => {
    audio.click();
    setAmount(Math.max(1, Math.min(cap, Math.round(v))));
  };
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex items-center gap-2">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Ставка</span>
        <input
          type="number"
          min={1}
          value={amount}
          disabled={disabled}
          onChange={(e) => setAmount(Math.max(1, Number(e.target.value) || 1))}
          className="input num w-28 px-3 py-2 text-center text-sm font-bold"
        />
        <span className="text-xs font-bold text-slate-500">₽</span>
      </div>
      <div className="chip-row w-full sm:w-auto sm:flex-wrap">
        {[50, 100, 500, 1000].map((v) => (
          <button key={v} className="chip num" disabled={disabled} onClick={() => set(v)}>{v}</button>
        ))}
        <button className="chip" disabled={disabled} onClick={() => set(amount / 2)}>½</button>
        <button className="chip" disabled={disabled} onClick={() => set(amount * 2)}>×2</button>
        <button className="chip" disabled={disabled} onClick={() => set(state.balance)}>МАКС</button>
      </div>
      <div className="ml-auto hidden items-center gap-1.5 text-[11px] font-bold text-slate-500 sm:flex">
        <Wallet size={12} className="text-gold" />
        <span className="num text-slate-300">{fmt(state.balance)}</span>
      </div>
    </div>
  );
}

/** Hook wiring a game round into balance, stats, history and toasts. */
export function useGameRound(gameName: string) {
  const { state, adjust, log, addStats, toast } = useGame();

  const canBet = (bet: number): boolean => {
    if (bet < 1) return false;
    if (state.balance < bet) {
      toast('Недостаточно средств', 'lose', 'Пополните баланс');
      return false;
    }
    return true;
  };

  const place = (bet: number) => {
    adjust(-bet);
  };

  const settle = (bet: number, rawPayout: number, detail: string) => {
    /* админ-переопределения: режим бога и множитель выигрыша */
    const forced = forcedOutcome();
    let payout = rawPayout;
    if (forced === true && payout <= 0) payout = bet * 2;
    if (forced === false) payout = 0;
    if (payout > 0) payout = applyWin(payout);

    const win = payout > 0;
    if (win) adjust(payout);
    addStats({
      gamesPlayed: 1,
      gameWins: win ? 1 : 0,
      wagered: bet,
      bestWin: Math.max(0, payout - state.stats.bestWin),
    });
    log({
      kind: 'game',
      text: `${gameName}: ${detail}`,
      amount: win ? payout - bet : -bet,
      success: win,
    });
    if (win) {
      if (payout >= bet * 5) audio.bigWin(); else audio.win();
      toast(`${gameName} — победа!`, 'win', `${detail} · +${fmt(payout - bet)}`);
    } else {
      audio.lose();
      toast(`${gameName} — проигрыш`, 'lose', detail);
    }
  };

  return { canBet, place, settle, balance: state.balance, fast: state.settings.fast };
}

export function GameShell({
  title, subtitle, children, right,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  right?: React.ReactNode;
}) {
  return (
    <div className="panel relative overflow-hidden p-4 sm:p-5">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-gold/5 to-transparent" />
      <div className="relative mb-3 flex items-center justify-between gap-2">
        <div>
          <h2 className="font-display text-[13px] font-bold uppercase tracking-[0.14em] text-slate-200">{title}</h2>
          {subtitle && <p className="mt-0.5 text-[10.5px] text-slate-500">{subtitle}</p>}
        </div>
        {right}
      </div>
      {children}
    </div>
  );
}
