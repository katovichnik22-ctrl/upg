import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, History, Play, Square, Info, Minus, Plus } from 'lucide-react';
import type { SlotConfig } from '../../data/slots';
import { symbol, WILD, BONUS, SCATTER, WILD_MULTS } from '../../data/slotSymbols';
import { SlotSymbol } from '../SlotSymbol';
import { Reel, ROWS, type ReelHandle } from './Reel';
import WinPopup, { type WinPopupData } from './WinPopup';
import { BetBar, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

const REELS = 5;
/** линии выплат: ряд для каждого барабана */
const LINES: number[][] = [
  [1, 1, 1, 1, 1],
  [0, 0, 0, 0, 0],
  [2, 2, 2, 2, 2],
  [0, 1, 2, 1, 0],
  [2, 1, 0, 1, 2],
];
const LINE_OPTIONS = [1, 3, 5];
const BULBS = 11;

function pick(pool: string[]): string {
  const total = pool.reduce((a, id) => a + symbol(id).weight, 0);
  let r = Math.random() * total;
  for (const id of pool) {
    r -= symbol(id).weight;
    if (r <= 0) return id;
  }
  return pool[0];
}

interface WinLine { line: number; count: number; sym: string; mult: number }

export default function SlotMachine({ slot, onBack }: { slot: SlotConfig; onBack: () => void }) {
  const { canBet, place, settle, fast } = useGameRound(slot.name);
  const L = slot.look;

  const [bet, setBet] = useState(slot.minBet);
  const [lines, setLines] = useState(1);
  const [busyUi, setBusyUi] = useState(false);
  const [history, setHistory] = useState<number[]>([]);
  const [auto, setAuto] = useState(0);
  const [showPay, setShowPay] = useState(false);
  const [lastWin, setLastWin] = useState(0);
  const [popup, setPopup] = useState<WinPopupData | null>(null);
  const [shake, setShake] = useState(false);
  const [bulbOn, setBulbOn] = useState(false);

  const busy = useRef(false);
  const timers = useRef<number[]>([]);
  const reels = useRef<Array<ReelHandle | null>>(Array(REELS).fill(null));
  const autoRef = useRef(0);
  autoRef.current = auto;

  /** стартовая раскладка барабанов */
  const initial = useMemo(
    () => Array.from({ length: REELS }, () =>
      Array.from({ length: ROWS }, () => pick(slot.symbols))),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [slot.id],
  );

  useEffect(() => () => timers.current.forEach(window.clearTimeout), []);

  const totalBet = bet * lines;

  /** подсчёт линий: Wild подменяет символ, Bonus/Scatter линии не образуют */
  const evaluate = useCallback((g: string[][]) => {
    const res: WinLine[] = [];
    for (let li = 0; li < lines; li++) {
      const seq = LINES[li].map((row, reel) => g[reel][row]);
      const base = seq.find((s) => s !== WILD);
      if (!base || base === BONUS || base === SCATTER) continue;

      let count = 0;
      for (const s of seq) {
        if (s === base || s === WILD) count++;
        else break;
      }
      if (count < 2) continue;

      const m = slot.multipliers;
      let mult = count === 5 ? m.m5 : count === 4 ? m.m4 : count === 3 ? m.m3 : m.m2;
      mult *= Math.max(0.3, symbol(base).pay5 / 25);
      /* Wild в линии добавляет свой множитель */
      if (seq.slice(0, count).includes(WILD)) {
        mult *= WILD_MULTS[Math.floor(Math.random() * WILD_MULTS.length)];
      }
      res.push({ line: li, count, sym: base, mult: Math.round(mult * 100) / 100 });
    }
    return res;
  }, [lines, slot.multipliers]);

  const finish = useCallback((g: string[][], staked: number) => {
    const wins = evaluate(g);
    const totalMult = wins.reduce((a, x) => a + x.mult, 0);
    const payout = Math.round(staked * totalMult);
    setLastWin(payout);
    setHistory((h) => [totalMult, ...h].slice(0, 12));

    /* подсветка выигрышных ячеек — императивно, без ре-рендера ленты */
    const perReel: Array<Set<number>> = Array.from({ length: REELS }, () => new Set<number>());
    for (const w of wins) {
      for (let r = 0; r < w.count; r++) perReel[r].add(LINES[w.line][r]);
    }
    reels.current.forEach((rl, i) => rl?.highlight(perReel[i], L.accent));

    settle(staked, payout, wins.length ? `${wins.length} лин. · x${totalMult.toFixed(2)}` : 'без выигрыша');

    /* крупный выигрыш — попап, мелкий — тост из settle */
    if (totalMult >= 5) {
      const big = totalMult >= 20;
      if (big) {
        setShake(true);
        window.setTimeout(() => setShake(false), 500);
      }
      setPopup({
        amount: payout, mult: totalMult, big, accent: L.accent,
        note: wins.length > 1 ? `${wins.length} выигрышных линии` : undefined,
      });
    }

    busy.current = false;
    setBusyUi(false);

    if (autoRef.current > 0) {
      setAuto((a) => Math.max(0, a - 1));
      timers.current.push(window.setTimeout(() => { if (autoRef.current > 0) spin(); }, totalMult >= 5 ? 1400 : 650));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [evaluate, settle, L.accent]);

  const spin = useCallback(() => {
    if (busy.current) return;
    const staked = Math.round(bet) * lines;
    if (!canBet(staked)) { setAuto(0); return; }

    busy.current = true;
    setBusyUi(true);
    setPopup(null);
    setLastWin(0);
    audio.click();
    place(staked);

    const target = Array.from({ length: REELS }, () =>
      Array.from({ length: ROWS }, () => pick(slot.symbols)));

    timers.current.forEach(window.clearTimeout);
    timers.current = [];

    const dur = fast ? 620 : 1000;
    const gap = fast ? 120 : 210;
    let done = 0;

    for (let i = 0; i < REELS; i++) {
      reels.current[i]?.spin(target[i], i * gap, dur, () => {
        audio.blip(560 + i * 40, 0.035, 'square', 0.06);
        setBulbOn((v) => !v);                 // лампочки мигают на остановке
        done++;
        if (done === REELS) finish(target, staked);
      });
    }
  }, [bet, lines, canBet, place, slot.symbols, fast, finish]);

  const bulbs = useMemo(() => Array.from({ length: BULBS }, (_, i) => i), []);
  const anySpinning = busyUi;

  return (
    <div className="space-y-2.5">
      {/* верхняя строка */}
      <div className="panel flex items-center gap-2 p-2">
        <button className="chip shrink-0" onClick={() => { audio.click(); setAuto(0); onBack(); }}>
          <ChevronLeft size={15} />
        </button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[12px] font-extrabold" style={{ color: L.accent }}>{slot.name}</div>
          <div className="num text-[9px] uppercase tracking-wider text-slate-500">
            {L.label} · RTP {(slot.rtp * 100).toFixed(0)}%
          </div>
        </div>
        <button className="chip shrink-0" onClick={() => { audio.click(); setShowPay((v) => !v); }}>
          <Info size={14} />
        </button>
      </div>

      {/* ---------- КОРПУС ---------- */}
      <div
        className={cn('relative overflow-hidden rounded-2xl p-2', shake && 'shake')}
        style={{
          background: L.frame === 'wood'
            ? `repeating-linear-gradient(92deg, ${L.frame1} 0 7px, ${L.frame2} 7px 13px)`
            : `linear-gradient(180deg, ${L.frame1}, ${L.frame2})`,
          border: `2px solid ${L.accent}77`,
          boxShadow: `0 0 22px -10px ${L.accent}`,
        }}
      >
        {/* лампочки по периметру */}
        <div className="pointer-events-none absolute inset-0">
          {bulbs.map((i) => {
            const on = bulbOn === (i % 2 === 0);
            const p = (i / (BULBS - 1)) * 100;
            return (
              <span key={`t${i}`} className="absolute h-1.5 w-1.5 rounded-full"
                style={{
                  left: `${p}%`, top: 3, transform: 'translateX(-50%)',
                  background: on ? L.accent : `${L.accent}33`,
                  boxShadow: on ? `0 0 6px ${L.accent}` : 'none',
                  transition: 'background .18s, box-shadow .18s',
                }} />
            );
          })}
          {bulbs.map((i) => {
            const on = bulbOn === (i % 2 !== 0);
            const p = (i / (BULBS - 1)) * 100;
            return (
              <span key={`b${i}`} className="absolute h-1.5 w-1.5 rounded-full"
                style={{
                  left: `${p}%`, bottom: 3, transform: 'translateX(-50%)',
                  background: on ? L.accent : `${L.accent}33`,
                  boxShadow: on ? `0 0 6px ${L.accent}` : 'none',
                  transition: 'background .18s, box-shadow .18s',
                }} />
            );
          })}
        </div>

        {/* баннер-логотип */}
        <div className="relative mx-1 mb-2 mt-2 grid place-items-center">
          <div
            className="font-display text-[15px] font-black uppercase leading-none tracking-[0.06em]"
            style={{
              background: `linear-gradient(180deg, ${L.titleTop}, ${L.titleBottom})`,
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
              WebkitTextStroke: '0.7px rgba(0,0,0,.55)',
              filter: `drop-shadow(0 2px 0 rgba(0,0,0,.55))`,
            }}
          >
            {slot.banner}
          </div>
          <div className="mt-0.5 text-[7.5px] font-bold uppercase tracking-[0.3em] text-white/35">
            NIKGRAGER CASINO
          </div>
        </div>

        {/* поле: стрелки + барабаны */}
        <div className="relative flex items-center gap-1">
          <div className="shrink-0 text-[15px] leading-none" style={{ color: L.accent }}>◄</div>

          <div
            className="relative min-w-0 flex-1 overflow-hidden rounded-xl p-1"
            style={{
              background: `radial-gradient(125% 95% at 50% 0%, ${L.bg1}, ${L.bg2} 78%)`,
              boxShadow: 'inset 0 0 30px rgba(0,0,0,.7)',
            }}
          >
            {/* декор фона */}
            <ThemeDecor kind={L.decor} color={L.decorColor} />
            <div className="relative grid grid-cols-5 gap-1">
              {initial.map((col, i) => (
                <Reel
                  key={i}
                  ref={(el) => { reels.current[i] = el; }}
                  pool={slot.symbols}
                  initial={col}
                />
              ))}
            </div>
          </div>

          <div className="shrink-0 text-[15px] leading-none" style={{ color: L.accent }}>►</div>
        </div>

        {/* панель автомата */}
        <div
          className="relative mt-2 grid grid-cols-3 gap-1 rounded-xl p-1.5"
          style={{ background: 'rgba(0,0,0,.45)', border: `1px solid ${L.accent}33` }}
        >
          {[
            ['Ставка', fmt(totalBet)],
            ['Линии', String(lines)],
            ['Выигрыш', lastWin > 0 ? fmt(lastWin) : '—'],
          ].map(([k, v], i) => (
            <div key={k} className="text-center">
              <div className="text-[7.5px] font-bold uppercase tracking-wider text-white/40">{k}</div>
              <div className="num truncate text-[12px] font-extrabold"
                style={{ color: i === 2 && lastWin > 0 ? '#4ade80' : '#fff' }}>
                {v}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* управление */}
      <div className="panel p-3">
        <div className="mb-2 flex items-center gap-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Линии</span>
          <div className="chip-row">
            {LINE_OPTIONS.map((n) => (
              <button key={n} className={cn('chip', lines === n && 'on')} disabled={anySpinning}
                onClick={() => { audio.click(); setLines(n); }}>{n}</button>
            ))}
          </div>
        </div>

        <BetBar amount={bet} setAmount={(v) => setBet(Math.max(slot.minBet, Math.min(slot.maxBet, v)))}
          disabled={anySpinning} max={slot.maxBet} />

        <div className="mt-3 flex items-center justify-center gap-3">
          <button
            className="chip h-11 w-11 justify-center"
            disabled={anySpinning}
            onClick={() => { audio.click(); setBet((v) => Math.max(slot.minBet, Math.round(v / 2))); }}
          >
            <Minus size={16} />
          </button>

          <button
            onClick={() => (auto > 0 ? setAuto(0) : spin())}
            disabled={anySpinning && auto === 0}
            className={cn(
              'grid h-[86px] w-[86px] shrink-0 place-items-center rounded-full font-display font-extrabold uppercase transition-transform active:scale-95',
              !anySpinning && auto === 0 && 'spin-pulse',
            )}
            style={{
              background: auto > 0
                ? 'radial-gradient(circle at 38% 30%,#ff9aa2,#b81228)'
                : `radial-gradient(circle at 38% 30%,#fff0b8,${L.accent} 48%,#8a5c06)`,
              border: '3px solid rgba(255,255,255,.4)',
              boxShadow: `0 6px 18px -4px ${L.accent}`,
              color: '#2b1f02',
            }}
          >
            {auto > 0 ? <Square size={24} /> : anySpinning ? '…' : <Play size={28} fill="currentColor" />}
          </button>

          <button
            className="chip h-11 w-11 justify-center"
            disabled={anySpinning}
            onClick={() => { audio.click(); setBet((v) => Math.min(slot.maxBet, Math.max(slot.minBet, v * 2))); }}
          >
            <Plus size={16} />
          </button>
        </div>

        <div className="chip-row mt-2 justify-center">
          <span className="chip pointer-events-none text-slate-500">Авто</span>
          {[10, 25, 50].map((n) => (
            <button key={n} className="chip" disabled={auto > 0}
              onClick={() => { audio.click(); setAuto(n); if (!busy.current) spin(); }}>×{n}</button>
          ))}
          {auto > 0 && <span className="num chip pointer-events-none text-gold">{auto}</span>}
        </div>
      </div>

      {/* история */}
      {history.length > 0 && (
        <div className="panel flex items-center gap-1.5 overflow-x-auto p-2.5">
          <History size={13} className="mr-0.5 shrink-0 text-slate-600" />
          {history.map((m, i) => (
            <span key={i} className={cn('num shrink-0 rounded-md px-1.5 py-1 text-[10px] font-extrabold',
              m >= 10 ? 'bg-violet-500/15 text-violet-300'
                : m > 0 ? 'bg-emerald-500/15 text-emerald-300'
                  : 'bg-white/5 text-slate-500')}>
              {m > 0 ? `x${m.toFixed(1)}` : '—'}
            </span>
          ))}
        </div>
      )}

      {/* таблица выплат */}
      {showPay && (
        <div className="panel fade-up p-3">
          <div className="mb-2 font-display text-[10.5px] font-bold uppercase tracking-[0.16em] text-slate-400">
            Символы и выплаты
          </div>
          <div className="grid grid-cols-4 gap-2">
            {slot.symbols.map((id) => {
              const d = symbol(id);
              return (
                <div key={id} className="panel-inset flex flex-col items-center gap-1 p-2">
                  <SlotSymbol name={id} size={34} />
                  <span className="truncate text-[8.5px] font-bold text-slate-400">{d.label}</span>
                  <span className="num text-[8.5px] font-extrabold" style={{ color: L.accent }}>
                    {d.pay5 > 0 ? `x${d.pay5}` : 'спец'}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="mt-2 text-[10px] leading-relaxed text-slate-600">
            5 подряд — x{slot.multipliers.m5} · 4 — x{slot.multipliers.m4} · 3 — x{slot.multipliers.m3} · 2 — x{slot.multipliers.m2}.
            Wild заменяет любой символ и умножает линию на ×2 или ×3.
          </div>
        </div>
      )}

      {popup && <WinPopup data={popup} onClose={() => setPopup(null)} />}
    </div>
  );
}

/** Лёгкий декор фона: чистый CSS, без картинок */
function ThemeDecor({ kind, color }: { kind: string; color: string }) {
  const items = useMemo(() => Array.from({ length: 7 }, (_, i) => ({
    left: `${8 + i * 13}%`,
    top: `${10 + ((i * 37) % 70)}%`,
    size: 4 + (i % 3) * 3,
    delay: `${i * 0.7}s`,
  })), []);
  if (kind === 'none') return null;

  const round = kind === 'bubbles' || kind === 'sparks' || kind === 'stars';
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {items.map((it, i) => (
        <span
          key={i}
          className="absolute float-slow"
          style={{
            left: it.left, top: it.top,
            width: it.size, height: kind === 'clouds' ? it.size * 0.6 : it.size,
            background: color,
            opacity: 0.22,
            borderRadius: round ? '50%' : kind === 'clouds' ? 99 : 2,
            animationDelay: it.delay,
          }}
        />
      ))}
    </div>
  );
}
