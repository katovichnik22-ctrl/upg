import { useEffect, useRef, useState } from 'react';
import { CircleDollarSign, Flame } from 'lucide-react';
import { BetBar, GameShell, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

type Side = 'heads' | 'tails';
const PAYOUT = 1.95; // 2.5% house edge

export default function CoinFlip() {
  const { canBet, place, settle, fast } = useGameRound('Орёл и решка');
  const [bet, setBet] = useState(100);
  const [choice, setChoice] = useState<Side>('heads');
  const [flipping, setFlipping] = useState(false);
  const [face, setFace] = useState<Side>('heads');
  const [spin, setSpin] = useState(0);
  const [result, setResult] = useState<{ side: Side; win: boolean } | null>(null);
  const [history, setHistory] = useState<Side[]>(['heads', 'tails', 'tails', 'heads', 'tails']);
  const [streak, setStreak] = useState(0);
  const timer = useRef<number>(0);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const flip = () => {
    if (flipping) return;
    const b = Math.round(bet);
    if (!canBet(b)) return;
    audio.click();
    place(b);
    setFlipping(true);
    setResult(null);

    const landed: Side = Math.random() < 0.5 ? 'heads' : 'tails';
    const dur = fast ? 1300 : 2200;
    const turns = fast ? 6 : 10;
    /* The visible face depends on the PARITY of the total half-turns, not on
       the increment. Land on an absolute value whose parity matches the side:
       even = heads, odd = tails. */
    setSpin((s) => {
      const spun = s + turns * 2;               // full turns keep parity
      const wanted = landed === 'heads' ? 0 : 1;
      return spun + ((wanted - (spun % 2) + 2) % 2);
    });

    /* ticking while it spins */
    const t0 = Date.now();
    const tick = () => {
      if (Date.now() - t0 > dur - 150) return;
      audio.blip(700 + Math.random() * 400, 0.02, 'square', 0.04);
      timer.current = window.setTimeout(tick, 110);
    };
    tick();

    window.setTimeout(() => {
      setFace(landed);
      setFlipping(false);
      setHistory((h) => [landed, ...h].slice(0, 14));
      const win = landed === choice;
      setStreak((s) => (win ? s + 1 : 0));
      setResult({ side: landed, win });
      const payout = win ? Math.round(b * PAYOUT) : 0;
      settle(b, payout, `${landed === 'heads' ? 'Орёл' : 'Решка'} — ${win ? 'угадал' : 'мимо'}`);
    }, dur);
  };

  const Coin = ({ side }: { side: Side }) => (
    <div
      className={cn(
        'grid h-full w-full place-items-center rounded-full [backface-visibility:hidden]',
        side === 'heads'
          ? 'bg-[radial-gradient(circle_at_35%_30%,#ffe9a8,#f6c445_45%,#b8790c)]'
          : 'bg-[radial-gradient(circle_at_35%_30%,#e8edff,#9fb0d6_45%,#4a5878)]',
      )}
      style={{
        transform: side === 'tails' ? 'rotateY(180deg)' : undefined,
        position: 'absolute',
        inset: 0,
        boxShadow: 'inset 0 -6px 16px rgba(0,0,0,.35), inset 0 6px 14px rgba(255,255,255,.5)',
      }}
    >
      <div
        className="grid h-[76%] w-[76%] place-items-center rounded-full"
        style={{ boxShadow: 'inset 0 0 0 3px rgba(0,0,0,.12)' }}
      >
        <span className={cn('font-display text-[40px] font-black sm:text-[52px]', side === 'heads' ? 'text-amber-900/80' : 'text-slate-700/80')}>
          {side === 'heads' ? '🦅' : '₽'}
        </span>
      </div>
    </div>
  );

  return (
    <div className="mx-auto max-w-[720px] space-y-4">
      <GameShell
        title="Орёл и решка"
        subtitle={`Угадай сторону · выплата x${PAYOUT}`}
        right={<CircleDollarSign size={16} className="text-gold" />}
      >
        {/* coin stage */}
        <div className="relative grid h-[230px] place-items-center overflow-hidden rounded-2xl border border-white/8 bg-[radial-gradient(120%_100%_at_50%_0%,#1a2133,#0b0f18)] sm:h-[280px]">
          <div
            className="absolute h-40 w-40 rounded-full blur-3xl"
            style={{ background: face === 'heads' ? 'rgba(246,196,69,.22)' : 'rgba(148,163,216,.18)' }}
          />
          <div
            className="relative h-[136px] w-[136px] sm:h-[168px] sm:w-[168px]"
            style={{ perspective: '900px' }}
          >
            <div
              className="relative h-full w-full"
              style={{
                transformStyle: 'preserve-3d',
                transform: `rotateY(${spin * 180}deg)`,
                transition: `transform ${flipping ? (fast ? 1300 : 2200) : 0}ms cubic-bezier(.22,.9,.24,1)`,
              }}
            >
              <Coin side="heads" />
              <Coin side="tails" />
            </div>
          </div>

          {result && !flipping && (
            <div
              className={cn(
                'pop-in absolute bottom-3 rounded-xl px-4 py-2 text-[13px] font-extrabold',
                result.win ? 'bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/40' : 'bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/40',
              )}
            >
              {result.side === 'heads' ? 'Орёл' : 'Решка'} · {result.win ? `+${fmt(Math.round(bet * PAYOUT) - bet)}` : 'мимо'}
            </div>
          )}
          {streak >= 2 && !flipping && (
            <div className="absolute right-3 top-3 flex items-center gap-1 rounded-lg bg-gold/12 px-2 py-1 text-[10.5px] font-extrabold text-gold ring-1 ring-gold/30">
              <Flame size={11} /> серия {streak}
            </div>
          )}
        </div>

        {/* history */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto py-1">
          {history.map((h, i) => (
            <span
              key={i}
              className={cn(
                'grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-extrabold',
                h === 'heads' ? 'bg-gradient-to-b from-amber-300 to-amber-600 text-amber-950' : 'bg-gradient-to-b from-slate-300 to-slate-600 text-slate-900',
                i === 0 && 'pop-in ring-2 ring-white/30',
              )}
            >
              {h === 'heads' ? 'О' : 'Р'}
            </span>
          ))}
        </div>

        {/* side choice */}
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          {(['heads', 'tails'] as Side[]).map((s) => (
            <button
              key={s}
              disabled={flipping}
              onClick={() => { audio.click(); setChoice(s); }}
              className={cn(
                'flex items-center justify-center gap-2 rounded-xl border py-3.5 text-[13px] font-extrabold transition-all',
                choice === s
                  ? s === 'heads'
                    ? 'border-gold/60 bg-gold/12 text-gold'
                    : 'border-slate-400/60 bg-slate-400/12 text-slate-200'
                  : 'border-transparent bg-[#1a2029] text-slate-400 hover:bg-[#222938]',
              )}
            >
              <span className="text-[18px]">{s === 'heads' ? '🦅' : '₽'}</span>
              {s === 'heads' ? 'ОРЁЛ' : 'РЕШКА'}
            </button>
          ))}
        </div>

        <div className="mt-3 space-y-3">
          <BetBar amount={bet} setAmount={setBet} disabled={flipping} />
          <button
            onClick={flip}
            disabled={flipping}
            className="btn btn-gold btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]"
          >
            {flipping ? 'Монета в воздухе…' : `Бросить · ${fmt(bet)}`}
          </button>
        </div>
      </GameShell>
    </div>
  );
}
