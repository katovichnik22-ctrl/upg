import { useState } from 'react';
import { Bomb, Gem, Sparkles } from 'lucide-react';
import { BetBar, GameShell, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

const SIZE = 25;
const MINE_OPTIONS = [1, 3, 5, 10, 15];
const EDGE = 0.95;

/** payout multiplier after `picks` safe reveals with `mines` bombs */
function multFor(mines: number, picks: number): number {
  if (picks === 0) return 1;
  let m = 1;
  for (let i = 0; i < picks; i++) {
    m *= (SIZE - i) / (SIZE - mines - i);
  }
  return Math.max(1, Math.floor(m * EDGE * 100) / 100);
}

function layMines(count: number): Set<number> {
  const s = new Set<number>();
  while (s.size < count) s.add(Math.floor(Math.random() * SIZE));
  return s;
}

export default function Mines() {
  const { canBet, place, settle } = useGameRound('Мины');
  const [bet, setBet] = useState(100);
  const [mines, setMines] = useState(3);
  const [field, setField] = useState<Set<number>>(new Set());
  const [opened, setOpened] = useState<number[]>([]);
  const [active, setActive] = useState(false);
  const [dead, setDead] = useState<number | null>(null);
  const [curBet, setCurBet] = useState(0);

  const picks = opened.length;
  const mult = multFor(mines, picks);
  const nextMult = multFor(mines, picks + 1);
  const cashValue = Math.round(curBet * mult);

  const start = () => {
    const b = Math.round(bet);
    if (!canBet(b)) return;
    audio.click();
    place(b);
    setCurBet(b);
    setField(layMines(mines));
    setOpened([]);
    setDead(null);
    setActive(true);
  };

  const open = (i: number) => {
    if (!active || opened.includes(i)) return;
    if (field.has(i)) {
      audio.lose();
      setDead(i);
      setActive(false);
      settle(curBet, 0, `Мина на ${picks + 1}-м шаге`);
      return;
    }
    audio.blip(900 + picks * 90, 0.07, 'triangle', 0.11);
    const next = [...opened, i];
    setOpened(next);
    if (next.length === SIZE - mines) {
      const payout = Math.round(curBet * multFor(mines, next.length));
      setActive(false);
      settle(curBet, payout, 'Поле полностью открыто!');
    }
  };

  const cashout = () => {
    if (!active || picks === 0) return;
    audio.coin();
    setActive(false);
    settle(curBet, cashValue, `Забрал на x${mult.toFixed(2)}`);
  };

  return (
    <div className="mx-auto max-w-[720px] space-y-4">
      <GameShell
        title="Мины"
        subtitle="Открывай кристаллы и забирай до того, как найдёшь бомбу"
        right={<Bomb size={16} className="text-rose-400" />}
      >
        <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
          {Array.from({ length: SIZE }, (_, i) => {
            const isOpen = opened.includes(i);
            const isDead = dead === i;
            const reveal = !active && field.has(i) && (dead !== null || picks > 0);
            return (
              <button
                key={i}
                onClick={() => open(i)}
                disabled={!active || isOpen}
                className={cn(
                  'grid aspect-square place-items-center rounded-xl border text-[20px] transition-all sm:text-[24px]',
                  isOpen && 'border-emerald-400/45 bg-emerald-500/12',
                  isDead && 'border-rose-500/70 bg-rose-500/25',
                  !isOpen && !isDead && reveal && 'border-rose-500/25 bg-rose-500/8',
                  !isOpen && !isDead && !reveal && 'border-white/8 bg-[#151b28]',
                  active && !isOpen && 'hover:-translate-y-0.5 hover:border-gold/45 hover:bg-[#1c2333]',
                )}
              >
                {isOpen && <Gem size={20} className="pop-in text-emerald-300 drop-shadow-[0_0_8px_rgba(52,211,153,.8)]" />}
                {(isDead || (reveal && !isOpen)) && <Bomb size={20} className={cn('pop-in', isDead ? 'text-rose-400' : 'text-rose-500/50')} />}
              </button>
            );
          })}
        </div>

        {/* status */}
        <div className="mt-3 grid grid-cols-3 gap-2">
          <div className="panel-inset px-3 py-2 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-slate-500">Открыто</div>
            <div className="num text-[15px] font-extrabold">{picks}</div>
          </div>
          <div className="panel-inset px-3 py-2 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-slate-500">Текущий кэф</div>
            <div className="num text-[15px] font-extrabold text-gold">x{mult.toFixed(2)}</div>
          </div>
          <div className="panel-inset px-3 py-2 text-center">
            <div className="text-[9px] font-bold uppercase tracking-wider text-slate-500">Следующий</div>
            <div className="num text-[15px] font-extrabold text-emerald-300">x{nextMult.toFixed(2)}</div>
          </div>
        </div>

        <div className="mt-3 space-y-3">
          {!active && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Мин на поле</span>
                {MINE_OPTIONS.map((m) => (
                  <button key={m} className={cn('chip num', mines === m && 'on')} onClick={() => { audio.click(); setMines(m); }}>
                    {m}
                  </button>
                ))}
              </div>
              <BetBar amount={bet} setAmount={setBet} />
              <button onClick={start} className="btn btn-gold btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]">
                <Sparkles size={16} /> Начать · {fmt(bet)}
              </button>
            </>
          )}
          {active && (
            <button
              onClick={cashout}
              disabled={picks === 0}
              className="btn btn-green btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]"
            >
              {picks === 0 ? 'Откройте хотя бы одну клетку' : `Забрать · ${fmt(cashValue)}`}
            </button>
          )}
        </div>
      </GameShell>
    </div>
  );
}
