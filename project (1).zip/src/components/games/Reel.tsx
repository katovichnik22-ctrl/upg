import { forwardRef, memo, useImperativeHandle, useMemo, useRef } from 'react';
import { symbol, TIER_GLOW } from '../../data/slotSymbols';
import { SlotSymbol } from '../SlotSymbol';

export const ROWS = 3;
/** высота ячейки — единая константа для JS и разметки */
export const CELL_H = 62;
/** длина ленты прокрутки */
const STRIP = 24;

export interface ReelHandle {
  spin: (final: string[], delayMs: number, durMs: number, onDone: () => void) => void;
  highlight: (rows: Set<number>, color: string) => void;
}

/**
 * Барабан: ОДИН слой символов (лента), без наложений.
 * Прокрутка — только transform, без setState на кадрах.
 * Приём: итог подставляется в хвост ленты, после остановки
 * копируется в голову и лента мгновенно возвращается в 0.
 */
export const Reel = memo(forwardRef<ReelHandle, {
  pool: string[];
  initial: string[];
}>(function Reel({ pool, initial }, ref) {
  const stripRef = useRef<HTMLDivElement>(null);
  const timers = useRef<number[]>([]);

  /** лента создаётся один раз: голова = стартовые символы */
  const cells = useMemo(() => {
    const out = [...initial];
    for (let i = ROWS; i < STRIP; i++) {
      out.push(pool[Math.floor(Math.random() * pool.length)]);
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** запись символа в ячейку напрямую в DOM */
  const write = (idx: number, id: string) => {
    const el = stripRef.current?.children[idx] as HTMLElement | undefined;
    const img = el?.querySelector('img');
    const def = symbol(id);
    if (img) {
      img.setAttribute('src', def.image);
      img.setAttribute('alt', def.label);
    } else if (el) {
      el.dataset.sym = id;
    }
  };

  useImperativeHandle(ref, () => ({
    spin(final, delayMs, durMs, onDone) {
      const el = stripRef.current;
      if (!el) { onDone(); return; }
      timers.current.forEach(window.clearTimeout);
      timers.current = [];

      /* убираем подсветку прошлого раунда */
      for (let i = 0; i < ROWS; i++) {
        const c = el.children[i] as HTMLElement;
        c.style.boxShadow = '';
        c.style.background = '';
        c.querySelector<HTMLElement>('[data-sym-box]')?.classList.remove('sym-win');
      }

      /* итог кладём в хвост ленты */
      for (let i = 0; i < ROWS; i++) write(STRIP - ROWS + i, final[i]);
      /* середину перетасовываем, чтобы лента не повторялась */
      for (let i = ROWS; i < STRIP - ROWS; i++) {
        write(i, pool[Math.floor(Math.random() * pool.length)]);
      }

      timers.current.push(window.setTimeout(() => {
        el.style.transition = 'none';
        el.style.transform = 'translate3d(0,0,0)';
        el.classList.add('reel-fast');
        void el.offsetHeight;                       // применяем сброс
        el.style.transition = `transform ${durMs}ms cubic-bezier(.17,.67,.24,1)`;
        el.style.transform = `translate3d(0,${-(STRIP - ROWS) * CELL_H}px,0)`;

        timers.current.push(window.setTimeout(() => {
          el.classList.remove('reel-fast');
          /* итог копируем в голову и мгновенно возвращаем ленту — без мигания */
          for (let i = 0; i < ROWS; i++) write(i, final[i]);
          el.style.transition = 'none';
          el.style.transform = 'translate3d(0,0,0)';
          onDone();
        }, durMs));
      }, delayMs));
    },

    highlight(rows, color) {
      const el = stripRef.current;
      if (!el) return;
      for (let i = 0; i < ROWS; i++) {
        const c = el.children[i] as HTMLElement;
        const on = rows.has(i);
        c.style.boxShadow = on ? `inset 0 0 0 2px ${color}` : '';
        c.style.background = on ? `${color}22` : '';
        c.querySelector<HTMLElement>('[data-sym-box]')?.classList.toggle('sym-win', on);
      }
    },
  }), [pool]);

  return (
    <div
      className="relative overflow-hidden rounded-lg"
      style={{
        height: CELL_H * ROWS,
        background: 'linear-gradient(180deg,#0a0e18,#141b2b 50%,#0a0e18)',
        boxShadow: 'inset 0 5px 10px rgba(0,0,0,.75), inset 0 -5px 10px rgba(0,0,0,.75)',
        contain: 'paint',
      }}
    >
      <div
        ref={stripRef}
        className="reel-strip flex flex-col"
        style={{ willChange: 'transform' }}
      >
        {cells.map((id, i) => {
          const def = symbol(id);
          const special = def.tier === 'wild' || def.tier === 'bonus' || def.tier === 'scatter';
          return (
            <div
              key={i}
              className="relative grid shrink-0 place-items-center"
              style={{ height: CELL_H, borderBottom: '1px solid rgba(255,255,255,.05)' }}
            >
              <div data-sym-box className={special ? 'sym-idle' : undefined}>
                <SlotSymbol name={id} size={Math.round(CELL_H * 0.76)} />
              </div>
              {special && (
                <span
                  className="pointer-events-none absolute inset-0"
                  style={{ background: `radial-gradient(circle,${TIER_GLOW[def.tier]}1f,transparent 70%)` }}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* стекло поверх барабана */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg,rgba(255,255,255,.12),transparent 26%,transparent 74%,rgba(0,0,0,.3))',
        }}
      />
    </div>
  );
}));
