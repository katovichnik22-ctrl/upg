import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { History, Play } from 'lucide-react';
import {
  PLINKO_MULTIPLIERS, RISKS, ROW_OPTIONS, slotColor,
  type Risk, type RowsCount,
} from '../../data/plinko';
import { BetBar, GameShell, useGameRound } from './common';
import { fmt } from '../../lib/skins';
import { audio } from '../../lib/audio';
import { cn } from '../../utils/cn';

const BALL = 11;

interface Drop { id: number; mult: number }

export default function Plinko() {
  const { canBet, place, settle } = useGameRound('Плинко');

  const [bet, setBet] = useState(50);
  const [risk, setRisk] = useState<Risk>('medium');
  const [rows, setRows] = useState<RowsCount>(12);
  const [history, setHistory] = useState<Drop[]>([]);
  const [auto, setAuto] = useState(0);
  const [live, setLive] = useState(0);           // шариков в полёте
  const [hot, setHot] = useState<number | null>(null);
  const [stats, setStats] = useState({ drops: 0, wagered: 0, won: 0 });

  const boardRef = useRef<HTMLDivElement>(null);
  const layerRef = useRef<HTMLDivElement>(null);
  const rafs = useRef<Set<number>>(new Set());
  const timers = useRef<number[]>([]);
  const dropId = useRef(0);
  const autoRef = useRef(0);
  autoRef.current = auto;

  const mults = PLINKO_MULTIPLIERS[rows][risk];

  useEffect(() => () => {
    rafs.current.forEach(cancelAnimationFrame);
    timers.current.forEach(window.clearTimeout);
  }, []);

  /** геометрия доски */
  const geo = useMemo(() => {
    const w = 340;
    const padTop = 16;
    const gapY = rows <= 8 ? 26 : rows <= 12 ? 22 : 18;
    const gapX = w / (rows + 2);
    const h = padTop + rows * gapY + 44;
    return { w, h, padTop, gapY, gapX };
  }, [rows]);

  /** колышки: ряд i содержит i+3 штук */
  const pegs = useMemo(() => {
    const out: Array<{ x: number; y: number }> = [];
    for (let r = 0; r < rows; r++) {
      const count = r + 3;
      const y = geo.padTop + r * geo.gapY;
      const rowW = (count - 1) * geo.gapX;
      const x0 = (geo.w - rowW) / 2;
      for (let c = 0; c < count; c++) out.push({ x: x0 + c * geo.gapX, y });
    }
    return out;
  }, [rows, geo]);

  const finishDrop = useCallback((slotIdx: number, staked: number) => {
    const mult = mults[slotIdx];
    const payout = Math.round(staked * mult);
    setHistory((h) => [{ id: ++dropId.current, mult }, ...h].slice(0, 15));
    setStats((s) => ({ drops: s.drops + 1, wagered: s.wagered + staked, won: s.won + payout }));
    setHot(slotIdx);
    window.setTimeout(() => setHot((v) => (v === slotIdx ? null : v)), 550);
    settle(staked, payout, `x${mult} · лоток ${slotIdx + 1}`);
    setLive((n) => Math.max(0, n - 1));
  }, [mults, settle]);

  /** один шарик: физика в RAF пишет прямо в style, без setState */
  const launch = useCallback((staked: number) => {
    const layer = layerRef.current;
    if (!layer) return;

    /* заранее считаем путь: на каждом ряду влево/вправо */
    let slotIdx = 0;
    const path: number[] = [];
    for (let r = 0; r < rows; r++) {
      const right = Math.random() < 0.5 ? 0 : 1;
      path.push(right);
      slotIdx += right;
    }

    const el = document.createElement('div');
    el.className = 'gpu';
    el.style.cssText =
      `position:absolute;left:0;top:0;width:${BALL}px;height:${BALL}px;border-radius:50%;` +
      'background:radial-gradient(circle at 34% 30%,#fff,#ffd964 45%,#b8790c);' +
      'box-shadow:0 1px 4px rgba(0,0,0,.6);pointer-events:none';
    layer.appendChild(el);
    setLive((n) => n + 1);

    const startX = geo.w / 2;
    let px = startX;
    let py = -BALL;
    let vy = 0;
    let row = 0;
    let targetX = startX;
    const stepDur = 1;
    const g = 0.62;

    const tick = () => {
      vy += g;
      py += vy;

      const rowY = geo.padTop + row * geo.gapY;
      if (row < rows && py >= rowY) {
        /* отскок от колышка: гасим скорость и смещаемся вбок */
        vy *= -0.32;
        const dir = path[row] === 1 ? 1 : -1;
        targetX += (dir * geo.gapX) / 2;
        row++;
        if (row % 2 === 0 || rows <= 8) {
          audio.blip(900 + Math.random() * 500, 0.018, 'square', 0.035);
        }
      }
      /* плавное подтягивание к целевой колонке */
      px += (targetX - px) * 0.35;

      el.style.transform = `translate3d(${px - BALL / 2}px,${py}px,0)`;

      if (py < geo.h - 24) {
        const id = requestAnimationFrame(tick);
        rafs.current.add(id);
      } else {
        el.remove();
        audio.blip(520, 0.05, 'triangle', 0.07);
        finishDrop(slotIdx, staked);
      }
    };
    void stepDur;
    const id = requestAnimationFrame(tick);
    rafs.current.add(id);
  }, [rows, geo, finishDrop]);

  const drop = useCallback(() => {
    const staked = Math.round(bet);
    if (!canBet(staked)) { setAuto(0); return; }
    place(staked);
    audio.click();
    launch(staked);
  }, [bet, canBet, place, launch]);

  /** автосерия */
  const startAuto = (n: number) => {
    audio.click();
    setAuto(n);
    let left = n;
    const step = () => {
      if (left <= 0 || autoRef.current <= 0) { setAuto(0); return; }
      left--;
      setAuto(left);
      drop();
      timers.current.push(window.setTimeout(step, 260));
    };
    step();
  };

  const rtp = stats.wagered > 0 ? (stats.won / stats.wagered) * 100 : 0;
  const slotW = geo.w / mults.length;

  return (
    <div className="mx-auto max-w-[420px] space-y-3">
      <GameShell title="Плинко" subtitle="Шарик падает — множитель на дне">
        {/* доска */}
        <div
          ref={boardRef}
          className="relative mx-auto overflow-hidden rounded-2xl"
          style={{
            width: geo.w,
            height: geo.h,
            maxWidth: '100%',
            background: 'radial-gradient(120% 90% at 50% 0%, #17203a, #080c16 75%)',
            contain: 'paint',
          }}
        >
          {/* колышки — статичный слой, не перерисовывается */}
          <svg width={geo.w} height={geo.h} className="absolute inset-0">
            {pegs.map((p, i) => (
              <circle key={i} cx={p.x} cy={p.y} r={2.6} fill="#93a3c9" opacity={0.9} />
            ))}
          </svg>

          {/* слой шариков */}
          <div ref={layerRef} className="absolute inset-0" />

          {/* лотки */}
          <div className="absolute inset-x-0 bottom-0 flex" style={{ height: 26 }}>
            {mults.map((m, i) => (
              <div
                key={i}
                className="grid place-items-center text-[8.5px] font-extrabold text-black/80 transition-transform"
                style={{
                  width: slotW,
                  background: slotColor(i, mults.length),
                  borderRight: i < mults.length - 1 ? '1px solid rgba(0,0,0,.35)' : undefined,
                  transform: hot === i ? 'translateY(-4px)' : 'none',
                  boxShadow: hot === i ? '0 0 12px #fff' : undefined,
                }}
              >
                {m}
              </div>
            ))}
          </div>
        </div>

        {/* риск и ряды */}
        <div className="mt-3 space-y-2">
          <div className="chip-row">
            <span className="chip pointer-events-none text-slate-500">Риск</span>
            {RISKS.map((r) => (
              <button key={r.id} className={cn('chip', risk === r.id && 'on')}
                disabled={live > 0} onClick={() => { audio.click(); setRisk(r.id); }}>
                {r.label}
              </button>
            ))}
          </div>
          <div className="chip-row">
            <span className="chip pointer-events-none text-slate-500">Ряды</span>
            {ROW_OPTIONS.map((n) => (
              <button key={n} className={cn('chip num', rows === n && 'on')}
                disabled={live > 0} onClick={() => { audio.click(); setRows(n); }}>
                {n}
              </button>
            ))}
          </div>

          <BetBar amount={bet} setAmount={setBet} disabled={auto > 0} />

          <button
            onClick={() => (auto > 0 ? setAuto(0) : drop())}
            className={cn('btn btn-shine w-full py-4 font-display text-[14px] font-extrabold uppercase tracking-[0.14em]',
              auto > 0 ? 'btn-red' : 'btn-gold')}
          >
            <Play size={16} /> {auto > 0 ? `Стоп · ${auto}` : `Бросить · ${fmt(bet)}`}
          </button>

          <div className="chip-row">
            <span className="chip pointer-events-none text-slate-500">Авто</span>
            {[10, 25, 50, 100].map((n) => (
              <button key={n} className="chip" disabled={auto > 0} onClick={() => startAuto(n)}>×{n}</button>
            ))}
          </div>
        </div>
      </GameShell>

      {/* история */}
      {history.length > 0 && (
        <div className="panel flex items-center gap-1.5 overflow-x-auto p-2.5">
          <History size={13} className="mr-0.5 shrink-0 text-slate-600" />
          {history.map((d) => (
            <span key={d.id}
              className="num shrink-0 rounded-md px-1.5 py-1 text-[10px] font-extrabold text-black/85"
              style={{ background: d.mult >= 2 ? '#8ecf3a' : d.mult >= 1 ? '#e8d51a' : '#ff7a1a' }}>
              x{d.mult}
            </span>
          ))}
        </div>
      )}

      {/* статистика */}
      <div className="panel grid grid-cols-4 gap-1.5 p-2.5">
        {[
          ['Дропов', String(stats.drops)],
          ['Ставки', fmt(stats.wagered)],
          ['Выплаты', fmt(stats.won)],
          ['RTP', `${rtp.toFixed(0)}%`],
        ].map(([k, v]) => (
          <div key={k} className="panel-inset px-1 py-1.5 text-center">
            <div className="num truncate text-[11px] font-extrabold">{v}</div>
            <div className="text-[8px] uppercase tracking-wider text-slate-500">{k}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
