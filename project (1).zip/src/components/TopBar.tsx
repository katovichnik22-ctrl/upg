import { useRef } from 'react';
import {
  ChevronsUp, Disc3, ShoppingBag, User, ShieldCheck,
  MousePointerClick, Globe,
} from 'lucide-react';
import type { Tab } from '../lib/types';
import { useGame } from '../lib/store';
import { useNet } from '../net/netStore';
import { AnimatedMoney } from './ui';
import { audio } from '../lib/audio';
import { cn } from '../utils/cn';

export const NAV: Array<{ id: Tab; label: string; icon: typeof ChevronsUp }> = [
  { id: 'upgrader', label: 'Апгрейд', icon: ChevronsUp },
  { id: 'roulette', label: 'Казино', icon: Disc3 },
  { id: 'clicker', label: 'Кликер', icon: MousePointerClick },
  { id: 'online', label: 'Онлайн', icon: Globe },
  { id: 'shop', label: 'Магазин', icon: ShoppingBag },
  { id: 'profile', label: 'Профиль', icon: User },
];

export function LogoMark({ size = 30 }: { size?: number }) {
  return (
    <div
      className="grid place-items-center rounded-lg shadow-[0_6px_18px_-4px_rgba(246,196,69,.6)]"
      style={{
        width: size, height: size,
        background: 'linear-gradient(180deg,#ffd964,#e8a013)',
        clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
      }}
    >
      <div className="grid h-full w-full place-items-center" style={{ clipPath: 'polygon(50% 8%, 92% 50%, 50% 92%, 8% 50%)', background: 'linear-gradient(180deg,#ffd964,#e8a013)' }}>
        <ChevronsUp size={size * 0.52} strokeWidth={3.2} style={{ color: '#241a02' }} />
      </div>
    </div>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <LogoMark size={compact ? 26 : 30} />
      <div className="leading-none">
        <div className="font-display text-[15px] font-extrabold tracking-[0.08em] text-white">
          NIK<span className="text-gold text-glow-gold">GRAGER</span>
        </div>
        {!compact && (
          <div className="mt-1 flex items-center gap-1 text-[8.5px] font-bold uppercase tracking-[0.2em] text-slate-500">
            <ShieldCheck size={9} className="text-emerald-400" /> Бесплатный режим
          </div>
        )}
      </div>
    </div>
  );
}

export function TopBar({ setTab, onSecret }: { setTab: (t: Tab) => void; onSecret?: () => void }) {
  const { state } = useGame();
  const net = useNet();
  /* серия быстрых тапов по логотипу открывает служебный вход */
  const taps = useRef<number[]>([]);

  const hitLogo = () => {
    audio.click();
    const now = Date.now();
    taps.current = [...taps.current.filter((t) => now - t < 1500), now];
    if (taps.current.length >= 5) {
      taps.current = [];
      onSecret?.();
      return;
    }
    setTab('upgrader');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-[#0b0e15]">
      <div className="flex h-[58px] w-full items-center gap-2.5 px-3">
        <button onClick={hitLogo} className="shrink-0">
          <Logo />
        </button>

        {/* индикатор P2P-соединения */}
        {net.state === 'online' && (
          <button
            onClick={() => { audio.click(); setTab('online'); }}
            className="flex shrink-0 items-center gap-1 rounded-lg bg-emerald-400/12 px-1.5 py-1 text-[9px] font-bold text-emerald-300 ring-1 ring-emerald-400/25"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            P2P
          </button>
        )}

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <button
            onClick={() => { audio.click(); setTab('profile'); }}
            title={`Профиль: ${state.name}`}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[12px] font-extrabold text-white ring-1 ring-white/15 transition-transform hover:scale-105"
            style={{
              background: `linear-gradient(135deg, hsl(${Math.abs([...state.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360} 65% 52%), hsl(${(Math.abs([...state.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360 + 60) % 360} 65% 38%))`,
            }}
          >
            {state.name[0]?.toUpperCase() ?? '?'}
          </button>
          <div className="hidden items-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] font-bold text-slate-500 lg:flex">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </span>
            {(1832 + (new Date().getMinutes() * 37) % 400).toLocaleString('ru-RU')} онлайн
          </div>
          <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-[#131a2c] py-1.5 pl-2.5 pr-1.5">
            <span className="grid h-5 w-5 place-items-center rounded-full bg-[#2563eb] text-[10px] font-black text-white">₽</span>
            <span className="hidden text-[9px] font-bold uppercase tracking-wider text-slate-500 sm:block">Баланс:</span>
            <AnimatedMoney value={state.balance} className="text-[13px] font-extrabold text-white" />
            <button
              onClick={() => { audio.click(); setTab('clicker'); }}
              className="btn-gold btn grid h-6 w-6 rounded-md text-sm font-black leading-none"
              title="Заработать в кликере"
            >
              +
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

/* -------- mobile bottom nav -------- */
export function MobileNav({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  return (
    <nav className="tabbar grid grid-cols-6 border-t border-line bg-[#0b0e15]">
      {NAV.map((n) => {
        const active = tab === n.id;
        return (
          <button
            key={n.id}
            onClick={() => { audio.click(); setTab(n.id); }}
            className={cn('flex flex-col items-center gap-1 py-2.5 text-[9.5px] font-bold', active ? 'text-gold' : 'text-slate-500')}
          >
            <n.icon size={20} strokeWidth={active ? 2.5 : 2} />
            {n.label}
          </button>
        );
      })}
    </nav>
  );
}
