import { useEffect, useRef, useState } from 'react';

/**
 * Простая виртуализация сетки: рендерит только видимые ряды.
 * Без внешних зависимостей — важно для размера бандла и телефона.
 */
export function VirtualGrid<T>({
  items, cols, rowHeight, gap = 8, height, render, overscan = 2, keyOf,
}: {
  items: T[];
  cols: number;
  rowHeight: number;
  gap?: number;
  /** высота области прокрутки, px */
  height: number;
  render: (item: T, index: number) => React.ReactNode;
  overscan?: number;
  keyOf: (item: T, index: number) => string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setScrollTop(el.scrollTop));
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const step = rowHeight + gap;
  const rows = Math.ceil(items.length / cols);
  const total = Math.max(0, rows * step - gap);
  const first = Math.max(0, Math.floor(scrollTop / step) - overscan);
  const visibleRows = Math.ceil(height / step) + overscan * 2;
  const last = Math.min(rows, first + visibleRows);

  const slice: React.ReactNode[] = [];
  for (let r = first; r < last; r++) {
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      if (i >= items.length) break;
      slice.push(
        <div key={keyOf(items[i], i)} style={{ height: rowHeight }}>
          {render(items[i], i)}
        </div>,
      );
    }
  }

  return (
    <div ref={ref} className="scroll-fast overflow-y-auto" style={{ height }}>
      <div style={{ height: total, position: 'relative' }}>
        <div
          style={{
            position: 'absolute',
            top: first * step,
            left: 0,
            right: 0,
            display: 'grid',
            gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))`,
            gap,
          }}
        >
          {slice}
        </div>
      </div>
    </div>
  );
}
