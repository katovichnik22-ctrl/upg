import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { ChevronsUp } from 'lucide-react';
import { GameProvider, SkinsProvider, useSkins, useGame } from './lib/store';
import { NetProvider } from './net/netStore';
import { levelInfo } from './lib/level';
import type { Tab } from './lib/types';
import { TopBar, MobileNav, LogoMark } from './components/TopBar';
import { Toasts } from './components/ui';
import Upgrader from './components/Upgrader';
import Casino from './components/Casino';
import Clicker from './components/Clicker';

import EconomyPicker from './components/EconomyPicker';
import Shop from './components/Shop';
import Profile from './components/Profile';
import Settings from './components/Settings';

/* сетевые и админские модули подгружаются по требованию */
const Online = lazy(() => import('./components/online/Online'));
const AdminGate = lazy(() => import('./admin/AdminGate'));

function LoadingScreen({ step }: { step: string }) {
  return (
    <div className="grid min-h-screen place-items-center">
      <div className="fade-up flex flex-col items-center gap-5 text-center">
        <div className="relative">
          <LogoMark size={64} />
          <div className="absolute -inset-4 -z-10 rounded-full bg-gold/20 blur-2xl ring-pulse" />
        </div>
        <div>
          <div className="font-display text-2xl font-extrabold tracking-[0.08em] text-white">
            NIK<span className="text-gold text-glow-gold">GRAGER</span>
          </div>
          <div className="mt-1 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">
            апгрейд скинов cs2
          </div>
        </div>
        <div className="w-56">
          <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
            <div className="h-full w-1/2 animate-[loadbar_1.1s_ease-in-out_infinite] rounded-full bg-gradient-to-r from-[#ffd964] to-[#e8a013]" />
          </div>
          <div className="pulse-soft mt-3 text-[11.5px] font-semibold text-slate-400">{step}</div>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-600">
          <ChevronsUp size={12} className="text-gold" /> бесплатный режим
        </div>
      </div>
      <style>{`@keyframes loadbar { 0%{transform:translateX(-110%)} 100%{transform:translateX(320%)} }`}</style>
    </div>
  );
}

/** Слабое устройство: мало ядер или памяти — включаем экономию по умолчанию */
function detectWeak(): boolean {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const cores = nav.hardwareConcurrency ?? 4;
  const mem = nav.deviceMemory ?? 4;
  return cores <= 4 || mem <= 3;
}

function Shell() {
  const { loading, step } = useSkins();
  const {
    toasts, state, createProfile, deleteProfile, activeProfile, setSettings,
  } = useGame();
  const [tab, setTab] = useState<Tab>('upgrader');
  const [adminAsk, setAdminAsk] = useState(0);

  /* режим экономии ресурсов */
  const lite = state.settings.lite;
  useEffect(() => {
    document.documentElement.classList.toggle('lite', lite);
  }, [lite]);

  /* на слабом телефоне включаем экономию автоматически при первом запуске */
  const autoLite = useRef(false);
  useEffect(() => {
    if (autoLite.current) return;
    autoLite.current = true;
    if (!lite && detectWeak()) setSettings({ lite: true, fast: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* первый запуск: профиль ещё не выбрал режим экономики */
  const needsSetup = !state.economySet;

  if (loading) return <LoadingScreen step={step} />;

  if (needsSetup) {
    return (
      <EconomyPicker
        title="Добро пожаловать"
        initialName={state.name === 'Игрок' ? '' : state.name}
        onDone={(name, economy) => {
          const old = activeProfile;
          createProfile(name, economy);
          deleteProfile(old);
        }}
      />
    );
  }

  return (
    <NetProvider name={state.name} level={levelInfo(state.stats.wagered).level}>
      <div className="flex min-h-screen flex-col">
        <TopBar setTab={setTab} onSecret={() => setAdminAsk((v) => v + 1)} />
        <main className="w-full flex-1 px-2.5 pb-[calc(82px+env(safe-area-inset-bottom))] pt-3">
          {tab === 'upgrader' && <Upgrader />}
          {tab === 'roulette' && <Casino />}
          {tab === 'clicker' && <Clicker />}
          {tab === 'online' && (
            <Suspense fallback={<div className="panel p-8 text-center text-[12px] text-slate-500">Загрузка…</div>}>
              <Online />
            </Suspense>
          )}
          {tab === 'shop' && <Shop onGoClicker={() => setTab('clicker')} />}
          {tab === 'profile' && <Profile />}
          {tab === 'settings' && <Settings />}
        </main>
        <footer className="border-t border-line px-4 py-3 text-center text-[9.5px] text-slate-600">
          NIKGRAGER v23 · честный режим · валюта виртуальная · скины не выводятся · 18+
        </footer>
        <MobileNav tab={tab} setTab={setTab} />

        <Toasts toasts={toasts} />

        {adminAsk > 0 && (
          <Suspense fallback={null}>
            <AdminGate askPin={adminAsk > 0} onDone={() => setAdminAsk(0)} />
          </Suspense>
        )}
      </div>
    </NetProvider>
  );
}

export default function App() {
  return (
    <SkinsProvider>
      <GameProvider>
        <div className="bg-scene" />
        <div className="bg-grid" />
        <div className="bg-noise" />
        <Shell />
      </GameProvider>
    </SkinsProvider>
  );
}
